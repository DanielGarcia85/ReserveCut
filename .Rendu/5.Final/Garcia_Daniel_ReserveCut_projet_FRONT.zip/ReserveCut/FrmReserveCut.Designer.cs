﻿namespace ReserveCut
{
    partial class FrmReserveCut
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmReserveCut));
            mns_file_rf = new ToolStripMenuItem();
            mns_new_rf = new ToolStripMenuItem();
            msns_newreservation_rf = new ToolStripMenuItem();
            mns_newcustomer_rf = new ToolStripMenuItem();
            mns_newstylist_rf = new ToolStripMenuItem();
            mns_newhaircut_rf = new ToolStripMenuItem();
            mns_users_rf = new ToolStripMenuItem();
            mns_quite_rf = new ToolStripMenuItem();
            mns_reservecut_rf = new MenuStrip();
            tab_reservecut_rf = new TabControl();
            tab_reservation_rr = new TabPage();
            dtp_reservation_rr = new DateTimePicker();
            pnl_1830_sat_rr = new Panel();
            pnl_1800_sat_rr = new Panel();
            pnl_1730_sat_rr = new Panel();
            pnl_1700_sat_rr = new Panel();
            pnl_1630_sat_rr = new Panel();
            pnl_1600_sat_rr = new Panel();
            pnl_1530_sat_rr = new Panel();
            pnl_1500_sat_rr = new Panel();
            pnl_1430_sat_rr = new Panel();
            pnl_1400_sat_rr = new Panel();
            pnl_1330_sat_rr = new Panel();
            pnl_1200_sat_rr = new Panel();
            pnl_1300_sat_rr = new Panel();
            pnl_1230_sat_rr = new Panel();
            pnl_1130_sat_rr = new Panel();
            pnl_1100_sat_rr = new Panel();
            pnl_1030_sat_rr = new Panel();
            pnl_1000_sat_rr = new Panel();
            pnl_0930_sat_rr = new Panel();
            pnl_0900_sat_rr = new Panel();
            pnl_1830_fri_rr = new Panel();
            pnl_1830_thu_rr = new Panel();
            pnl_1800_fri_rr = new Panel();
            pnl_1800_thu_rr = new Panel();
            pnl_1730_fri_rr = new Panel();
            pnl_1730_thu_rr = new Panel();
            pnl_1700_fri_rr = new Panel();
            pnl_1700_thu_rr = new Panel();
            pnl_1630_fri_rr = new Panel();
            pnl_1630_thu_rr = new Panel();
            pnl_1600_fri_rr = new Panel();
            pnl_1600_thu_rr = new Panel();
            pnl_1530_fri_rr = new Panel();
            pnl_1530_thu_rr = new Panel();
            pnl_1500_fri_rr = new Panel();
            pnl_1500_thu_rr = new Panel();
            pnl_1430_fri_rr = new Panel();
            pnl_1430_thu_rr = new Panel();
            pnl_1400_fri_rr = new Panel();
            pnl_1400_thu_rr = new Panel();
            pnl_1330_fri_rr = new Panel();
            pnl_1330_thu_rr = new Panel();
            pnl_1200_fri_rr = new Panel();
            pnl_1200_thu_rr = new Panel();
            pnl_1300_fri_rr = new Panel();
            pnl_1300_thu_rr = new Panel();
            pnl_1230_fri_rr = new Panel();
            pnl_1230_thu_rr = new Panel();
            pnl_1130_fri_rr = new Panel();
            pnl_1130_thu_rr = new Panel();
            pnl_1100_fri_rr = new Panel();
            pnl_1100_thu_rr = new Panel();
            pnl_1030_fri_rr = new Panel();
            pnl_1030_thu_rr = new Panel();
            pnl_1000_fri_rr = new Panel();
            pnl_1000_thu_rr = new Panel();
            pnl_0930_fri_rr = new Panel();
            pnl_0930_thu_rr = new Panel();
            pnl_0900_fri_rr = new Panel();
            pnl_0900_thu_rr = new Panel();
            pnl_1830_wed_rr = new Panel();
            pnl_1800_wed_rr = new Panel();
            pnl_1730_wed_rr = new Panel();
            pnl_1700_wed_rr = new Panel();
            pnl_1630_wed_rr = new Panel();
            pnl_1600_wed_rr = new Panel();
            pnl_1530_wed_rr = new Panel();
            pnl_1500_wed_rr = new Panel();
            pnl_1430_wed_rr = new Panel();
            pnl_1400_wed_rr = new Panel();
            pnl_1330_wed_rr = new Panel();
            pnl_1200_wed_rr = new Panel();
            pnl_1300_wed_rr = new Panel();
            pnl_1230_wed_rr = new Panel();
            pnl_1130_wed_rr = new Panel();
            pnl_1100_wed_rr = new Panel();
            pnl_1030_wed_rr = new Panel();
            pnl_1000_wed_rr = new Panel();
            pnl_0930_wed_rr = new Panel();
            pnl_0900_wed_rr = new Panel();
            pnl_1830_tue_rr = new Panel();
            pnl_1800_tue_rr = new Panel();
            pnl_1730_tue_rr = new Panel();
            pnl_1700_tue_rr = new Panel();
            pnl_1630_tue_rr = new Panel();
            pnl_1600_tue_rr = new Panel();
            pnl_1530_tue_rr = new Panel();
            pnl_1500_tue_rr = new Panel();
            pnl_1430_tue_rr = new Panel();
            pnl_1400_tue_rr = new Panel();
            pnl_1330_tue_rr = new Panel();
            pnl_1200_tue_rr = new Panel();
            pnl_1300_tue_rr = new Panel();
            pnl_1230_tue_rr = new Panel();
            pnl_1130_tue_rr = new Panel();
            pnl_1100_tue_rr = new Panel();
            pnl_1030_tue_rr = new Panel();
            pnl_1000_tue_rr = new Panel();
            pnl_0930_tue_rr = new Panel();
            pnl_0900_tue_rr = new Panel();
            pnl_1830_mon_rr = new Panel();
            pnl_1800_mon_rr = new Panel();
            pnl_1730_mon_rr = new Panel();
            pnl_1700_mon_rr = new Panel();
            pnl_1630_mon_rr = new Panel();
            pnl_1600_mon_rr = new Panel();
            pnl_1530_mon_rr = new Panel();
            pnl_1500_mon_rr = new Panel();
            pnl_1430_mon_rr = new Panel();
            pnl_1400_mon_rr = new Panel();
            pnl_1330_mon_rr = new Panel();
            pnl_1200_mon_rr = new Panel();
            pnl_1300_mon_rr = new Panel();
            pnl_1230_mon_rr = new Panel();
            pnl_1130_mon_rr = new Panel();
            pnl_1100_mon_rr = new Panel();
            pnl_1030_mon_rr = new Panel();
            pnl_1000_mon_rr = new Panel();
            pnl_0930_mon_rr = new Panel();
            pnl_0900_mon_rr = new Panel();
            pnl_0830_sat_rr = new Panel();
            pnl_0830_wed_rr = new Panel();
            pnl_0830_fri_rr = new Panel();
            pnl_0830_thu_rr = new Panel();
            pnl_0830_tue_rr = new Panel();
            pnl_0830_mon_rr = new Panel();
            lbl_0800_rr = new Label();
            cmb_stylist_rr = new ComboBox();
            lbl_stylist_rr = new Label();
            pnl_0800_sat_rr = new Panel();
            pnl_0800_wed_rr = new Panel();
            pnl_0800_fri_rr = new Panel();
            pnl_0800_thu_rr = new Panel();
            pnl_0800_tue_rr = new Panel();
            pnl_0800_mon_rr = new Panel();
            btn_add_rr = new Button();
            lbl_1830_rr = new Label();
            lbl_1800_rr = new Label();
            lbl_1730_rr = new Label();
            lbl_1700_rr = new Label();
            lbl_1630_rr = new Label();
            lbl_1600_rr = new Label();
            lbl_1530_rr = new Label();
            lbl_1500_rr = new Label();
            lbl_1430_rr = new Label();
            lbl_1400_rr = new Label();
            lbl_1330_rr = new Label();
            lbl_1300_rr = new Label();
            lbl_1230_rr = new Label();
            lbl_1200_rr = new Label();
            lbl_1130_rr = new Label();
            lbl_1100_rr = new Label();
            lbl_1030_rr = new Label();
            lbl_1000_rr = new Label();
            lbl_0930_rr = new Label();
            lbl_0900_rr = new Label();
            lbl_8030_rr = new Label();
            lbl_saturday_rr = new Label();
            lbl_friday_rr = new Label();
            lbl_thursday_rr = new Label();
            lbl_wednesday_rr = new Label();
            lbl_tuesday_rr = new Label();
            lbl_monday_rr = new Label();
            tab_customer_rc = new TabPage();
            btn_cancel_rc = new Button();
            dtp_birthdate_rc = new DateTimePicker();
            cmb_contact_rc = new ComboBox();
            cmb_haircut_rc = new ComboBox();
            btn_photo_rc = new Button();
            btn_confirm_rc = new Button();
            btn_delete_rc = new Button();
            btn_modify_rc = new Button();
            txb_haircut_rc = new TextBox();
            lbl_haircut_rc = new Label();
            btn_next_rc = new Button();
            btn_previous_rc = new Button();
            pic_customer_rc = new PictureBox();
            btn_add_rc = new Button();
            lbl_search_rc = new Label();
            txb_search_rc = new TextBox();
            txb_npa_rc = new TextBox();
            txb_contact_rc = new TextBox();
            txb_datebirth_rc = new TextBox();
            txb_phone_rc = new TextBox();
            txb_mail_rc = new TextBox();
            txb_city_rc = new TextBox();
            txb_address_rc = new TextBox();
            txb_firstname_rc = new TextBox();
            txb_name_rc = new TextBox();
            lbl_npa_rc = new Label();
            lbl_contact_rc = new Label();
            lbl_birthdate_rc = new Label();
            lbl_phone_rc = new Label();
            lbl_mail_rc = new Label();
            lbl_city_rc = new Label();
            lbl_address_rc = new Label();
            lbl_firstname_rc = new Label();
            lbl_name_rc = new Label();
            tab_stylist_rs = new TabPage();
            btn_cancel_rs = new Button();
            btn_photo_rs = new Button();
            btn_confirm_rs = new Button();
            lbl_absence_rs = new Label();
            cmb_speciality_rs = new ComboBox();
            btn_next_rs = new Button();
            btn_previous_rs = new Button();
            btn_deleteabsence_rs = new Button();
            btn_addabsence_rs = new Button();
            lst_absence_rs = new ListBox();
            btn_deletespeciality_rs = new Button();
            btn_delete_rs = new Button();
            btn_add_rs = new Button();
            lst_speciality_rs = new ListBox();
            pic_stylist_rs = new PictureBox();
            btn_addspeciality_rs = new Button();
            btn_modify_rs = new Button();
            lbl_speciality_rs = new Label();
            lbl_search_rs = new Label();
            txb_search_rs = new TextBox();
            txb_firstname_rs = new TextBox();
            txb_name_rs = new TextBox();
            lbl_firstname_rs = new Label();
            lbl_name_rs = new Label();
            tab_haircut_rh = new TabPage();
            cmb_cuttingtime_rh = new ComboBox();
            btn_cancel_rh = new Button();
            cmb_shortlong_rh = new ComboBox();
            btn_photo_rh = new Button();
            btn_confirm_rh = new Button();
            txb_price_rh = new TextBox();
            lbl_price_rh = new Label();
            btn_next_rh = new Button();
            btn_previous_rh = new Button();
            btn_delete_rh = new Button();
            btn_modify_rh = new Button();
            btn_add_rh = new Button();
            txb_shortlong_rh = new TextBox();
            lbl_shortlong_rh = new Label();
            pic_haircut_rh = new PictureBox();
            txb_cuttingtime_rh = new TextBox();
            txb_description_rh = new RichTextBox();
            lbl_cuttingtime_rh = new Label();
            txb_name_rh = new TextBox();
            lbl_description_rh = new Label();
            lbl_name_rh = new Label();
            lbl_search_rh = new Label();
            txb_search_rh = new TextBox();
            pic_reservecute_rf = new PictureBox();
            mns_reservecut_rf.SuspendLayout();
            tab_reservecut_rf.SuspendLayout();
            tab_reservation_rr.SuspendLayout();
            tab_customer_rc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_customer_rc).BeginInit();
            tab_stylist_rs.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_stylist_rs).BeginInit();
            tab_haircut_rh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_haircut_rh).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pic_reservecute_rf).BeginInit();
            SuspendLayout();
            // 
            // mns_file_rf
            // 
            mns_file_rf.DropDownItems.AddRange(new ToolStripItem[] { mns_new_rf, mns_users_rf, mns_quite_rf });
            mns_file_rf.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            mns_file_rf.Name = "mns_file_rf";
            mns_file_rf.Size = new Size(60, 23);
            mns_file_rf.Text = "Fichier";
            // 
            // mns_new_rf
            // 
            mns_new_rf.BackColor = SystemColors.Window;
            mns_new_rf.DropDownItems.AddRange(new ToolStripItem[] { msns_newreservation_rf, mns_newcustomer_rf, mns_newstylist_rf, mns_newhaircut_rf });
            mns_new_rf.Name = "mns_new_rf";
            mns_new_rf.Size = new Size(197, 24);
            mns_new_rf.Text = "Nouveau";
            // 
            // msns_newreservation_rf
            // 
            msns_newreservation_rf.BackColor = SystemColors.Window;
            msns_newreservation_rf.Name = "msns_newreservation_rf";
            msns_newreservation_rf.ShortcutKeys = Keys.Control | Keys.R;
            msns_newreservation_rf.Size = new Size(241, 24);
            msns_newreservation_rf.Text = "Réservation";
            msns_newreservation_rf.Click += mns_newreservation_rc_Click;
            // 
            // mns_newcustomer_rf
            // 
            mns_newcustomer_rf.BackColor = SystemColors.Window;
            mns_newcustomer_rf.Name = "mns_newcustomer_rf";
            mns_newcustomer_rf.ShortcutKeys = Keys.Control | Keys.P;
            mns_newcustomer_rf.Size = new Size(241, 24);
            mns_newcustomer_rf.Text = "Client";
            mns_newcustomer_rf.Click += mns_newcustomer_rc_Click;
            // 
            // mns_newstylist_rf
            // 
            mns_newstylist_rf.BackColor = SystemColors.Window;
            mns_newstylist_rf.Name = "mns_newstylist_rf";
            mns_newstylist_rf.ShortcutKeys = Keys.Control | Keys.S;
            mns_newstylist_rf.Size = new Size(241, 24);
            mns_newstylist_rf.Text = "Coiffeur";
            mns_newstylist_rf.Click += mns_newstylist_rc_Click;
            // 
            // mns_newhaircut_rf
            // 
            mns_newhaircut_rf.BackColor = SystemColors.Window;
            mns_newhaircut_rf.Name = "mns_newhaircut_rf";
            mns_newhaircut_rf.ShortcutKeys = Keys.Control | Keys.H;
            mns_newhaircut_rf.Size = new Size(241, 24);
            mns_newhaircut_rf.Text = "Coupe de cheveux";
            mns_newhaircut_rf.Click += mns_newhaircut_rc_Click;
            // 
            // mns_users_rf
            // 
            mns_users_rf.BackColor = SystemColors.Window;
            mns_users_rf.Name = "mns_users_rf";
            mns_users_rf.ShortcutKeys = Keys.Control | Keys.U;
            mns_users_rf.Size = new Size(197, 24);
            mns_users_rf.Text = "Utilisateurs";
            mns_users_rf.Click += mns_users_rc_Click;
            // 
            // mns_quite_rf
            // 
            mns_quite_rf.Name = "mns_quite_rf";
            mns_quite_rf.ShortcutKeys = Keys.Control | Keys.Q;
            mns_quite_rf.Size = new Size(197, 24);
            mns_quite_rf.Text = "Quitter";
            mns_quite_rf.Click += mns_quite_rc_Click;
            // 
            // mns_reservecut_rf
            // 
            mns_reservecut_rf.BackColor = SystemColors.Window;
            mns_reservecut_rf.ImageScalingSize = new Size(20, 20);
            mns_reservecut_rf.Items.AddRange(new ToolStripItem[] { mns_file_rf });
            mns_reservecut_rf.Location = new Point(0, 0);
            mns_reservecut_rf.Name = "mns_reservecut_rf";
            mns_reservecut_rf.Padding = new Padding(7, 3, 0, 3);
            mns_reservecut_rf.RenderMode = ToolStripRenderMode.Professional;
            mns_reservecut_rf.Size = new Size(1031, 29);
            mns_reservecut_rf.TabIndex = 1;
            mns_reservecut_rf.Text = "menuStrip1";
            // 
            // tab_reservecut_rf
            // 
            tab_reservecut_rf.Controls.Add(tab_reservation_rr);
            tab_reservecut_rf.Controls.Add(tab_customer_rc);
            tab_reservecut_rf.Controls.Add(tab_stylist_rs);
            tab_reservecut_rf.Controls.Add(tab_haircut_rh);
            tab_reservecut_rf.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tab_reservecut_rf.Location = new Point(0, 36);
            tab_reservecut_rf.Name = "tab_reservecut_rf";
            tab_reservecut_rf.SelectedIndex = 0;
            tab_reservecut_rf.Size = new Size(1031, 626);
            tab_reservecut_rf.TabIndex = 1;
            tab_reservecut_rf.SelectedIndexChanged += tab_reservecut_rc_SelectedIndexChanged;
            // 
            // tab_reservation_rr
            // 
            tab_reservation_rr.BackColor = SystemColors.Window;
            tab_reservation_rr.Controls.Add(dtp_reservation_rr);
            tab_reservation_rr.Controls.Add(pnl_1830_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1800_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1730_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1700_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1630_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1600_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1530_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1500_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1430_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1400_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1330_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1200_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1300_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1230_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1130_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1100_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1030_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1000_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_0930_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_0900_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_1830_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1830_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1800_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1800_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1730_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1730_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1700_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1700_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1630_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1630_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1600_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1600_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1530_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1530_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1500_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1500_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1430_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1430_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1400_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1400_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1330_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1330_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1200_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1200_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1300_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1300_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1230_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1230_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1130_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1130_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1100_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1100_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1030_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1030_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1000_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_1000_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_0930_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_0930_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_0900_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_0900_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_1830_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1800_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1730_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1700_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1630_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1600_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1530_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1500_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1430_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1400_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1330_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1200_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1300_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1230_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1130_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1100_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1030_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1000_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_0930_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_0900_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_1830_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1800_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1730_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1700_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1630_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1600_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1530_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1500_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1430_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1400_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1330_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1200_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1300_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1230_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1130_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1100_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1030_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1000_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_0930_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_0900_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_1830_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1800_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1730_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1700_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1630_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1600_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1530_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1500_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1430_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1400_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1330_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1200_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1300_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1230_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1130_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1100_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1030_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_1000_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_0930_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_0900_mon_rr);
            tab_reservation_rr.Controls.Add(pnl_0830_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_0830_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_0830_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_0830_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_0830_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_0830_mon_rr);
            tab_reservation_rr.Controls.Add(lbl_0800_rr);
            tab_reservation_rr.Controls.Add(cmb_stylist_rr);
            tab_reservation_rr.Controls.Add(lbl_stylist_rr);
            tab_reservation_rr.Controls.Add(pnl_0800_sat_rr);
            tab_reservation_rr.Controls.Add(pnl_0800_wed_rr);
            tab_reservation_rr.Controls.Add(pnl_0800_fri_rr);
            tab_reservation_rr.Controls.Add(pnl_0800_thu_rr);
            tab_reservation_rr.Controls.Add(pnl_0800_tue_rr);
            tab_reservation_rr.Controls.Add(pnl_0800_mon_rr);
            tab_reservation_rr.Controls.Add(btn_add_rr);
            tab_reservation_rr.Controls.Add(lbl_1830_rr);
            tab_reservation_rr.Controls.Add(lbl_1800_rr);
            tab_reservation_rr.Controls.Add(lbl_1730_rr);
            tab_reservation_rr.Controls.Add(lbl_1700_rr);
            tab_reservation_rr.Controls.Add(lbl_1630_rr);
            tab_reservation_rr.Controls.Add(lbl_1600_rr);
            tab_reservation_rr.Controls.Add(lbl_1530_rr);
            tab_reservation_rr.Controls.Add(lbl_1500_rr);
            tab_reservation_rr.Controls.Add(lbl_1430_rr);
            tab_reservation_rr.Controls.Add(lbl_1400_rr);
            tab_reservation_rr.Controls.Add(lbl_1330_rr);
            tab_reservation_rr.Controls.Add(lbl_1300_rr);
            tab_reservation_rr.Controls.Add(lbl_1230_rr);
            tab_reservation_rr.Controls.Add(lbl_1200_rr);
            tab_reservation_rr.Controls.Add(lbl_1130_rr);
            tab_reservation_rr.Controls.Add(lbl_1100_rr);
            tab_reservation_rr.Controls.Add(lbl_1030_rr);
            tab_reservation_rr.Controls.Add(lbl_1000_rr);
            tab_reservation_rr.Controls.Add(lbl_0930_rr);
            tab_reservation_rr.Controls.Add(lbl_0900_rr);
            tab_reservation_rr.Controls.Add(lbl_8030_rr);
            tab_reservation_rr.Controls.Add(lbl_saturday_rr);
            tab_reservation_rr.Controls.Add(lbl_friday_rr);
            tab_reservation_rr.Controls.Add(lbl_thursday_rr);
            tab_reservation_rr.Controls.Add(lbl_wednesday_rr);
            tab_reservation_rr.Controls.Add(lbl_tuesday_rr);
            tab_reservation_rr.Controls.Add(lbl_monday_rr);
            tab_reservation_rr.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tab_reservation_rr.ForeColor = SystemColors.ControlText;
            tab_reservation_rr.Location = new Point(4, 30);
            tab_reservation_rr.Name = "tab_reservation_rr";
            tab_reservation_rr.Padding = new Padding(3);
            tab_reservation_rr.Size = new Size(1023, 592);
            tab_reservation_rr.TabIndex = 0;
            tab_reservation_rr.Text = "Réservation";
            // 
            // dtp_reservation_rr
            // 
            dtp_reservation_rr.CalendarFont = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtp_reservation_rr.CalendarForeColor = SystemColors.Window;
            dtp_reservation_rr.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtp_reservation_rr.Format = DateTimePickerFormat.Custom;
            dtp_reservation_rr.Location = new Point(477, 16);
            dtp_reservation_rr.Margin = new Padding(3, 2, 3, 2);
            dtp_reservation_rr.MaximumSize = new Size(218, 32);
            dtp_reservation_rr.MinDate = new DateTime(2024, 1, 1, 0, 0, 0, 0);
            dtp_reservation_rr.MinimumSize = new Size(218, 32);
            dtp_reservation_rr.Name = "dtp_reservation_rr";
            dtp_reservation_rr.RightToLeft = RightToLeft.No;
            dtp_reservation_rr.Size = new Size(218, 32);
            dtp_reservation_rr.TabIndex = 2;
            dtp_reservation_rr.ValueChanged += dtp_reservation_rr_ValueChanged;
            // 
            // pnl_1830_sat_rr
            // 
            pnl_1830_sat_rr.BackColor = Color.MintCream;
            pnl_1830_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1830_sat_rr.Location = new Point(821, 552);
            pnl_1830_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1830_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1830_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1830_sat_rr.Name = "pnl_1830_sat_rr";
            pnl_1830_sat_rr.Size = new Size(133, 21);
            pnl_1830_sat_rr.TabIndex = 0;
            pnl_1830_sat_rr.MouseDoubleClick += pnl_1830_sat_rr_MouseDoubleClick;
            // 
            // pnl_1800_sat_rr
            // 
            pnl_1800_sat_rr.BackColor = Color.MintCream;
            pnl_1800_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1800_sat_rr.Location = new Point(821, 530);
            pnl_1800_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1800_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1800_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1800_sat_rr.Name = "pnl_1800_sat_rr";
            pnl_1800_sat_rr.Size = new Size(133, 21);
            pnl_1800_sat_rr.TabIndex = 0;
            pnl_1800_sat_rr.MouseDoubleClick += pnl_1800_sat_rr_MouseDoubleClick;
            // 
            // pnl_1730_sat_rr
            // 
            pnl_1730_sat_rr.BackColor = Color.MintCream;
            pnl_1730_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1730_sat_rr.Location = new Point(821, 508);
            pnl_1730_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1730_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1730_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1730_sat_rr.Name = "pnl_1730_sat_rr";
            pnl_1730_sat_rr.Size = new Size(133, 21);
            pnl_1730_sat_rr.TabIndex = 0;
            pnl_1730_sat_rr.MouseDoubleClick += pnl_1730_sat_rr_MouseDoubleClick;
            // 
            // pnl_1700_sat_rr
            // 
            pnl_1700_sat_rr.BackColor = Color.MintCream;
            pnl_1700_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1700_sat_rr.Location = new Point(821, 486);
            pnl_1700_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1700_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1700_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1700_sat_rr.Name = "pnl_1700_sat_rr";
            pnl_1700_sat_rr.Size = new Size(133, 21);
            pnl_1700_sat_rr.TabIndex = 0;
            pnl_1700_sat_rr.MouseDoubleClick += pnl_1700_sat_rr_MouseDoubleClick;
            // 
            // pnl_1630_sat_rr
            // 
            pnl_1630_sat_rr.BackColor = Color.MintCream;
            pnl_1630_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1630_sat_rr.Location = new Point(821, 464);
            pnl_1630_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1630_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1630_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1630_sat_rr.Name = "pnl_1630_sat_rr";
            pnl_1630_sat_rr.Size = new Size(133, 21);
            pnl_1630_sat_rr.TabIndex = 0;
            pnl_1630_sat_rr.MouseDoubleClick += pnl_1630_sat_rr_MouseDoubleClick;
            // 
            // pnl_1600_sat_rr
            // 
            pnl_1600_sat_rr.BackColor = Color.MintCream;
            pnl_1600_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1600_sat_rr.Location = new Point(821, 442);
            pnl_1600_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1600_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1600_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1600_sat_rr.Name = "pnl_1600_sat_rr";
            pnl_1600_sat_rr.Size = new Size(133, 21);
            pnl_1600_sat_rr.TabIndex = 0;
            pnl_1600_sat_rr.MouseDoubleClick += pnl_1600_sat_rr_MouseDoubleClick;
            // 
            // pnl_1530_sat_rr
            // 
            pnl_1530_sat_rr.BackColor = Color.MintCream;
            pnl_1530_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1530_sat_rr.Location = new Point(821, 420);
            pnl_1530_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1530_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1530_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1530_sat_rr.Name = "pnl_1530_sat_rr";
            pnl_1530_sat_rr.Size = new Size(133, 21);
            pnl_1530_sat_rr.TabIndex = 0;
            pnl_1530_sat_rr.MouseDoubleClick += pnl_1530_sat_rr_MouseDoubleClick;
            // 
            // pnl_1500_sat_rr
            // 
            pnl_1500_sat_rr.BackColor = Color.MintCream;
            pnl_1500_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1500_sat_rr.Location = new Point(821, 398);
            pnl_1500_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1500_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1500_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1500_sat_rr.Name = "pnl_1500_sat_rr";
            pnl_1500_sat_rr.Size = new Size(133, 21);
            pnl_1500_sat_rr.TabIndex = 0;
            pnl_1500_sat_rr.MouseDoubleClick += pnl_1500_sat_rr_MouseDoubleClick;
            // 
            // pnl_1430_sat_rr
            // 
            pnl_1430_sat_rr.BackColor = Color.MintCream;
            pnl_1430_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1430_sat_rr.Location = new Point(821, 376);
            pnl_1430_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1430_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1430_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1430_sat_rr.Name = "pnl_1430_sat_rr";
            pnl_1430_sat_rr.Size = new Size(133, 21);
            pnl_1430_sat_rr.TabIndex = 0;
            pnl_1430_sat_rr.MouseDoubleClick += pnl_1430_sat_rr_MouseDoubleClick;
            // 
            // pnl_1400_sat_rr
            // 
            pnl_1400_sat_rr.BackColor = Color.MintCream;
            pnl_1400_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1400_sat_rr.Location = new Point(821, 354);
            pnl_1400_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1400_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1400_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1400_sat_rr.Name = "pnl_1400_sat_rr";
            pnl_1400_sat_rr.Size = new Size(133, 21);
            pnl_1400_sat_rr.TabIndex = 0;
            pnl_1400_sat_rr.MouseDoubleClick += pnl_1400_sat_rr_MouseDoubleClick;
            // 
            // pnl_1330_sat_rr
            // 
            pnl_1330_sat_rr.BackColor = Color.MintCream;
            pnl_1330_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1330_sat_rr.Location = new Point(821, 332);
            pnl_1330_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1330_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1330_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1330_sat_rr.Name = "pnl_1330_sat_rr";
            pnl_1330_sat_rr.Size = new Size(133, 21);
            pnl_1330_sat_rr.TabIndex = 0;
            pnl_1330_sat_rr.MouseDoubleClick += pnl_1330_sat_rr_MouseDoubleClick;
            // 
            // pnl_1200_sat_rr
            // 
            pnl_1200_sat_rr.BackColor = Color.MintCream;
            pnl_1200_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1200_sat_rr.Location = new Point(821, 266);
            pnl_1200_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1200_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1200_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1200_sat_rr.Name = "pnl_1200_sat_rr";
            pnl_1200_sat_rr.Size = new Size(133, 21);
            pnl_1200_sat_rr.TabIndex = 0;
            pnl_1200_sat_rr.MouseDoubleClick += pnl_1200_sat_rr_MouseDoubleClick;
            // 
            // pnl_1300_sat_rr
            // 
            pnl_1300_sat_rr.BackColor = Color.MintCream;
            pnl_1300_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1300_sat_rr.Location = new Point(821, 310);
            pnl_1300_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1300_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1300_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1300_sat_rr.Name = "pnl_1300_sat_rr";
            pnl_1300_sat_rr.Size = new Size(133, 21);
            pnl_1300_sat_rr.TabIndex = 0;
            pnl_1300_sat_rr.MouseDoubleClick += pnl_1300_sat_rr_MouseDoubleClick;
            // 
            // pnl_1230_sat_rr
            // 
            pnl_1230_sat_rr.BackColor = Color.MintCream;
            pnl_1230_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1230_sat_rr.Location = new Point(821, 288);
            pnl_1230_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1230_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1230_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1230_sat_rr.Name = "pnl_1230_sat_rr";
            pnl_1230_sat_rr.Size = new Size(133, 21);
            pnl_1230_sat_rr.TabIndex = 0;
            pnl_1230_sat_rr.MouseDoubleClick += pnl_1230_sat_rr_MouseDoubleClick;
            // 
            // pnl_1130_sat_rr
            // 
            pnl_1130_sat_rr.BackColor = Color.MintCream;
            pnl_1130_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1130_sat_rr.Location = new Point(821, 244);
            pnl_1130_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1130_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1130_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1130_sat_rr.Name = "pnl_1130_sat_rr";
            pnl_1130_sat_rr.Size = new Size(133, 21);
            pnl_1130_sat_rr.TabIndex = 0;
            pnl_1130_sat_rr.MouseDoubleClick += pnl_1130_sat_rr_MouseDoubleClick;
            // 
            // pnl_1100_sat_rr
            // 
            pnl_1100_sat_rr.BackColor = Color.MintCream;
            pnl_1100_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1100_sat_rr.Location = new Point(821, 222);
            pnl_1100_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1100_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1100_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1100_sat_rr.Name = "pnl_1100_sat_rr";
            pnl_1100_sat_rr.Size = new Size(133, 21);
            pnl_1100_sat_rr.TabIndex = 0;
            pnl_1100_sat_rr.MouseDoubleClick += pnl_1100_sat_rr_MouseDoubleClick;
            // 
            // pnl_1030_sat_rr
            // 
            pnl_1030_sat_rr.BackColor = Color.MintCream;
            pnl_1030_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1030_sat_rr.Location = new Point(821, 200);
            pnl_1030_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1030_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1030_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1030_sat_rr.Name = "pnl_1030_sat_rr";
            pnl_1030_sat_rr.Size = new Size(133, 21);
            pnl_1030_sat_rr.TabIndex = 0;
            pnl_1030_sat_rr.MouseDoubleClick += pnl_1030_sat_rr_MouseDoubleClick;
            // 
            // pnl_1000_sat_rr
            // 
            pnl_1000_sat_rr.BackColor = Color.MintCream;
            pnl_1000_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1000_sat_rr.Location = new Point(821, 178);
            pnl_1000_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1000_sat_rr.MaximumSize = new Size(133, 21);
            pnl_1000_sat_rr.MinimumSize = new Size(133, 21);
            pnl_1000_sat_rr.Name = "pnl_1000_sat_rr";
            pnl_1000_sat_rr.Size = new Size(133, 21);
            pnl_1000_sat_rr.TabIndex = 0;
            pnl_1000_sat_rr.MouseDoubleClick += pnl_1000_sat_rr_MouseDoubleClick;
            // 
            // pnl_0930_sat_rr
            // 
            pnl_0930_sat_rr.BackColor = Color.MintCream;
            pnl_0930_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0930_sat_rr.Location = new Point(821, 156);
            pnl_0930_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0930_sat_rr.MaximumSize = new Size(133, 21);
            pnl_0930_sat_rr.MinimumSize = new Size(133, 21);
            pnl_0930_sat_rr.Name = "pnl_0930_sat_rr";
            pnl_0930_sat_rr.Size = new Size(133, 21);
            pnl_0930_sat_rr.TabIndex = 0;
            pnl_0930_sat_rr.MouseDoubleClick += pnl_0930_sat_rr_MouseDoubleClick;
            // 
            // pnl_0900_sat_rr
            // 
            pnl_0900_sat_rr.BackColor = Color.MintCream;
            pnl_0900_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0900_sat_rr.Location = new Point(821, 134);
            pnl_0900_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0900_sat_rr.MaximumSize = new Size(133, 21);
            pnl_0900_sat_rr.MinimumSize = new Size(133, 21);
            pnl_0900_sat_rr.Name = "pnl_0900_sat_rr";
            pnl_0900_sat_rr.Size = new Size(133, 21);
            pnl_0900_sat_rr.TabIndex = 0;
            pnl_0900_sat_rr.MouseDoubleClick += pnl_0900_sat_rr_MouseDoubleClick;
            // 
            // pnl_1830_fri_rr
            // 
            pnl_1830_fri_rr.BackColor = Color.MintCream;
            pnl_1830_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1830_fri_rr.Location = new Point(687, 552);
            pnl_1830_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1830_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1830_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1830_fri_rr.Name = "pnl_1830_fri_rr";
            pnl_1830_fri_rr.Size = new Size(133, 21);
            pnl_1830_fri_rr.TabIndex = 0;
            pnl_1830_fri_rr.MouseDoubleClick += pnl_1830_fri_rr_MouseDoubleClick;
            // 
            // pnl_1830_thu_rr
            // 
            pnl_1830_thu_rr.BackColor = Color.MintCream;
            pnl_1830_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1830_thu_rr.Location = new Point(553, 552);
            pnl_1830_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1830_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1830_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1830_thu_rr.Name = "pnl_1830_thu_rr";
            pnl_1830_thu_rr.Size = new Size(133, 21);
            pnl_1830_thu_rr.TabIndex = 0;
            pnl_1830_thu_rr.MouseDoubleClick += pnl_1830_thu_rr_MouseDoubleClick;
            // 
            // pnl_1800_fri_rr
            // 
            pnl_1800_fri_rr.BackColor = Color.MintCream;
            pnl_1800_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1800_fri_rr.Location = new Point(687, 530);
            pnl_1800_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1800_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1800_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1800_fri_rr.Name = "pnl_1800_fri_rr";
            pnl_1800_fri_rr.Size = new Size(133, 21);
            pnl_1800_fri_rr.TabIndex = 0;
            pnl_1800_fri_rr.MouseDoubleClick += pnl_1800_fri_rr_MouseDoubleClick;
            // 
            // pnl_1800_thu_rr
            // 
            pnl_1800_thu_rr.BackColor = Color.MintCream;
            pnl_1800_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1800_thu_rr.Location = new Point(553, 530);
            pnl_1800_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1800_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1800_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1800_thu_rr.Name = "pnl_1800_thu_rr";
            pnl_1800_thu_rr.Size = new Size(133, 21);
            pnl_1800_thu_rr.TabIndex = 0;
            pnl_1800_thu_rr.MouseDoubleClick += pnl_1800_thu_rr_MouseDoubleClick;
            // 
            // pnl_1730_fri_rr
            // 
            pnl_1730_fri_rr.BackColor = Color.MintCream;
            pnl_1730_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1730_fri_rr.Location = new Point(687, 508);
            pnl_1730_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1730_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1730_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1730_fri_rr.Name = "pnl_1730_fri_rr";
            pnl_1730_fri_rr.Size = new Size(133, 21);
            pnl_1730_fri_rr.TabIndex = 0;
            pnl_1730_fri_rr.MouseDoubleClick += pnl_1730_fri_rr_MouseDoubleClick;
            // 
            // pnl_1730_thu_rr
            // 
            pnl_1730_thu_rr.BackColor = Color.MintCream;
            pnl_1730_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1730_thu_rr.Location = new Point(553, 508);
            pnl_1730_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1730_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1730_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1730_thu_rr.Name = "pnl_1730_thu_rr";
            pnl_1730_thu_rr.Size = new Size(133, 21);
            pnl_1730_thu_rr.TabIndex = 0;
            pnl_1730_thu_rr.MouseDoubleClick += pnl_1730_thu_rr_MouseDoubleClick;
            // 
            // pnl_1700_fri_rr
            // 
            pnl_1700_fri_rr.BackColor = Color.MintCream;
            pnl_1700_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1700_fri_rr.Location = new Point(687, 486);
            pnl_1700_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1700_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1700_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1700_fri_rr.Name = "pnl_1700_fri_rr";
            pnl_1700_fri_rr.Size = new Size(133, 21);
            pnl_1700_fri_rr.TabIndex = 0;
            pnl_1700_fri_rr.MouseDoubleClick += pnl_1700_fri_rr_MouseDoubleClick;
            // 
            // pnl_1700_thu_rr
            // 
            pnl_1700_thu_rr.BackColor = Color.MintCream;
            pnl_1700_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1700_thu_rr.Location = new Point(553, 486);
            pnl_1700_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1700_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1700_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1700_thu_rr.Name = "pnl_1700_thu_rr";
            pnl_1700_thu_rr.Size = new Size(133, 21);
            pnl_1700_thu_rr.TabIndex = 0;
            pnl_1700_thu_rr.MouseDoubleClick += pnl_1700_thu_rr_MouseDoubleClick;
            // 
            // pnl_1630_fri_rr
            // 
            pnl_1630_fri_rr.BackColor = Color.MintCream;
            pnl_1630_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1630_fri_rr.Location = new Point(687, 464);
            pnl_1630_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1630_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1630_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1630_fri_rr.Name = "pnl_1630_fri_rr";
            pnl_1630_fri_rr.Size = new Size(133, 21);
            pnl_1630_fri_rr.TabIndex = 0;
            pnl_1630_fri_rr.MouseDoubleClick += pnl_1630_fri_rr_MouseDoubleClick;
            // 
            // pnl_1630_thu_rr
            // 
            pnl_1630_thu_rr.BackColor = Color.MintCream;
            pnl_1630_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1630_thu_rr.Location = new Point(553, 464);
            pnl_1630_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1630_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1630_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1630_thu_rr.Name = "pnl_1630_thu_rr";
            pnl_1630_thu_rr.Size = new Size(133, 21);
            pnl_1630_thu_rr.TabIndex = 0;
            pnl_1630_thu_rr.MouseDoubleClick += pnl_1630_thu_rr_MouseDoubleClick;
            // 
            // pnl_1600_fri_rr
            // 
            pnl_1600_fri_rr.BackColor = Color.MintCream;
            pnl_1600_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1600_fri_rr.Location = new Point(687, 442);
            pnl_1600_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1600_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1600_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1600_fri_rr.Name = "pnl_1600_fri_rr";
            pnl_1600_fri_rr.Size = new Size(133, 21);
            pnl_1600_fri_rr.TabIndex = 0;
            pnl_1600_fri_rr.MouseDoubleClick += pnl_1600_fri_rr_MouseDoubleClick;
            // 
            // pnl_1600_thu_rr
            // 
            pnl_1600_thu_rr.BackColor = Color.MintCream;
            pnl_1600_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1600_thu_rr.Location = new Point(553, 442);
            pnl_1600_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1600_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1600_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1600_thu_rr.Name = "pnl_1600_thu_rr";
            pnl_1600_thu_rr.Size = new Size(133, 21);
            pnl_1600_thu_rr.TabIndex = 0;
            pnl_1600_thu_rr.MouseDoubleClick += pnl_1600_thu_rr_MouseDoubleClick;
            // 
            // pnl_1530_fri_rr
            // 
            pnl_1530_fri_rr.BackColor = Color.MintCream;
            pnl_1530_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1530_fri_rr.Location = new Point(687, 420);
            pnl_1530_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1530_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1530_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1530_fri_rr.Name = "pnl_1530_fri_rr";
            pnl_1530_fri_rr.Size = new Size(133, 21);
            pnl_1530_fri_rr.TabIndex = 0;
            pnl_1530_fri_rr.MouseDoubleClick += pnl_1530_fri_rr_MouseDoubleClick;
            // 
            // pnl_1530_thu_rr
            // 
            pnl_1530_thu_rr.BackColor = Color.MintCream;
            pnl_1530_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1530_thu_rr.Location = new Point(553, 420);
            pnl_1530_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1530_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1530_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1530_thu_rr.Name = "pnl_1530_thu_rr";
            pnl_1530_thu_rr.Size = new Size(133, 21);
            pnl_1530_thu_rr.TabIndex = 0;
            pnl_1530_thu_rr.MouseDoubleClick += pnl_1530_thu_rr_MouseDoubleClick;
            // 
            // pnl_1500_fri_rr
            // 
            pnl_1500_fri_rr.BackColor = Color.MintCream;
            pnl_1500_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1500_fri_rr.Location = new Point(687, 398);
            pnl_1500_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1500_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1500_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1500_fri_rr.Name = "pnl_1500_fri_rr";
            pnl_1500_fri_rr.Size = new Size(133, 21);
            pnl_1500_fri_rr.TabIndex = 0;
            pnl_1500_fri_rr.MouseDoubleClick += pnl_1500_fri_rr_MouseDoubleClick;
            // 
            // pnl_1500_thu_rr
            // 
            pnl_1500_thu_rr.BackColor = Color.MintCream;
            pnl_1500_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1500_thu_rr.Location = new Point(553, 398);
            pnl_1500_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1500_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1500_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1500_thu_rr.Name = "pnl_1500_thu_rr";
            pnl_1500_thu_rr.Size = new Size(133, 21);
            pnl_1500_thu_rr.TabIndex = 0;
            pnl_1500_thu_rr.MouseDoubleClick += pnl_1500_thu_rr_MouseDoubleClick;
            // 
            // pnl_1430_fri_rr
            // 
            pnl_1430_fri_rr.BackColor = Color.MintCream;
            pnl_1430_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1430_fri_rr.Location = new Point(687, 376);
            pnl_1430_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1430_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1430_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1430_fri_rr.Name = "pnl_1430_fri_rr";
            pnl_1430_fri_rr.Size = new Size(133, 21);
            pnl_1430_fri_rr.TabIndex = 0;
            pnl_1430_fri_rr.MouseDoubleClick += pnl_1430_fri_rr_MouseDoubleClick;
            // 
            // pnl_1430_thu_rr
            // 
            pnl_1430_thu_rr.BackColor = Color.MintCream;
            pnl_1430_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1430_thu_rr.Location = new Point(553, 376);
            pnl_1430_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1430_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1430_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1430_thu_rr.Name = "pnl_1430_thu_rr";
            pnl_1430_thu_rr.Size = new Size(133, 21);
            pnl_1430_thu_rr.TabIndex = 0;
            pnl_1430_thu_rr.MouseDoubleClick += pnl_1430_thu_rr_MouseDoubleClick;
            // 
            // pnl_1400_fri_rr
            // 
            pnl_1400_fri_rr.BackColor = Color.MintCream;
            pnl_1400_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1400_fri_rr.Location = new Point(687, 354);
            pnl_1400_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1400_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1400_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1400_fri_rr.Name = "pnl_1400_fri_rr";
            pnl_1400_fri_rr.Size = new Size(133, 21);
            pnl_1400_fri_rr.TabIndex = 0;
            pnl_1400_fri_rr.MouseDoubleClick += pnl_1400_fri_rr_MouseDoubleClick;
            // 
            // pnl_1400_thu_rr
            // 
            pnl_1400_thu_rr.BackColor = Color.MintCream;
            pnl_1400_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1400_thu_rr.Location = new Point(553, 354);
            pnl_1400_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1400_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1400_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1400_thu_rr.Name = "pnl_1400_thu_rr";
            pnl_1400_thu_rr.Size = new Size(133, 21);
            pnl_1400_thu_rr.TabIndex = 0;
            pnl_1400_thu_rr.MouseDoubleClick += pnl_1400_thu_rr_MouseDoubleClick;
            // 
            // pnl_1330_fri_rr
            // 
            pnl_1330_fri_rr.BackColor = Color.MintCream;
            pnl_1330_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1330_fri_rr.Location = new Point(687, 332);
            pnl_1330_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1330_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1330_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1330_fri_rr.Name = "pnl_1330_fri_rr";
            pnl_1330_fri_rr.Size = new Size(133, 21);
            pnl_1330_fri_rr.TabIndex = 0;
            pnl_1330_fri_rr.MouseDoubleClick += pnl_1330_fri_rr_MouseDoubleClick;
            // 
            // pnl_1330_thu_rr
            // 
            pnl_1330_thu_rr.BackColor = Color.MintCream;
            pnl_1330_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1330_thu_rr.Location = new Point(553, 332);
            pnl_1330_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1330_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1330_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1330_thu_rr.Name = "pnl_1330_thu_rr";
            pnl_1330_thu_rr.Size = new Size(133, 21);
            pnl_1330_thu_rr.TabIndex = 0;
            pnl_1330_thu_rr.MouseDoubleClick += pnl_1330_thu_rr_MouseDoubleClick;
            // 
            // pnl_1200_fri_rr
            // 
            pnl_1200_fri_rr.BackColor = Color.MintCream;
            pnl_1200_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1200_fri_rr.Location = new Point(687, 266);
            pnl_1200_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1200_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1200_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1200_fri_rr.Name = "pnl_1200_fri_rr";
            pnl_1200_fri_rr.Size = new Size(133, 21);
            pnl_1200_fri_rr.TabIndex = 0;
            pnl_1200_fri_rr.MouseDoubleClick += pnl_1200_fri_rr_MouseDoubleClick;
            // 
            // pnl_1200_thu_rr
            // 
            pnl_1200_thu_rr.BackColor = Color.MintCream;
            pnl_1200_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1200_thu_rr.Location = new Point(553, 266);
            pnl_1200_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1200_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1200_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1200_thu_rr.Name = "pnl_1200_thu_rr";
            pnl_1200_thu_rr.Size = new Size(133, 21);
            pnl_1200_thu_rr.TabIndex = 0;
            pnl_1200_thu_rr.MouseDoubleClick += pnl_1200_thu_rr_MouseDoubleClick;
            // 
            // pnl_1300_fri_rr
            // 
            pnl_1300_fri_rr.BackColor = Color.MintCream;
            pnl_1300_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1300_fri_rr.Location = new Point(687, 310);
            pnl_1300_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1300_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1300_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1300_fri_rr.Name = "pnl_1300_fri_rr";
            pnl_1300_fri_rr.Size = new Size(133, 21);
            pnl_1300_fri_rr.TabIndex = 0;
            pnl_1300_fri_rr.MouseDoubleClick += pnl_1300_fri_rr_MouseDoubleClick;
            // 
            // pnl_1300_thu_rr
            // 
            pnl_1300_thu_rr.BackColor = Color.MintCream;
            pnl_1300_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1300_thu_rr.Location = new Point(553, 310);
            pnl_1300_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1300_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1300_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1300_thu_rr.Name = "pnl_1300_thu_rr";
            pnl_1300_thu_rr.Size = new Size(133, 21);
            pnl_1300_thu_rr.TabIndex = 0;
            pnl_1300_thu_rr.MouseDoubleClick += pnl_1300_thu_rr_MouseDoubleClick;
            // 
            // pnl_1230_fri_rr
            // 
            pnl_1230_fri_rr.BackColor = Color.MintCream;
            pnl_1230_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1230_fri_rr.Location = new Point(687, 288);
            pnl_1230_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1230_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1230_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1230_fri_rr.Name = "pnl_1230_fri_rr";
            pnl_1230_fri_rr.Size = new Size(133, 21);
            pnl_1230_fri_rr.TabIndex = 0;
            pnl_1230_fri_rr.MouseDoubleClick += pnl_1230_fri_rr_MouseDoubleClick;
            // 
            // pnl_1230_thu_rr
            // 
            pnl_1230_thu_rr.BackColor = Color.MintCream;
            pnl_1230_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1230_thu_rr.Location = new Point(553, 288);
            pnl_1230_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1230_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1230_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1230_thu_rr.Name = "pnl_1230_thu_rr";
            pnl_1230_thu_rr.Size = new Size(133, 21);
            pnl_1230_thu_rr.TabIndex = 0;
            pnl_1230_thu_rr.MouseDoubleClick += pnl_1230_thu_rr_MouseDoubleClick;
            // 
            // pnl_1130_fri_rr
            // 
            pnl_1130_fri_rr.BackColor = Color.MintCream;
            pnl_1130_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1130_fri_rr.Location = new Point(687, 244);
            pnl_1130_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1130_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1130_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1130_fri_rr.Name = "pnl_1130_fri_rr";
            pnl_1130_fri_rr.Size = new Size(133, 21);
            pnl_1130_fri_rr.TabIndex = 0;
            pnl_1130_fri_rr.MouseDoubleClick += pnl_1130_fri_rr_MouseDoubleClick;
            // 
            // pnl_1130_thu_rr
            // 
            pnl_1130_thu_rr.BackColor = Color.MintCream;
            pnl_1130_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1130_thu_rr.Location = new Point(553, 244);
            pnl_1130_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1130_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1130_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1130_thu_rr.Name = "pnl_1130_thu_rr";
            pnl_1130_thu_rr.Size = new Size(133, 21);
            pnl_1130_thu_rr.TabIndex = 0;
            pnl_1130_thu_rr.MouseDoubleClick += pnl_1130_thu_rr_MouseDoubleClick;
            // 
            // pnl_1100_fri_rr
            // 
            pnl_1100_fri_rr.BackColor = Color.MintCream;
            pnl_1100_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1100_fri_rr.Location = new Point(687, 222);
            pnl_1100_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1100_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1100_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1100_fri_rr.Name = "pnl_1100_fri_rr";
            pnl_1100_fri_rr.Size = new Size(133, 21);
            pnl_1100_fri_rr.TabIndex = 0;
            pnl_1100_fri_rr.MouseDoubleClick += pnl_1100_fri_rr_MouseDoubleClick;
            // 
            // pnl_1100_thu_rr
            // 
            pnl_1100_thu_rr.BackColor = Color.MintCream;
            pnl_1100_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1100_thu_rr.Location = new Point(553, 222);
            pnl_1100_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1100_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1100_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1100_thu_rr.Name = "pnl_1100_thu_rr";
            pnl_1100_thu_rr.Size = new Size(133, 21);
            pnl_1100_thu_rr.TabIndex = 0;
            pnl_1100_thu_rr.MouseDoubleClick += pnl_1100_thu_rr_MouseDoubleClick;
            // 
            // pnl_1030_fri_rr
            // 
            pnl_1030_fri_rr.BackColor = Color.MintCream;
            pnl_1030_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1030_fri_rr.Location = new Point(687, 200);
            pnl_1030_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1030_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1030_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1030_fri_rr.Name = "pnl_1030_fri_rr";
            pnl_1030_fri_rr.Size = new Size(133, 21);
            pnl_1030_fri_rr.TabIndex = 0;
            pnl_1030_fri_rr.MouseDoubleClick += pnl_1030_fri_rr_MouseDoubleClick;
            // 
            // pnl_1030_thu_rr
            // 
            pnl_1030_thu_rr.BackColor = Color.MintCream;
            pnl_1030_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1030_thu_rr.Location = new Point(553, 200);
            pnl_1030_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1030_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1030_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1030_thu_rr.Name = "pnl_1030_thu_rr";
            pnl_1030_thu_rr.Size = new Size(133, 21);
            pnl_1030_thu_rr.TabIndex = 0;
            pnl_1030_thu_rr.MouseDoubleClick += pnl_1030_thu_rr_MouseDoubleClick;
            // 
            // pnl_1000_fri_rr
            // 
            pnl_1000_fri_rr.BackColor = Color.MintCream;
            pnl_1000_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1000_fri_rr.Location = new Point(687, 178);
            pnl_1000_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1000_fri_rr.MaximumSize = new Size(133, 21);
            pnl_1000_fri_rr.MinimumSize = new Size(133, 21);
            pnl_1000_fri_rr.Name = "pnl_1000_fri_rr";
            pnl_1000_fri_rr.Size = new Size(133, 21);
            pnl_1000_fri_rr.TabIndex = 0;
            pnl_1000_fri_rr.MouseDoubleClick += pnl_1000_fri_rr_MouseDoubleClick;
            // 
            // pnl_1000_thu_rr
            // 
            pnl_1000_thu_rr.BackColor = Color.MintCream;
            pnl_1000_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1000_thu_rr.Location = new Point(553, 178);
            pnl_1000_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1000_thu_rr.MaximumSize = new Size(133, 21);
            pnl_1000_thu_rr.MinimumSize = new Size(133, 21);
            pnl_1000_thu_rr.Name = "pnl_1000_thu_rr";
            pnl_1000_thu_rr.Size = new Size(133, 21);
            pnl_1000_thu_rr.TabIndex = 0;
            pnl_1000_thu_rr.MouseDoubleClick += pnl_1000_thu_rr_MouseDoubleClick;
            // 
            // pnl_0930_fri_rr
            // 
            pnl_0930_fri_rr.BackColor = Color.MintCream;
            pnl_0930_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0930_fri_rr.Location = new Point(687, 156);
            pnl_0930_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0930_fri_rr.MaximumSize = new Size(133, 21);
            pnl_0930_fri_rr.MinimumSize = new Size(133, 21);
            pnl_0930_fri_rr.Name = "pnl_0930_fri_rr";
            pnl_0930_fri_rr.Size = new Size(133, 21);
            pnl_0930_fri_rr.TabIndex = 0;
            pnl_0930_fri_rr.MouseDoubleClick += pnl_0930_fri_rr_MouseDoubleClick;
            // 
            // pnl_0930_thu_rr
            // 
            pnl_0930_thu_rr.BackColor = Color.MintCream;
            pnl_0930_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0930_thu_rr.Location = new Point(553, 156);
            pnl_0930_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0930_thu_rr.MaximumSize = new Size(133, 21);
            pnl_0930_thu_rr.MinimumSize = new Size(133, 21);
            pnl_0930_thu_rr.Name = "pnl_0930_thu_rr";
            pnl_0930_thu_rr.Size = new Size(133, 21);
            pnl_0930_thu_rr.TabIndex = 0;
            pnl_0930_thu_rr.MouseDoubleClick += pnl_0930_thu_rr_MouseDoubleClick;
            // 
            // pnl_0900_fri_rr
            // 
            pnl_0900_fri_rr.BackColor = Color.MintCream;
            pnl_0900_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0900_fri_rr.Location = new Point(687, 134);
            pnl_0900_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0900_fri_rr.MaximumSize = new Size(133, 21);
            pnl_0900_fri_rr.MinimumSize = new Size(133, 21);
            pnl_0900_fri_rr.Name = "pnl_0900_fri_rr";
            pnl_0900_fri_rr.Size = new Size(133, 21);
            pnl_0900_fri_rr.TabIndex = 0;
            pnl_0900_fri_rr.MouseDoubleClick += pnl_0900_fri_rr_MouseDoubleClick;
            // 
            // pnl_0900_thu_rr
            // 
            pnl_0900_thu_rr.BackColor = Color.MintCream;
            pnl_0900_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0900_thu_rr.Location = new Point(553, 134);
            pnl_0900_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0900_thu_rr.MaximumSize = new Size(133, 21);
            pnl_0900_thu_rr.MinimumSize = new Size(133, 21);
            pnl_0900_thu_rr.Name = "pnl_0900_thu_rr";
            pnl_0900_thu_rr.Size = new Size(133, 21);
            pnl_0900_thu_rr.TabIndex = 0;
            pnl_0900_thu_rr.MouseDoubleClick += pnl_0900_thu_rr_MouseDoubleClick;
            // 
            // pnl_1830_wed_rr
            // 
            pnl_1830_wed_rr.BackColor = Color.MintCream;
            pnl_1830_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1830_wed_rr.Location = new Point(419, 552);
            pnl_1830_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1830_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1830_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1830_wed_rr.Name = "pnl_1830_wed_rr";
            pnl_1830_wed_rr.Size = new Size(133, 21);
            pnl_1830_wed_rr.TabIndex = 0;
            pnl_1830_wed_rr.MouseDoubleClick += pnl_1830_wen_rr_MouseDoubleClick;
            // 
            // pnl_1800_wed_rr
            // 
            pnl_1800_wed_rr.BackColor = Color.MintCream;
            pnl_1800_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1800_wed_rr.Location = new Point(419, 530);
            pnl_1800_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1800_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1800_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1800_wed_rr.Name = "pnl_1800_wed_rr";
            pnl_1800_wed_rr.Size = new Size(133, 21);
            pnl_1800_wed_rr.TabIndex = 0;
            pnl_1800_wed_rr.MouseDoubleClick += pnl_1800_wen_rr_MouseDoubleClick;
            // 
            // pnl_1730_wed_rr
            // 
            pnl_1730_wed_rr.BackColor = Color.MintCream;
            pnl_1730_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1730_wed_rr.Location = new Point(419, 508);
            pnl_1730_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1730_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1730_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1730_wed_rr.Name = "pnl_1730_wed_rr";
            pnl_1730_wed_rr.Size = new Size(133, 21);
            pnl_1730_wed_rr.TabIndex = 0;
            pnl_1730_wed_rr.MouseDoubleClick += pnl_1730_wen_rr_MouseDoubleClick;
            // 
            // pnl_1700_wed_rr
            // 
            pnl_1700_wed_rr.BackColor = Color.MintCream;
            pnl_1700_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1700_wed_rr.Location = new Point(419, 486);
            pnl_1700_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1700_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1700_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1700_wed_rr.Name = "pnl_1700_wed_rr";
            pnl_1700_wed_rr.Size = new Size(133, 21);
            pnl_1700_wed_rr.TabIndex = 0;
            pnl_1700_wed_rr.MouseDoubleClick += pnl_1700_wen_rr_MouseDoubleClick;
            // 
            // pnl_1630_wed_rr
            // 
            pnl_1630_wed_rr.BackColor = Color.MintCream;
            pnl_1630_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1630_wed_rr.Location = new Point(419, 464);
            pnl_1630_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1630_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1630_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1630_wed_rr.Name = "pnl_1630_wed_rr";
            pnl_1630_wed_rr.Size = new Size(133, 21);
            pnl_1630_wed_rr.TabIndex = 0;
            pnl_1630_wed_rr.MouseDoubleClick += pnl_1630_wen_rr_MouseDoubleClick;
            // 
            // pnl_1600_wed_rr
            // 
            pnl_1600_wed_rr.BackColor = Color.MintCream;
            pnl_1600_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1600_wed_rr.Location = new Point(419, 442);
            pnl_1600_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1600_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1600_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1600_wed_rr.Name = "pnl_1600_wed_rr";
            pnl_1600_wed_rr.Size = new Size(133, 21);
            pnl_1600_wed_rr.TabIndex = 0;
            pnl_1600_wed_rr.MouseDoubleClick += pnl_1600_wen_rr_MouseDoubleClick;
            // 
            // pnl_1530_wed_rr
            // 
            pnl_1530_wed_rr.BackColor = Color.MintCream;
            pnl_1530_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1530_wed_rr.Location = new Point(419, 420);
            pnl_1530_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1530_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1530_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1530_wed_rr.Name = "pnl_1530_wed_rr";
            pnl_1530_wed_rr.Size = new Size(133, 21);
            pnl_1530_wed_rr.TabIndex = 0;
            pnl_1530_wed_rr.MouseDoubleClick += pnl_1530_wen_rr_MouseDoubleClick;
            // 
            // pnl_1500_wed_rr
            // 
            pnl_1500_wed_rr.BackColor = Color.MintCream;
            pnl_1500_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1500_wed_rr.Location = new Point(419, 398);
            pnl_1500_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1500_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1500_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1500_wed_rr.Name = "pnl_1500_wed_rr";
            pnl_1500_wed_rr.Size = new Size(133, 21);
            pnl_1500_wed_rr.TabIndex = 0;
            pnl_1500_wed_rr.MouseDoubleClick += pnl_1500_wen_rr_MouseDoubleClick;
            // 
            // pnl_1430_wed_rr
            // 
            pnl_1430_wed_rr.BackColor = Color.MintCream;
            pnl_1430_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1430_wed_rr.Location = new Point(419, 376);
            pnl_1430_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1430_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1430_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1430_wed_rr.Name = "pnl_1430_wed_rr";
            pnl_1430_wed_rr.Size = new Size(133, 21);
            pnl_1430_wed_rr.TabIndex = 0;
            pnl_1430_wed_rr.MouseDoubleClick += pnl_1430_wen_rr_MouseDoubleClick;
            // 
            // pnl_1400_wed_rr
            // 
            pnl_1400_wed_rr.BackColor = Color.MintCream;
            pnl_1400_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1400_wed_rr.Location = new Point(419, 354);
            pnl_1400_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1400_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1400_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1400_wed_rr.Name = "pnl_1400_wed_rr";
            pnl_1400_wed_rr.Size = new Size(133, 21);
            pnl_1400_wed_rr.TabIndex = 0;
            pnl_1400_wed_rr.MouseDoubleClick += pnl_1400_wen_rr_MouseDoubleClick;
            // 
            // pnl_1330_wed_rr
            // 
            pnl_1330_wed_rr.BackColor = Color.MintCream;
            pnl_1330_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1330_wed_rr.Location = new Point(419, 332);
            pnl_1330_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1330_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1330_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1330_wed_rr.Name = "pnl_1330_wed_rr";
            pnl_1330_wed_rr.Size = new Size(133, 21);
            pnl_1330_wed_rr.TabIndex = 0;
            pnl_1330_wed_rr.MouseDoubleClick += pnl_1330_wen_rr_MouseDoubleClick;
            // 
            // pnl_1200_wed_rr
            // 
            pnl_1200_wed_rr.BackColor = Color.MintCream;
            pnl_1200_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1200_wed_rr.Location = new Point(419, 266);
            pnl_1200_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1200_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1200_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1200_wed_rr.Name = "pnl_1200_wed_rr";
            pnl_1200_wed_rr.Size = new Size(133, 21);
            pnl_1200_wed_rr.TabIndex = 0;
            pnl_1200_wed_rr.MouseDoubleClick += pnl_1200_wen_rr_MouseDoubleClick;
            // 
            // pnl_1300_wed_rr
            // 
            pnl_1300_wed_rr.BackColor = Color.MintCream;
            pnl_1300_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1300_wed_rr.Location = new Point(419, 310);
            pnl_1300_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1300_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1300_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1300_wed_rr.Name = "pnl_1300_wed_rr";
            pnl_1300_wed_rr.Size = new Size(133, 21);
            pnl_1300_wed_rr.TabIndex = 0;
            pnl_1300_wed_rr.MouseDoubleClick += pnl_1300_wen_rr_MouseDoubleClick;
            // 
            // pnl_1230_wed_rr
            // 
            pnl_1230_wed_rr.BackColor = Color.MintCream;
            pnl_1230_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1230_wed_rr.Location = new Point(419, 288);
            pnl_1230_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1230_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1230_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1230_wed_rr.Name = "pnl_1230_wed_rr";
            pnl_1230_wed_rr.Size = new Size(133, 21);
            pnl_1230_wed_rr.TabIndex = 0;
            pnl_1230_wed_rr.MouseDoubleClick += pnl_1230_wen_rr_MouseDoubleClick;
            // 
            // pnl_1130_wed_rr
            // 
            pnl_1130_wed_rr.BackColor = Color.MintCream;
            pnl_1130_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1130_wed_rr.Location = new Point(419, 244);
            pnl_1130_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1130_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1130_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1130_wed_rr.Name = "pnl_1130_wed_rr";
            pnl_1130_wed_rr.Size = new Size(133, 21);
            pnl_1130_wed_rr.TabIndex = 0;
            pnl_1130_wed_rr.MouseDoubleClick += pnl_1130_wen_rr_MouseDoubleClick;
            // 
            // pnl_1100_wed_rr
            // 
            pnl_1100_wed_rr.BackColor = Color.MintCream;
            pnl_1100_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1100_wed_rr.Location = new Point(419, 222);
            pnl_1100_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1100_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1100_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1100_wed_rr.Name = "pnl_1100_wed_rr";
            pnl_1100_wed_rr.Size = new Size(133, 21);
            pnl_1100_wed_rr.TabIndex = 0;
            pnl_1100_wed_rr.MouseDoubleClick += pnl_1100_wen_rr_MouseDoubleClick;
            // 
            // pnl_1030_wed_rr
            // 
            pnl_1030_wed_rr.BackColor = Color.MintCream;
            pnl_1030_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1030_wed_rr.Location = new Point(419, 200);
            pnl_1030_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1030_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1030_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1030_wed_rr.Name = "pnl_1030_wed_rr";
            pnl_1030_wed_rr.Size = new Size(133, 21);
            pnl_1030_wed_rr.TabIndex = 0;
            pnl_1030_wed_rr.MouseDoubleClick += pnl_1030_wen_rr_MouseDoubleClick;
            // 
            // pnl_1000_wed_rr
            // 
            pnl_1000_wed_rr.BackColor = Color.MintCream;
            pnl_1000_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1000_wed_rr.Location = new Point(419, 178);
            pnl_1000_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1000_wed_rr.MaximumSize = new Size(133, 21);
            pnl_1000_wed_rr.MinimumSize = new Size(133, 21);
            pnl_1000_wed_rr.Name = "pnl_1000_wed_rr";
            pnl_1000_wed_rr.Size = new Size(133, 21);
            pnl_1000_wed_rr.TabIndex = 0;
            pnl_1000_wed_rr.MouseDoubleClick += pnl_1000_wen_rr_MouseDoubleClick;
            // 
            // pnl_0930_wed_rr
            // 
            pnl_0930_wed_rr.BackColor = Color.MintCream;
            pnl_0930_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0930_wed_rr.Location = new Point(419, 156);
            pnl_0930_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0930_wed_rr.MaximumSize = new Size(133, 21);
            pnl_0930_wed_rr.MinimumSize = new Size(133, 21);
            pnl_0930_wed_rr.Name = "pnl_0930_wed_rr";
            pnl_0930_wed_rr.Size = new Size(133, 21);
            pnl_0930_wed_rr.TabIndex = 0;
            pnl_0930_wed_rr.MouseDoubleClick += pnl_0930_wen_rr_MouseDoubleClick;
            // 
            // pnl_0900_wed_rr
            // 
            pnl_0900_wed_rr.BackColor = Color.MintCream;
            pnl_0900_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0900_wed_rr.Location = new Point(419, 134);
            pnl_0900_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0900_wed_rr.MaximumSize = new Size(133, 21);
            pnl_0900_wed_rr.MinimumSize = new Size(133, 21);
            pnl_0900_wed_rr.Name = "pnl_0900_wed_rr";
            pnl_0900_wed_rr.Size = new Size(133, 21);
            pnl_0900_wed_rr.TabIndex = 0;
            pnl_0900_wed_rr.MouseDoubleClick += pnl_0900_wen_rr_MouseDoubleClick;
            // 
            // pnl_1830_tue_rr
            // 
            pnl_1830_tue_rr.BackColor = Color.MintCream;
            pnl_1830_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1830_tue_rr.Location = new Point(285, 552);
            pnl_1830_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1830_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1830_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1830_tue_rr.Name = "pnl_1830_tue_rr";
            pnl_1830_tue_rr.Size = new Size(133, 21);
            pnl_1830_tue_rr.TabIndex = 0;
            pnl_1830_tue_rr.MouseDoubleClick += pnl_1830_tue_rr_MouseDoubleClick;
            // 
            // pnl_1800_tue_rr
            // 
            pnl_1800_tue_rr.BackColor = Color.MintCream;
            pnl_1800_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1800_tue_rr.Location = new Point(285, 530);
            pnl_1800_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1800_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1800_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1800_tue_rr.Name = "pnl_1800_tue_rr";
            pnl_1800_tue_rr.Size = new Size(133, 21);
            pnl_1800_tue_rr.TabIndex = 0;
            pnl_1800_tue_rr.MouseDoubleClick += pnl_1800_tue_rr_MouseDoubleClick;
            // 
            // pnl_1730_tue_rr
            // 
            pnl_1730_tue_rr.BackColor = Color.MintCream;
            pnl_1730_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1730_tue_rr.Location = new Point(285, 508);
            pnl_1730_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1730_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1730_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1730_tue_rr.Name = "pnl_1730_tue_rr";
            pnl_1730_tue_rr.Size = new Size(133, 21);
            pnl_1730_tue_rr.TabIndex = 0;
            pnl_1730_tue_rr.MouseDoubleClick += pnl_1730_tue_rr_MouseDoubleClick;
            // 
            // pnl_1700_tue_rr
            // 
            pnl_1700_tue_rr.BackColor = Color.MintCream;
            pnl_1700_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1700_tue_rr.Location = new Point(285, 486);
            pnl_1700_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1700_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1700_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1700_tue_rr.Name = "pnl_1700_tue_rr";
            pnl_1700_tue_rr.Size = new Size(133, 21);
            pnl_1700_tue_rr.TabIndex = 0;
            pnl_1700_tue_rr.MouseDoubleClick += pnl_1700_tue_rr_MouseDoubleClick;
            // 
            // pnl_1630_tue_rr
            // 
            pnl_1630_tue_rr.BackColor = Color.MintCream;
            pnl_1630_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1630_tue_rr.Location = new Point(285, 464);
            pnl_1630_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1630_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1630_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1630_tue_rr.Name = "pnl_1630_tue_rr";
            pnl_1630_tue_rr.Size = new Size(133, 21);
            pnl_1630_tue_rr.TabIndex = 0;
            pnl_1630_tue_rr.MouseDoubleClick += pnl_1630_tue_rr_MouseDoubleClick;
            // 
            // pnl_1600_tue_rr
            // 
            pnl_1600_tue_rr.BackColor = Color.MintCream;
            pnl_1600_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1600_tue_rr.Location = new Point(285, 442);
            pnl_1600_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1600_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1600_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1600_tue_rr.Name = "pnl_1600_tue_rr";
            pnl_1600_tue_rr.Size = new Size(133, 21);
            pnl_1600_tue_rr.TabIndex = 0;
            pnl_1600_tue_rr.MouseDoubleClick += pnl_1600_tue_rr_MouseDoubleClick;
            // 
            // pnl_1530_tue_rr
            // 
            pnl_1530_tue_rr.BackColor = Color.MintCream;
            pnl_1530_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1530_tue_rr.Location = new Point(285, 420);
            pnl_1530_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1530_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1530_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1530_tue_rr.Name = "pnl_1530_tue_rr";
            pnl_1530_tue_rr.Size = new Size(133, 21);
            pnl_1530_tue_rr.TabIndex = 0;
            pnl_1530_tue_rr.MouseDoubleClick += pnl_1530_tue_rr_MouseDoubleClick;
            // 
            // pnl_1500_tue_rr
            // 
            pnl_1500_tue_rr.BackColor = Color.MintCream;
            pnl_1500_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1500_tue_rr.Location = new Point(285, 398);
            pnl_1500_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1500_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1500_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1500_tue_rr.Name = "pnl_1500_tue_rr";
            pnl_1500_tue_rr.Size = new Size(133, 21);
            pnl_1500_tue_rr.TabIndex = 0;
            pnl_1500_tue_rr.MouseDoubleClick += pnl_1500_tue_rr_MouseDoubleClick;
            // 
            // pnl_1430_tue_rr
            // 
            pnl_1430_tue_rr.BackColor = Color.MintCream;
            pnl_1430_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1430_tue_rr.Location = new Point(285, 376);
            pnl_1430_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1430_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1430_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1430_tue_rr.Name = "pnl_1430_tue_rr";
            pnl_1430_tue_rr.Size = new Size(133, 21);
            pnl_1430_tue_rr.TabIndex = 0;
            pnl_1430_tue_rr.MouseDoubleClick += pnl_1430_tue_rr_MouseDoubleClick;
            // 
            // pnl_1400_tue_rr
            // 
            pnl_1400_tue_rr.BackColor = Color.MintCream;
            pnl_1400_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1400_tue_rr.Location = new Point(285, 354);
            pnl_1400_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1400_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1400_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1400_tue_rr.Name = "pnl_1400_tue_rr";
            pnl_1400_tue_rr.Size = new Size(133, 21);
            pnl_1400_tue_rr.TabIndex = 0;
            pnl_1400_tue_rr.MouseDoubleClick += pnl_1400_tue_rr_MouseDoubleClick;
            // 
            // pnl_1330_tue_rr
            // 
            pnl_1330_tue_rr.BackColor = Color.MintCream;
            pnl_1330_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1330_tue_rr.Location = new Point(285, 332);
            pnl_1330_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1330_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1330_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1330_tue_rr.Name = "pnl_1330_tue_rr";
            pnl_1330_tue_rr.Size = new Size(133, 21);
            pnl_1330_tue_rr.TabIndex = 0;
            pnl_1330_tue_rr.MouseDoubleClick += pnl_1330_tue_rr_MouseDoubleClick;
            // 
            // pnl_1200_tue_rr
            // 
            pnl_1200_tue_rr.BackColor = Color.MintCream;
            pnl_1200_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1200_tue_rr.Location = new Point(285, 266);
            pnl_1200_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1200_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1200_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1200_tue_rr.Name = "pnl_1200_tue_rr";
            pnl_1200_tue_rr.Size = new Size(133, 21);
            pnl_1200_tue_rr.TabIndex = 0;
            pnl_1200_tue_rr.MouseDoubleClick += pnl_1200_tue_rr_MouseDoubleClick;
            // 
            // pnl_1300_tue_rr
            // 
            pnl_1300_tue_rr.BackColor = Color.MintCream;
            pnl_1300_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1300_tue_rr.Location = new Point(285, 310);
            pnl_1300_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1300_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1300_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1300_tue_rr.Name = "pnl_1300_tue_rr";
            pnl_1300_tue_rr.Size = new Size(133, 21);
            pnl_1300_tue_rr.TabIndex = 0;
            pnl_1300_tue_rr.MouseDoubleClick += pnl_1300_tue_rr_MouseDoubleClick;
            // 
            // pnl_1230_tue_rr
            // 
            pnl_1230_tue_rr.BackColor = Color.MintCream;
            pnl_1230_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1230_tue_rr.Location = new Point(285, 288);
            pnl_1230_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1230_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1230_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1230_tue_rr.Name = "pnl_1230_tue_rr";
            pnl_1230_tue_rr.Size = new Size(133, 21);
            pnl_1230_tue_rr.TabIndex = 0;
            pnl_1230_tue_rr.MouseDoubleClick += pnl_1230_tue_rr_MouseDoubleClick;
            // 
            // pnl_1130_tue_rr
            // 
            pnl_1130_tue_rr.BackColor = Color.MintCream;
            pnl_1130_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1130_tue_rr.Location = new Point(285, 244);
            pnl_1130_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1130_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1130_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1130_tue_rr.Name = "pnl_1130_tue_rr";
            pnl_1130_tue_rr.Size = new Size(133, 21);
            pnl_1130_tue_rr.TabIndex = 0;
            pnl_1130_tue_rr.MouseDoubleClick += pnl_1130_tue_rr_MouseDoubleClick;
            // 
            // pnl_1100_tue_rr
            // 
            pnl_1100_tue_rr.BackColor = Color.MintCream;
            pnl_1100_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1100_tue_rr.Location = new Point(285, 222);
            pnl_1100_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1100_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1100_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1100_tue_rr.Name = "pnl_1100_tue_rr";
            pnl_1100_tue_rr.Size = new Size(133, 21);
            pnl_1100_tue_rr.TabIndex = 0;
            pnl_1100_tue_rr.MouseDoubleClick += pnl_1100_tue_rr_MouseDoubleClick;
            // 
            // pnl_1030_tue_rr
            // 
            pnl_1030_tue_rr.BackColor = Color.MintCream;
            pnl_1030_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1030_tue_rr.Location = new Point(285, 200);
            pnl_1030_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1030_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1030_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1030_tue_rr.Name = "pnl_1030_tue_rr";
            pnl_1030_tue_rr.Size = new Size(133, 21);
            pnl_1030_tue_rr.TabIndex = 0;
            pnl_1030_tue_rr.MouseDoubleClick += pnl_1030_tue_rr_MouseDoubleClick;
            // 
            // pnl_1000_tue_rr
            // 
            pnl_1000_tue_rr.BackColor = Color.MintCream;
            pnl_1000_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1000_tue_rr.Location = new Point(285, 178);
            pnl_1000_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1000_tue_rr.MaximumSize = new Size(133, 21);
            pnl_1000_tue_rr.MinimumSize = new Size(133, 21);
            pnl_1000_tue_rr.Name = "pnl_1000_tue_rr";
            pnl_1000_tue_rr.Size = new Size(133, 21);
            pnl_1000_tue_rr.TabIndex = 0;
            pnl_1000_tue_rr.MouseDoubleClick += pnl_1000_tue_rr_MouseDoubleClick;
            // 
            // pnl_0930_tue_rr
            // 
            pnl_0930_tue_rr.BackColor = Color.MintCream;
            pnl_0930_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0930_tue_rr.Location = new Point(285, 156);
            pnl_0930_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0930_tue_rr.MaximumSize = new Size(133, 21);
            pnl_0930_tue_rr.MinimumSize = new Size(133, 21);
            pnl_0930_tue_rr.Name = "pnl_0930_tue_rr";
            pnl_0930_tue_rr.Size = new Size(133, 21);
            pnl_0930_tue_rr.TabIndex = 0;
            pnl_0930_tue_rr.MouseDoubleClick += pnl_0930_tue_rr_MouseDoubleClick;
            // 
            // pnl_0900_tue_rr
            // 
            pnl_0900_tue_rr.BackColor = Color.MintCream;
            pnl_0900_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0900_tue_rr.Location = new Point(285, 134);
            pnl_0900_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0900_tue_rr.MaximumSize = new Size(133, 21);
            pnl_0900_tue_rr.MinimumSize = new Size(133, 21);
            pnl_0900_tue_rr.Name = "pnl_0900_tue_rr";
            pnl_0900_tue_rr.Size = new Size(133, 21);
            pnl_0900_tue_rr.TabIndex = 0;
            pnl_0900_tue_rr.MouseDoubleClick += pnl_0900_tue_rr_MouseDoubleClick;
            // 
            // pnl_1830_mon_rr
            // 
            pnl_1830_mon_rr.BackColor = Color.MintCream;
            pnl_1830_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1830_mon_rr.Location = new Point(151, 552);
            pnl_1830_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1830_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1830_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1830_mon_rr.Name = "pnl_1830_mon_rr";
            pnl_1830_mon_rr.Size = new Size(133, 21);
            pnl_1830_mon_rr.TabIndex = 0;
            pnl_1830_mon_rr.MouseDoubleClick += pnl_1830_mon_rr_MouseDoubleClick;
            // 
            // pnl_1800_mon_rr
            // 
            pnl_1800_mon_rr.BackColor = Color.MintCream;
            pnl_1800_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1800_mon_rr.Location = new Point(151, 530);
            pnl_1800_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1800_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1800_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1800_mon_rr.Name = "pnl_1800_mon_rr";
            pnl_1800_mon_rr.Size = new Size(133, 21);
            pnl_1800_mon_rr.TabIndex = 0;
            pnl_1800_mon_rr.MouseDoubleClick += pnl_1800_mon_rr_MouseDoubleClick;
            // 
            // pnl_1730_mon_rr
            // 
            pnl_1730_mon_rr.BackColor = Color.MintCream;
            pnl_1730_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1730_mon_rr.Location = new Point(151, 508);
            pnl_1730_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1730_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1730_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1730_mon_rr.Name = "pnl_1730_mon_rr";
            pnl_1730_mon_rr.Size = new Size(133, 21);
            pnl_1730_mon_rr.TabIndex = 0;
            pnl_1730_mon_rr.MouseDoubleClick += pnl_1730_mon_rr_MouseDoubleClick;
            // 
            // pnl_1700_mon_rr
            // 
            pnl_1700_mon_rr.BackColor = Color.MintCream;
            pnl_1700_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1700_mon_rr.Location = new Point(151, 486);
            pnl_1700_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1700_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1700_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1700_mon_rr.Name = "pnl_1700_mon_rr";
            pnl_1700_mon_rr.Size = new Size(133, 21);
            pnl_1700_mon_rr.TabIndex = 0;
            pnl_1700_mon_rr.MouseDoubleClick += pnl_1700_mon_rr_MouseDoubleClick;
            // 
            // pnl_1630_mon_rr
            // 
            pnl_1630_mon_rr.BackColor = Color.MintCream;
            pnl_1630_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1630_mon_rr.Location = new Point(151, 464);
            pnl_1630_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1630_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1630_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1630_mon_rr.Name = "pnl_1630_mon_rr";
            pnl_1630_mon_rr.Size = new Size(133, 21);
            pnl_1630_mon_rr.TabIndex = 0;
            pnl_1630_mon_rr.MouseDoubleClick += pnl_1630_mon_rr_MouseDoubleClick;
            // 
            // pnl_1600_mon_rr
            // 
            pnl_1600_mon_rr.BackColor = Color.MintCream;
            pnl_1600_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1600_mon_rr.Location = new Point(151, 442);
            pnl_1600_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1600_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1600_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1600_mon_rr.Name = "pnl_1600_mon_rr";
            pnl_1600_mon_rr.Size = new Size(133, 21);
            pnl_1600_mon_rr.TabIndex = 0;
            pnl_1600_mon_rr.MouseDoubleClick += pnl_1600_mon_rr_MouseDoubleClick;
            // 
            // pnl_1530_mon_rr
            // 
            pnl_1530_mon_rr.BackColor = Color.MintCream;
            pnl_1530_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1530_mon_rr.Location = new Point(151, 420);
            pnl_1530_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1530_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1530_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1530_mon_rr.Name = "pnl_1530_mon_rr";
            pnl_1530_mon_rr.Size = new Size(133, 21);
            pnl_1530_mon_rr.TabIndex = 0;
            pnl_1530_mon_rr.MouseDoubleClick += pnl_1530_mon_rr_MouseDoubleClick;
            // 
            // pnl_1500_mon_rr
            // 
            pnl_1500_mon_rr.BackColor = Color.MintCream;
            pnl_1500_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1500_mon_rr.Location = new Point(151, 398);
            pnl_1500_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1500_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1500_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1500_mon_rr.Name = "pnl_1500_mon_rr";
            pnl_1500_mon_rr.Size = new Size(133, 21);
            pnl_1500_mon_rr.TabIndex = 0;
            pnl_1500_mon_rr.MouseDoubleClick += pnl_1500_mon_rr_MouseDoubleClick;
            // 
            // pnl_1430_mon_rr
            // 
            pnl_1430_mon_rr.BackColor = Color.MintCream;
            pnl_1430_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1430_mon_rr.Location = new Point(151, 376);
            pnl_1430_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1430_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1430_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1430_mon_rr.Name = "pnl_1430_mon_rr";
            pnl_1430_mon_rr.Size = new Size(133, 21);
            pnl_1430_mon_rr.TabIndex = 0;
            pnl_1430_mon_rr.MouseDoubleClick += pnl_1430_mon_rr_MouseDoubleClick;
            // 
            // pnl_1400_mon_rr
            // 
            pnl_1400_mon_rr.BackColor = Color.MintCream;
            pnl_1400_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1400_mon_rr.Location = new Point(151, 354);
            pnl_1400_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1400_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1400_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1400_mon_rr.Name = "pnl_1400_mon_rr";
            pnl_1400_mon_rr.Size = new Size(133, 21);
            pnl_1400_mon_rr.TabIndex = 0;
            pnl_1400_mon_rr.MouseDoubleClick += pnl_1400_mon_rr_MouseDoubleClick;
            // 
            // pnl_1330_mon_rr
            // 
            pnl_1330_mon_rr.BackColor = Color.MintCream;
            pnl_1330_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1330_mon_rr.Location = new Point(151, 332);
            pnl_1330_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1330_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1330_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1330_mon_rr.Name = "pnl_1330_mon_rr";
            pnl_1330_mon_rr.Size = new Size(133, 21);
            pnl_1330_mon_rr.TabIndex = 0;
            pnl_1330_mon_rr.MouseDoubleClick += pnl_1330_mon_rr_MouseDoubleClick;
            // 
            // pnl_1200_mon_rr
            // 
            pnl_1200_mon_rr.BackColor = Color.MintCream;
            pnl_1200_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1200_mon_rr.Location = new Point(151, 266);
            pnl_1200_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1200_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1200_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1200_mon_rr.Name = "pnl_1200_mon_rr";
            pnl_1200_mon_rr.Size = new Size(133, 21);
            pnl_1200_mon_rr.TabIndex = 0;
            pnl_1200_mon_rr.MouseDoubleClick += pnl_1200_mon_rr_MouseDoubleClick;
            // 
            // pnl_1300_mon_rr
            // 
            pnl_1300_mon_rr.BackColor = Color.MintCream;
            pnl_1300_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1300_mon_rr.Location = new Point(151, 310);
            pnl_1300_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1300_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1300_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1300_mon_rr.Name = "pnl_1300_mon_rr";
            pnl_1300_mon_rr.Size = new Size(133, 21);
            pnl_1300_mon_rr.TabIndex = 0;
            pnl_1300_mon_rr.MouseDoubleClick += pnl_1300_mon_rr_MouseDoubleClick;
            // 
            // pnl_1230_mon_rr
            // 
            pnl_1230_mon_rr.BackColor = Color.MintCream;
            pnl_1230_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1230_mon_rr.Location = new Point(151, 288);
            pnl_1230_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1230_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1230_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1230_mon_rr.Name = "pnl_1230_mon_rr";
            pnl_1230_mon_rr.Size = new Size(133, 21);
            pnl_1230_mon_rr.TabIndex = 0;
            pnl_1230_mon_rr.MouseDoubleClick += pnl_1230_mon_rr_MouseDoubleClick;
            // 
            // pnl_1130_mon_rr
            // 
            pnl_1130_mon_rr.BackColor = Color.MintCream;
            pnl_1130_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1130_mon_rr.Location = new Point(151, 244);
            pnl_1130_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1130_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1130_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1130_mon_rr.Name = "pnl_1130_mon_rr";
            pnl_1130_mon_rr.Size = new Size(133, 21);
            pnl_1130_mon_rr.TabIndex = 0;
            pnl_1130_mon_rr.MouseDoubleClick += pnl_1130_mon_rr_MouseDoubleClick;
            // 
            // pnl_1100_mon_rr
            // 
            pnl_1100_mon_rr.BackColor = Color.MintCream;
            pnl_1100_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1100_mon_rr.Location = new Point(151, 222);
            pnl_1100_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1100_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1100_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1100_mon_rr.Name = "pnl_1100_mon_rr";
            pnl_1100_mon_rr.Size = new Size(133, 21);
            pnl_1100_mon_rr.TabIndex = 0;
            pnl_1100_mon_rr.MouseDoubleClick += pnl_1100_mon_rr_MouseDoubleClick;
            // 
            // pnl_1030_mon_rr
            // 
            pnl_1030_mon_rr.BackColor = Color.MintCream;
            pnl_1030_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1030_mon_rr.Location = new Point(151, 200);
            pnl_1030_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1030_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1030_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1030_mon_rr.Name = "pnl_1030_mon_rr";
            pnl_1030_mon_rr.Size = new Size(133, 21);
            pnl_1030_mon_rr.TabIndex = 0;
            pnl_1030_mon_rr.MouseDoubleClick += pnl_1030_mon_rr_MouseDoubleClick;
            // 
            // pnl_1000_mon_rr
            // 
            pnl_1000_mon_rr.BackColor = Color.MintCream;
            pnl_1000_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_1000_mon_rr.Location = new Point(151, 178);
            pnl_1000_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_1000_mon_rr.MaximumSize = new Size(133, 21);
            pnl_1000_mon_rr.MinimumSize = new Size(133, 21);
            pnl_1000_mon_rr.Name = "pnl_1000_mon_rr";
            pnl_1000_mon_rr.Size = new Size(133, 21);
            pnl_1000_mon_rr.TabIndex = 0;
            pnl_1000_mon_rr.MouseDoubleClick += pnl_1000_mon_rr_MouseDoubleClick;
            // 
            // pnl_0930_mon_rr
            // 
            pnl_0930_mon_rr.BackColor = Color.MintCream;
            pnl_0930_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0930_mon_rr.Location = new Point(151, 156);
            pnl_0930_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0930_mon_rr.MaximumSize = new Size(133, 21);
            pnl_0930_mon_rr.MinimumSize = new Size(133, 21);
            pnl_0930_mon_rr.Name = "pnl_0930_mon_rr";
            pnl_0930_mon_rr.Size = new Size(133, 21);
            pnl_0930_mon_rr.TabIndex = 0;
            pnl_0930_mon_rr.MouseDoubleClick += pnl_0930_mon_rr_MouseDoubleClick;
            // 
            // pnl_0900_mon_rr
            // 
            pnl_0900_mon_rr.BackColor = Color.MintCream;
            pnl_0900_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0900_mon_rr.Location = new Point(151, 134);
            pnl_0900_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0900_mon_rr.MaximumSize = new Size(133, 21);
            pnl_0900_mon_rr.MinimumSize = new Size(133, 21);
            pnl_0900_mon_rr.Name = "pnl_0900_mon_rr";
            pnl_0900_mon_rr.Size = new Size(133, 21);
            pnl_0900_mon_rr.TabIndex = 0;
            pnl_0900_mon_rr.MouseDoubleClick += pnl_0900_mon_rr_MouseDoubleClick;
            // 
            // pnl_0830_sat_rr
            // 
            pnl_0830_sat_rr.BackColor = Color.MintCream;
            pnl_0830_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0830_sat_rr.Location = new Point(821, 112);
            pnl_0830_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0830_sat_rr.MaximumSize = new Size(133, 21);
            pnl_0830_sat_rr.MinimumSize = new Size(133, 21);
            pnl_0830_sat_rr.Name = "pnl_0830_sat_rr";
            pnl_0830_sat_rr.Size = new Size(133, 21);
            pnl_0830_sat_rr.TabIndex = 0;
            pnl_0830_sat_rr.MouseDoubleClick += pnl_0830_sat_rr_MouseDoubleClick;
            // 
            // pnl_0830_wed_rr
            // 
            pnl_0830_wed_rr.BackColor = Color.MintCream;
            pnl_0830_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0830_wed_rr.Location = new Point(419, 112);
            pnl_0830_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0830_wed_rr.MaximumSize = new Size(133, 21);
            pnl_0830_wed_rr.MinimumSize = new Size(133, 21);
            pnl_0830_wed_rr.Name = "pnl_0830_wed_rr";
            pnl_0830_wed_rr.Size = new Size(133, 21);
            pnl_0830_wed_rr.TabIndex = 0;
            pnl_0830_wed_rr.MouseDoubleClick += pnl_0830_wen_rr_MouseDoubleClick;
            // 
            // pnl_0830_fri_rr
            // 
            pnl_0830_fri_rr.BackColor = Color.MintCream;
            pnl_0830_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0830_fri_rr.Location = new Point(687, 112);
            pnl_0830_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0830_fri_rr.MaximumSize = new Size(133, 21);
            pnl_0830_fri_rr.MinimumSize = new Size(133, 21);
            pnl_0830_fri_rr.Name = "pnl_0830_fri_rr";
            pnl_0830_fri_rr.Size = new Size(133, 21);
            pnl_0830_fri_rr.TabIndex = 0;
            pnl_0830_fri_rr.MouseDoubleClick += pnl_0830_fri_rr_MouseDoubleClick;
            // 
            // pnl_0830_thu_rr
            // 
            pnl_0830_thu_rr.BackColor = Color.MintCream;
            pnl_0830_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0830_thu_rr.Location = new Point(553, 112);
            pnl_0830_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0830_thu_rr.MaximumSize = new Size(133, 21);
            pnl_0830_thu_rr.MinimumSize = new Size(133, 21);
            pnl_0830_thu_rr.Name = "pnl_0830_thu_rr";
            pnl_0830_thu_rr.Size = new Size(133, 21);
            pnl_0830_thu_rr.TabIndex = 0;
            pnl_0830_thu_rr.MouseDoubleClick += pnl_0830_thu_rr_MouseDoubleClick;
            // 
            // pnl_0830_tue_rr
            // 
            pnl_0830_tue_rr.BackColor = Color.MintCream;
            pnl_0830_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0830_tue_rr.Location = new Point(285, 112);
            pnl_0830_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0830_tue_rr.MaximumSize = new Size(133, 21);
            pnl_0830_tue_rr.MinimumSize = new Size(133, 21);
            pnl_0830_tue_rr.Name = "pnl_0830_tue_rr";
            pnl_0830_tue_rr.Size = new Size(133, 21);
            pnl_0830_tue_rr.TabIndex = 0;
            pnl_0830_tue_rr.MouseDoubleClick += pnl_0830_tue_rr_MouseDoubleClick;
            // 
            // pnl_0830_mon_rr
            // 
            pnl_0830_mon_rr.BackColor = Color.MintCream;
            pnl_0830_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0830_mon_rr.Location = new Point(151, 112);
            pnl_0830_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0830_mon_rr.MaximumSize = new Size(133, 21);
            pnl_0830_mon_rr.MinimumSize = new Size(133, 21);
            pnl_0830_mon_rr.Name = "pnl_0830_mon_rr";
            pnl_0830_mon_rr.Size = new Size(133, 21);
            pnl_0830_mon_rr.TabIndex = 0;
            pnl_0830_mon_rr.MouseDoubleClick += pnl_0830_mon_rr_MouseDoubleClick;
            // 
            // lbl_0800_rr
            // 
            lbl_0800_rr.AutoSize = true;
            lbl_0800_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_0800_rr.Location = new Point(70, 90);
            lbl_0800_rr.MaximumSize = new Size(49, 21);
            lbl_0800_rr.MinimumSize = new Size(49, 21);
            lbl_0800_rr.Name = "lbl_0800_rr";
            lbl_0800_rr.Size = new Size(49, 21);
            lbl_0800_rr.TabIndex = 0;
            lbl_0800_rr.Text = "08:00";
            // 
            // cmb_stylist_rr
            // 
            cmb_stylist_rr.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_stylist_rr.FormattingEnabled = true;
            cmb_stylist_rr.Location = new Point(162, 16);
            cmb_stylist_rr.Margin = new Padding(3, 2, 3, 2);
            cmb_stylist_rr.MaximumSize = new Size(191, 0);
            cmb_stylist_rr.MinimumSize = new Size(191, 0);
            cmb_stylist_rr.Name = "cmb_stylist_rr";
            cmb_stylist_rr.Size = new Size(191, 33);
            cmb_stylist_rr.TabIndex = 1;
            cmb_stylist_rr.Tag = "";
            cmb_stylist_rr.SelectedIndexChanged += cmb_stylist_rr_SelectedIndexChanged;
            // 
            // lbl_stylist_rr
            // 
            lbl_stylist_rr.AutoSize = true;
            lbl_stylist_rr.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_stylist_rr.Location = new Point(74, 20);
            lbl_stylist_rr.MaximumSize = new Size(80, 25);
            lbl_stylist_rr.MinimumSize = new Size(80, 25);
            lbl_stylist_rr.Name = "lbl_stylist_rr";
            lbl_stylist_rr.Size = new Size(80, 25);
            lbl_stylist_rr.TabIndex = 0;
            lbl_stylist_rr.Text = "Coiffeur";
            // 
            // pnl_0800_sat_rr
            // 
            pnl_0800_sat_rr.BackColor = Color.MintCream;
            pnl_0800_sat_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0800_sat_rr.Location = new Point(821, 90);
            pnl_0800_sat_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0800_sat_rr.MaximumSize = new Size(133, 21);
            pnl_0800_sat_rr.MinimumSize = new Size(133, 21);
            pnl_0800_sat_rr.Name = "pnl_0800_sat_rr";
            pnl_0800_sat_rr.Size = new Size(133, 21);
            pnl_0800_sat_rr.TabIndex = 0;
            pnl_0800_sat_rr.MouseDoubleClick += pnl_0800_sat_rr_MouseDoubleClick;
            // 
            // pnl_0800_wed_rr
            // 
            pnl_0800_wed_rr.BackColor = Color.MintCream;
            pnl_0800_wed_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0800_wed_rr.Location = new Point(419, 90);
            pnl_0800_wed_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0800_wed_rr.MaximumSize = new Size(133, 21);
            pnl_0800_wed_rr.MinimumSize = new Size(133, 21);
            pnl_0800_wed_rr.Name = "pnl_0800_wed_rr";
            pnl_0800_wed_rr.Size = new Size(133, 21);
            pnl_0800_wed_rr.TabIndex = 0;
            pnl_0800_wed_rr.MouseDoubleClick += pnl_0800_wen_rr_MouseDoubleClick;
            // 
            // pnl_0800_fri_rr
            // 
            pnl_0800_fri_rr.BackColor = Color.MintCream;
            pnl_0800_fri_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0800_fri_rr.Location = new Point(687, 90);
            pnl_0800_fri_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0800_fri_rr.MaximumSize = new Size(133, 21);
            pnl_0800_fri_rr.MinimumSize = new Size(133, 21);
            pnl_0800_fri_rr.Name = "pnl_0800_fri_rr";
            pnl_0800_fri_rr.Size = new Size(133, 21);
            pnl_0800_fri_rr.TabIndex = 0;
            pnl_0800_fri_rr.MouseDoubleClick += pnl_0800_fri_rr_MouseDoubleClick;
            // 
            // pnl_0800_thu_rr
            // 
            pnl_0800_thu_rr.BackColor = Color.MintCream;
            pnl_0800_thu_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0800_thu_rr.Location = new Point(553, 90);
            pnl_0800_thu_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0800_thu_rr.MaximumSize = new Size(133, 21);
            pnl_0800_thu_rr.MinimumSize = new Size(133, 21);
            pnl_0800_thu_rr.Name = "pnl_0800_thu_rr";
            pnl_0800_thu_rr.Size = new Size(133, 21);
            pnl_0800_thu_rr.TabIndex = 0;
            pnl_0800_thu_rr.MouseDoubleClick += pnl_0800_thu_rr_MouseDoubleClick;
            // 
            // pnl_0800_tue_rr
            // 
            pnl_0800_tue_rr.BackColor = Color.MintCream;
            pnl_0800_tue_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0800_tue_rr.Location = new Point(285, 90);
            pnl_0800_tue_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0800_tue_rr.MaximumSize = new Size(133, 21);
            pnl_0800_tue_rr.MinimumSize = new Size(133, 21);
            pnl_0800_tue_rr.Name = "pnl_0800_tue_rr";
            pnl_0800_tue_rr.Size = new Size(133, 21);
            pnl_0800_tue_rr.TabIndex = 0;
            pnl_0800_tue_rr.MouseDoubleClick += pnl_0800_tue_rr_MouseDoubleClick;
            // 
            // pnl_0800_mon_rr
            // 
            pnl_0800_mon_rr.BackColor = Color.MintCream;
            pnl_0800_mon_rr.BorderStyle = BorderStyle.FixedSingle;
            pnl_0800_mon_rr.Location = new Point(151, 90);
            pnl_0800_mon_rr.Margin = new Padding(3, 2, 3, 2);
            pnl_0800_mon_rr.MaximumSize = new Size(133, 21);
            pnl_0800_mon_rr.MinimumSize = new Size(133, 21);
            pnl_0800_mon_rr.Name = "pnl_0800_mon_rr";
            pnl_0800_mon_rr.Size = new Size(133, 21);
            pnl_0800_mon_rr.TabIndex = 0;
            pnl_0800_mon_rr.MouseDoubleClick += pnl_0800_mon_rr_MouseDoubleClick;
            // 
            // btn_add_rr
            // 
            btn_add_rr.BackColor = SystemColors.Window;
            btn_add_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_add_rr.Location = new Point(772, 14);
            btn_add_rr.MaximumSize = new Size(179, 34);
            btn_add_rr.MinimumSize = new Size(179, 34);
            btn_add_rr.Name = "btn_add_rr";
            btn_add_rr.Size = new Size(179, 34);
            btn_add_rr.TabIndex = 3;
            btn_add_rr.Text = "Nouvelle réservation";
            btn_add_rr.UseVisualStyleBackColor = false;
            btn_add_rr.Click += btn_add_rr_Click;
            // 
            // lbl_1830_rr
            // 
            lbl_1830_rr.AutoSize = true;
            lbl_1830_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1830_rr.Location = new Point(70, 551);
            lbl_1830_rr.MaximumSize = new Size(49, 21);
            lbl_1830_rr.MinimumSize = new Size(49, 21);
            lbl_1830_rr.Name = "lbl_1830_rr";
            lbl_1830_rr.Size = new Size(49, 21);
            lbl_1830_rr.TabIndex = 0;
            lbl_1830_rr.Text = "18:30";
            // 
            // lbl_1800_rr
            // 
            lbl_1800_rr.AutoSize = true;
            lbl_1800_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1800_rr.Location = new Point(70, 529);
            lbl_1800_rr.MaximumSize = new Size(49, 21);
            lbl_1800_rr.MinimumSize = new Size(49, 21);
            lbl_1800_rr.Name = "lbl_1800_rr";
            lbl_1800_rr.Size = new Size(49, 21);
            lbl_1800_rr.TabIndex = 0;
            lbl_1800_rr.Text = "18:00";
            // 
            // lbl_1730_rr
            // 
            lbl_1730_rr.AutoSize = true;
            lbl_1730_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1730_rr.Location = new Point(70, 508);
            lbl_1730_rr.MaximumSize = new Size(49, 21);
            lbl_1730_rr.MinimumSize = new Size(49, 21);
            lbl_1730_rr.Name = "lbl_1730_rr";
            lbl_1730_rr.Size = new Size(49, 21);
            lbl_1730_rr.TabIndex = 0;
            lbl_1730_rr.Text = "17:30";
            // 
            // lbl_1700_rr
            // 
            lbl_1700_rr.AutoSize = true;
            lbl_1700_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1700_rr.Location = new Point(70, 486);
            lbl_1700_rr.MaximumSize = new Size(49, 21);
            lbl_1700_rr.MinimumSize = new Size(49, 21);
            lbl_1700_rr.Name = "lbl_1700_rr";
            lbl_1700_rr.Size = new Size(49, 21);
            lbl_1700_rr.TabIndex = 0;
            lbl_1700_rr.Text = "17:00";
            // 
            // lbl_1630_rr
            // 
            lbl_1630_rr.AutoSize = true;
            lbl_1630_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1630_rr.Location = new Point(70, 463);
            lbl_1630_rr.MaximumSize = new Size(49, 21);
            lbl_1630_rr.MinimumSize = new Size(49, 21);
            lbl_1630_rr.Name = "lbl_1630_rr";
            lbl_1630_rr.Size = new Size(49, 21);
            lbl_1630_rr.TabIndex = 0;
            lbl_1630_rr.Text = "16:30";
            // 
            // lbl_1600_rr
            // 
            lbl_1600_rr.AutoSize = true;
            lbl_1600_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1600_rr.Location = new Point(70, 441);
            lbl_1600_rr.MaximumSize = new Size(49, 21);
            lbl_1600_rr.MinimumSize = new Size(49, 21);
            lbl_1600_rr.Name = "lbl_1600_rr";
            lbl_1600_rr.Size = new Size(49, 21);
            lbl_1600_rr.TabIndex = 0;
            lbl_1600_rr.Text = "16:00";
            // 
            // lbl_1530_rr
            // 
            lbl_1530_rr.AutoSize = true;
            lbl_1530_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1530_rr.Location = new Point(70, 419);
            lbl_1530_rr.MaximumSize = new Size(49, 21);
            lbl_1530_rr.MinimumSize = new Size(49, 21);
            lbl_1530_rr.Name = "lbl_1530_rr";
            lbl_1530_rr.Size = new Size(49, 21);
            lbl_1530_rr.TabIndex = 0;
            lbl_1530_rr.Text = "15:30";
            // 
            // lbl_1500_rr
            // 
            lbl_1500_rr.AutoSize = true;
            lbl_1500_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1500_rr.Location = new Point(70, 397);
            lbl_1500_rr.MaximumSize = new Size(49, 21);
            lbl_1500_rr.MinimumSize = new Size(49, 21);
            lbl_1500_rr.Name = "lbl_1500_rr";
            lbl_1500_rr.Size = new Size(49, 21);
            lbl_1500_rr.TabIndex = 0;
            lbl_1500_rr.Text = "15:00";
            // 
            // lbl_1430_rr
            // 
            lbl_1430_rr.AutoSize = true;
            lbl_1430_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1430_rr.Location = new Point(70, 375);
            lbl_1430_rr.MaximumSize = new Size(49, 21);
            lbl_1430_rr.MinimumSize = new Size(49, 21);
            lbl_1430_rr.Name = "lbl_1430_rr";
            lbl_1430_rr.Size = new Size(49, 21);
            lbl_1430_rr.TabIndex = 0;
            lbl_1430_rr.Text = "14:30";
            // 
            // lbl_1400_rr
            // 
            lbl_1400_rr.AutoSize = true;
            lbl_1400_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1400_rr.Location = new Point(70, 353);
            lbl_1400_rr.MaximumSize = new Size(49, 21);
            lbl_1400_rr.MinimumSize = new Size(49, 21);
            lbl_1400_rr.Name = "lbl_1400_rr";
            lbl_1400_rr.Size = new Size(49, 21);
            lbl_1400_rr.TabIndex = 0;
            lbl_1400_rr.Text = "14:00";
            // 
            // lbl_1330_rr
            // 
            lbl_1330_rr.AutoSize = true;
            lbl_1330_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1330_rr.Location = new Point(70, 332);
            lbl_1330_rr.MaximumSize = new Size(49, 21);
            lbl_1330_rr.MinimumSize = new Size(49, 21);
            lbl_1330_rr.Name = "lbl_1330_rr";
            lbl_1330_rr.Size = new Size(49, 21);
            lbl_1330_rr.TabIndex = 0;
            lbl_1330_rr.Text = "13:30";
            // 
            // lbl_1300_rr
            // 
            lbl_1300_rr.AutoSize = true;
            lbl_1300_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1300_rr.Location = new Point(70, 310);
            lbl_1300_rr.MaximumSize = new Size(49, 21);
            lbl_1300_rr.MinimumSize = new Size(49, 21);
            lbl_1300_rr.Name = "lbl_1300_rr";
            lbl_1300_rr.Size = new Size(49, 21);
            lbl_1300_rr.TabIndex = 0;
            lbl_1300_rr.Text = "13:00";
            // 
            // lbl_1230_rr
            // 
            lbl_1230_rr.AutoSize = true;
            lbl_1230_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1230_rr.Location = new Point(70, 287);
            lbl_1230_rr.MaximumSize = new Size(49, 21);
            lbl_1230_rr.MinimumSize = new Size(49, 21);
            lbl_1230_rr.Name = "lbl_1230_rr";
            lbl_1230_rr.Size = new Size(49, 21);
            lbl_1230_rr.TabIndex = 0;
            lbl_1230_rr.Text = "12:30";
            // 
            // lbl_1200_rr
            // 
            lbl_1200_rr.AutoSize = true;
            lbl_1200_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1200_rr.Location = new Point(70, 265);
            lbl_1200_rr.MaximumSize = new Size(49, 21);
            lbl_1200_rr.MinimumSize = new Size(49, 21);
            lbl_1200_rr.Name = "lbl_1200_rr";
            lbl_1200_rr.Size = new Size(49, 21);
            lbl_1200_rr.TabIndex = 0;
            lbl_1200_rr.Text = "12:00";
            // 
            // lbl_1130_rr
            // 
            lbl_1130_rr.AutoSize = true;
            lbl_1130_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1130_rr.Location = new Point(70, 243);
            lbl_1130_rr.MaximumSize = new Size(49, 21);
            lbl_1130_rr.MinimumSize = new Size(49, 21);
            lbl_1130_rr.Name = "lbl_1130_rr";
            lbl_1130_rr.Size = new Size(49, 21);
            lbl_1130_rr.TabIndex = 0;
            lbl_1130_rr.Text = "11:30";
            // 
            // lbl_1100_rr
            // 
            lbl_1100_rr.AutoSize = true;
            lbl_1100_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1100_rr.Location = new Point(70, 221);
            lbl_1100_rr.MaximumSize = new Size(49, 21);
            lbl_1100_rr.MinimumSize = new Size(49, 21);
            lbl_1100_rr.Name = "lbl_1100_rr";
            lbl_1100_rr.Size = new Size(49, 21);
            lbl_1100_rr.TabIndex = 0;
            lbl_1100_rr.Text = "11:00";
            // 
            // lbl_1030_rr
            // 
            lbl_1030_rr.AutoSize = true;
            lbl_1030_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1030_rr.Location = new Point(70, 200);
            lbl_1030_rr.MaximumSize = new Size(49, 21);
            lbl_1030_rr.MinimumSize = new Size(49, 21);
            lbl_1030_rr.Name = "lbl_1030_rr";
            lbl_1030_rr.Size = new Size(49, 21);
            lbl_1030_rr.TabIndex = 0;
            lbl_1030_rr.Text = "10:30";
            // 
            // lbl_1000_rr
            // 
            lbl_1000_rr.AutoSize = true;
            lbl_1000_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1000_rr.Location = new Point(70, 177);
            lbl_1000_rr.MaximumSize = new Size(49, 21);
            lbl_1000_rr.MinimumSize = new Size(49, 21);
            lbl_1000_rr.Name = "lbl_1000_rr";
            lbl_1000_rr.Size = new Size(49, 21);
            lbl_1000_rr.TabIndex = 0;
            lbl_1000_rr.Text = "10:00";
            // 
            // lbl_0930_rr
            // 
            lbl_0930_rr.AutoSize = true;
            lbl_0930_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_0930_rr.Location = new Point(70, 156);
            lbl_0930_rr.MaximumSize = new Size(49, 21);
            lbl_0930_rr.MinimumSize = new Size(49, 21);
            lbl_0930_rr.Name = "lbl_0930_rr";
            lbl_0930_rr.Size = new Size(49, 21);
            lbl_0930_rr.TabIndex = 0;
            lbl_0930_rr.Text = "09:30";
            // 
            // lbl_0900_rr
            // 
            lbl_0900_rr.AutoSize = true;
            lbl_0900_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_0900_rr.Location = new Point(70, 133);
            lbl_0900_rr.MaximumSize = new Size(49, 21);
            lbl_0900_rr.MinimumSize = new Size(49, 21);
            lbl_0900_rr.Name = "lbl_0900_rr";
            lbl_0900_rr.Size = new Size(49, 21);
            lbl_0900_rr.TabIndex = 0;
            lbl_0900_rr.Text = "09:00";
            // 
            // lbl_8030_rr
            // 
            lbl_8030_rr.AutoSize = true;
            lbl_8030_rr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_8030_rr.Location = new Point(70, 111);
            lbl_8030_rr.MaximumSize = new Size(49, 21);
            lbl_8030_rr.MinimumSize = new Size(49, 21);
            lbl_8030_rr.Name = "lbl_8030_rr";
            lbl_8030_rr.Size = new Size(49, 21);
            lbl_8030_rr.TabIndex = 0;
            lbl_8030_rr.Text = "08:30";
            // 
            // lbl_saturday_rr
            // 
            lbl_saturday_rr.AutoSize = true;
            lbl_saturday_rr.Font = new Font("Segoe UI", 12F);
            lbl_saturday_rr.Location = new Point(844, 58);
            lbl_saturday_rr.MaximumSize = new Size(62, 21);
            lbl_saturday_rr.MinimumSize = new Size(62, 21);
            lbl_saturday_rr.Name = "lbl_saturday_rr";
            lbl_saturday_rr.Size = new Size(62, 21);
            lbl_saturday_rr.TabIndex = 0;
            lbl_saturday_rr.Text = "Samedi";
            // 
            // lbl_friday_rr
            // 
            lbl_friday_rr.AutoSize = true;
            lbl_friday_rr.Font = new Font("Segoe UI", 12F);
            lbl_friday_rr.Location = new Point(710, 58);
            lbl_friday_rr.MaximumSize = new Size(72, 21);
            lbl_friday_rr.MinimumSize = new Size(72, 21);
            lbl_friday_rr.Name = "lbl_friday_rr";
            lbl_friday_rr.Size = new Size(72, 21);
            lbl_friday_rr.TabIndex = 0;
            lbl_friday_rr.Text = "Vendredi";
            // 
            // lbl_thursday_rr
            // 
            lbl_thursday_rr.AutoSize = true;
            lbl_thursday_rr.Font = new Font("Segoe UI", 12F);
            lbl_thursday_rr.Location = new Point(587, 58);
            lbl_thursday_rr.MaximumSize = new Size(46, 21);
            lbl_thursday_rr.MinimumSize = new Size(46, 21);
            lbl_thursday_rr.Name = "lbl_thursday_rr";
            lbl_thursday_rr.Size = new Size(46, 21);
            lbl_thursday_rr.TabIndex = 0;
            lbl_thursday_rr.Text = "Jeudi";
            // 
            // lbl_wednesday_rr
            // 
            lbl_wednesday_rr.AutoSize = true;
            lbl_wednesday_rr.Font = new Font("Segoe UI", 12F);
            lbl_wednesday_rr.Location = new Point(444, 58);
            lbl_wednesday_rr.MaximumSize = new Size(72, 21);
            lbl_wednesday_rr.MinimumSize = new Size(72, 21);
            lbl_wednesday_rr.Name = "lbl_wednesday_rr";
            lbl_wednesday_rr.Size = new Size(72, 21);
            lbl_wednesday_rr.TabIndex = 0;
            lbl_wednesday_rr.Text = "Mercredi";
            // 
            // lbl_tuesday_rr
            // 
            lbl_tuesday_rr.AutoSize = true;
            lbl_tuesday_rr.Font = new Font("Segoe UI", 12F);
            lbl_tuesday_rr.Location = new Point(323, 58);
            lbl_tuesday_rr.MaximumSize = new Size(51, 21);
            lbl_tuesday_rr.MinimumSize = new Size(51, 21);
            lbl_tuesday_rr.Name = "lbl_tuesday_rr";
            lbl_tuesday_rr.Size = new Size(51, 21);
            lbl_tuesday_rr.TabIndex = 0;
            lbl_tuesday_rr.Text = "Mardi";
            // 
            // lbl_monday_rr
            // 
            lbl_monday_rr.AutoSize = true;
            lbl_monday_rr.Font = new Font("Segoe UI", 12F);
            lbl_monday_rr.Location = new Point(188, 58);
            lbl_monday_rr.MaximumSize = new Size(49, 21);
            lbl_monday_rr.MinimumSize = new Size(49, 21);
            lbl_monday_rr.Name = "lbl_monday_rr";
            lbl_monday_rr.Size = new Size(49, 21);
            lbl_monday_rr.TabIndex = 0;
            lbl_monday_rr.Text = "Lundi";
            // 
            // tab_customer_rc
            // 
            tab_customer_rc.BackColor = SystemColors.Window;
            tab_customer_rc.BackgroundImageLayout = ImageLayout.Center;
            tab_customer_rc.Controls.Add(btn_cancel_rc);
            tab_customer_rc.Controls.Add(dtp_birthdate_rc);
            tab_customer_rc.Controls.Add(cmb_contact_rc);
            tab_customer_rc.Controls.Add(cmb_haircut_rc);
            tab_customer_rc.Controls.Add(btn_photo_rc);
            tab_customer_rc.Controls.Add(btn_confirm_rc);
            tab_customer_rc.Controls.Add(btn_delete_rc);
            tab_customer_rc.Controls.Add(btn_modify_rc);
            tab_customer_rc.Controls.Add(txb_haircut_rc);
            tab_customer_rc.Controls.Add(lbl_haircut_rc);
            tab_customer_rc.Controls.Add(btn_next_rc);
            tab_customer_rc.Controls.Add(btn_previous_rc);
            tab_customer_rc.Controls.Add(pic_customer_rc);
            tab_customer_rc.Controls.Add(btn_add_rc);
            tab_customer_rc.Controls.Add(lbl_search_rc);
            tab_customer_rc.Controls.Add(txb_search_rc);
            tab_customer_rc.Controls.Add(txb_npa_rc);
            tab_customer_rc.Controls.Add(txb_contact_rc);
            tab_customer_rc.Controls.Add(txb_datebirth_rc);
            tab_customer_rc.Controls.Add(txb_phone_rc);
            tab_customer_rc.Controls.Add(txb_mail_rc);
            tab_customer_rc.Controls.Add(txb_city_rc);
            tab_customer_rc.Controls.Add(txb_address_rc);
            tab_customer_rc.Controls.Add(txb_firstname_rc);
            tab_customer_rc.Controls.Add(txb_name_rc);
            tab_customer_rc.Controls.Add(lbl_npa_rc);
            tab_customer_rc.Controls.Add(lbl_contact_rc);
            tab_customer_rc.Controls.Add(lbl_birthdate_rc);
            tab_customer_rc.Controls.Add(lbl_phone_rc);
            tab_customer_rc.Controls.Add(lbl_mail_rc);
            tab_customer_rc.Controls.Add(lbl_city_rc);
            tab_customer_rc.Controls.Add(lbl_address_rc);
            tab_customer_rc.Controls.Add(lbl_firstname_rc);
            tab_customer_rc.Controls.Add(lbl_name_rc);
            tab_customer_rc.Location = new Point(4, 30);
            tab_customer_rc.Name = "tab_customer_rc";
            tab_customer_rc.Padding = new Padding(3);
            tab_customer_rc.Size = new Size(1023, 592);
            tab_customer_rc.TabIndex = 1;
            tab_customer_rc.Text = "Client";
            // 
            // btn_cancel_rc
            // 
            btn_cancel_rc.BackColor = Color.Linen;
            btn_cancel_rc.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_cancel_rc.Location = new Point(752, 532);
            btn_cancel_rc.MaximumSize = new Size(194, 35);
            btn_cancel_rc.MinimumSize = new Size(194, 35);
            btn_cancel_rc.Name = "btn_cancel_rc";
            btn_cancel_rc.Size = new Size(194, 35);
            btn_cancel_rc.TabIndex = 22;
            btn_cancel_rc.Text = "Annuler";
            btn_cancel_rc.UseVisualStyleBackColor = false;
            btn_cancel_rc.Visible = false;
            btn_cancel_rc.Click += btn_cancel_rc_Click;
            // 
            // dtp_birthdate_rc
            // 
            dtp_birthdate_rc.CustomFormat = "";
            dtp_birthdate_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtp_birthdate_rc.Format = DateTimePickerFormat.Short;
            dtp_birthdate_rc.Location = new Point(329, 428);
            dtp_birthdate_rc.Margin = new Padding(3, 2, 3, 2);
            dtp_birthdate_rc.MaximumSize = new Size(360, 39);
            dtp_birthdate_rc.MinDate = new DateTime(2024, 1, 1, 0, 0, 0, 0);
            dtp_birthdate_rc.MinimumSize = new Size(360, 39);
            dtp_birthdate_rc.Name = "dtp_birthdate_rc";
            dtp_birthdate_rc.Size = new Size(360, 39);
            dtp_birthdate_rc.TabIndex = 12;
            dtp_birthdate_rc.Visible = false;
            // 
            // cmb_contact_rc
            // 
            cmb_contact_rc.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_contact_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmb_contact_rc.FormattingEnabled = true;
            cmb_contact_rc.Items.AddRange(new object[] { "Téléphone", "Email", "Courrier", "Ne pas contacter" });
            cmb_contact_rc.Location = new Point(329, 480);
            cmb_contact_rc.Margin = new Padding(3, 2, 3, 2);
            cmb_contact_rc.MaximumSize = new Size(360, 0);
            cmb_contact_rc.MinimumSize = new Size(360, 0);
            cmb_contact_rc.Name = "cmb_contact_rc";
            cmb_contact_rc.Size = new Size(360, 40);
            cmb_contact_rc.TabIndex = 14;
            cmb_contact_rc.Visible = false;
            // 
            // cmb_haircut_rc
            // 
            cmb_haircut_rc.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_haircut_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmb_haircut_rc.FormattingEnabled = true;
            cmb_haircut_rc.Location = new Point(329, 532);
            cmb_haircut_rc.Margin = new Padding(3, 2, 3, 2);
            cmb_haircut_rc.MaximumSize = new Size(360, 0);
            cmb_haircut_rc.MinimumSize = new Size(360, 0);
            cmb_haircut_rc.Name = "cmb_haircut_rc";
            cmb_haircut_rc.Size = new Size(360, 40);
            cmb_haircut_rc.TabIndex = 16;
            cmb_haircut_rc.Visible = false;
            // 
            // btn_photo_rc
            // 
            btn_photo_rc.BackColor = SystemColors.Window;
            btn_photo_rc.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_photo_rc.Location = new Point(752, 22);
            btn_photo_rc.MaximumSize = new Size(194, 176);
            btn_photo_rc.MinimumSize = new Size(194, 176);
            btn_photo_rc.Name = "btn_photo_rc";
            btn_photo_rc.Size = new Size(194, 176);
            btn_photo_rc.TabIndex = 17;
            btn_photo_rc.Text = "Ajouter une photo";
            btn_photo_rc.UseVisualStyleBackColor = false;
            btn_photo_rc.Visible = false;
            btn_photo_rc.Click += btn_photo_rc_Click;
            // 
            // btn_confirm_rc
            // 
            btn_confirm_rc.BackColor = Color.Honeydew;
            btn_confirm_rc.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_confirm_rc.Location = new Point(752, 480);
            btn_confirm_rc.MaximumSize = new Size(194, 35);
            btn_confirm_rc.MinimumSize = new Size(194, 35);
            btn_confirm_rc.Name = "btn_confirm_rc";
            btn_confirm_rc.Size = new Size(194, 35);
            btn_confirm_rc.TabIndex = 20;
            btn_confirm_rc.Text = "Confirmer";
            btn_confirm_rc.UseVisualStyleBackColor = false;
            btn_confirm_rc.Visible = false;
            // 
            // btn_delete_rc
            // 
            btn_delete_rc.BackColor = Color.MistyRose;
            btn_delete_rc.Font = new Font("Segoe UI", 14.25F);
            btn_delete_rc.Location = new Point(752, 532);
            btn_delete_rc.MaximumSize = new Size(194, 35);
            btn_delete_rc.MinimumSize = new Size(194, 35);
            btn_delete_rc.Name = "btn_delete_rc";
            btn_delete_rc.Size = new Size(194, 35);
            btn_delete_rc.TabIndex = 21;
            btn_delete_rc.Text = "Supprimer";
            btn_delete_rc.UseVisualStyleBackColor = false;
            btn_delete_rc.Click += btn_delete_rc_Click;
            // 
            // btn_modify_rc
            // 
            btn_modify_rc.BackColor = Color.Linen;
            btn_modify_rc.Font = new Font("Segoe UI", 14.25F);
            btn_modify_rc.Location = new Point(752, 480);
            btn_modify_rc.MaximumSize = new Size(194, 35);
            btn_modify_rc.MinimumSize = new Size(194, 35);
            btn_modify_rc.Name = "btn_modify_rc";
            btn_modify_rc.Size = new Size(194, 35);
            btn_modify_rc.TabIndex = 19;
            btn_modify_rc.Text = "Modifier";
            btn_modify_rc.UseVisualStyleBackColor = false;
            btn_modify_rc.Click += btn_modify_rc_Click;
            // 
            // txb_haircut_rc
            // 
            txb_haircut_rc.BackColor = SystemColors.Window;
            txb_haircut_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_haircut_rc.Location = new Point(329, 532);
            txb_haircut_rc.MaximumSize = new Size(360, 39);
            txb_haircut_rc.MinimumSize = new Size(360, 39);
            txb_haircut_rc.Name = "txb_haircut_rc";
            txb_haircut_rc.ReadOnly = true;
            txb_haircut_rc.Size = new Size(360, 39);
            txb_haircut_rc.TabIndex = 15;
            // 
            // lbl_haircut_rc
            // 
            lbl_haircut_rc.AutoSize = true;
            lbl_haircut_rc.Font = new Font("Segoe UI", 18F);
            lbl_haircut_rc.Location = new Point(73, 532);
            lbl_haircut_rc.MaximumSize = new Size(213, 32);
            lbl_haircut_rc.MinimumSize = new Size(213, 32);
            lbl_haircut_rc.Name = "lbl_haircut_rc";
            lbl_haircut_rc.Size = new Size(213, 32);
            lbl_haircut_rc.TabIndex = 0;
            lbl_haircut_rc.Text = "Coupe de cheveux";
            // 
            // btn_next_rc
            // 
            btn_next_rc.BackColor = SystemColors.Window;
            btn_next_rc.Image = (Image)resources.GetObject("btn_next_rc.Image");
            btn_next_rc.Location = new Point(140, 56);
            btn_next_rc.MaximumSize = new Size(67, 23);
            btn_next_rc.MinimumSize = new Size(67, 23);
            btn_next_rc.Name = "btn_next_rc";
            btn_next_rc.Size = new Size(67, 23);
            btn_next_rc.TabIndex = 3;
            btn_next_rc.UseVisualStyleBackColor = false;
            // 
            // btn_previous_rc
            // 
            btn_previous_rc.BackColor = SystemColors.Window;
            btn_previous_rc.Image = (Image)resources.GetObject("btn_previous_rc.Image");
            btn_previous_rc.Location = new Point(73, 56);
            btn_previous_rc.MaximumSize = new Size(67, 23);
            btn_previous_rc.MinimumSize = new Size(67, 23);
            btn_previous_rc.Name = "btn_previous_rc";
            btn_previous_rc.Size = new Size(67, 23);
            btn_previous_rc.TabIndex = 2;
            btn_previous_rc.UseVisualStyleBackColor = false;
            // 
            // pic_customer_rc
            // 
            pic_customer_rc.BackColor = SystemColors.InactiveBorder;
            pic_customer_rc.Location = new Point(752, 22);
            pic_customer_rc.MaximumSize = new Size(194, 176);
            pic_customer_rc.MinimumSize = new Size(194, 176);
            pic_customer_rc.Name = "pic_customer_rc";
            pic_customer_rc.Size = new Size(194, 176);
            pic_customer_rc.TabIndex = 21;
            pic_customer_rc.TabStop = false;
            // 
            // btn_add_rc
            // 
            btn_add_rc.BackColor = Color.Honeydew;
            btn_add_rc.Font = new Font("Segoe UI", 14.25F);
            btn_add_rc.Location = new Point(752, 428);
            btn_add_rc.MaximumSize = new Size(194, 35);
            btn_add_rc.MinimumSize = new Size(194, 35);
            btn_add_rc.Name = "btn_add_rc";
            btn_add_rc.Size = new Size(194, 35);
            btn_add_rc.TabIndex = 18;
            btn_add_rc.Text = "Ajouter";
            btn_add_rc.UseVisualStyleBackColor = false;
            btn_add_rc.Click += btn_add_rc_Click;
            // 
            // lbl_search_rc
            // 
            lbl_search_rc.AutoSize = true;
            lbl_search_rc.Font = new Font("Segoe UI", 18F);
            lbl_search_rc.Location = new Point(73, 22);
            lbl_search_rc.MaximumSize = new Size(124, 32);
            lbl_search_rc.MinimumSize = new Size(124, 32);
            lbl_search_rc.Name = "lbl_search_rc";
            lbl_search_rc.Size = new Size(124, 32);
            lbl_search_rc.TabIndex = 0;
            lbl_search_rc.Text = "Recherche";
            // 
            // txb_search_rc
            // 
            txb_search_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_search_rc.Location = new Point(329, 22);
            txb_search_rc.MaximumSize = new Size(360, 39);
            txb_search_rc.MinimumSize = new Size(360, 39);
            txb_search_rc.Name = "txb_search_rc";
            txb_search_rc.Size = new Size(360, 39);
            txb_search_rc.TabIndex = 1;
            // 
            // txb_npa_rc
            // 
            txb_npa_rc.BackColor = SystemColors.Window;
            txb_npa_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_npa_rc.Location = new Point(801, 270);
            txb_npa_rc.MaximumSize = new Size(147, 39);
            txb_npa_rc.MinimumSize = new Size(147, 39);
            txb_npa_rc.Name = "txb_npa_rc";
            txb_npa_rc.ReadOnly = true;
            txb_npa_rc.Size = new Size(147, 39);
            txb_npa_rc.TabIndex = 8;
            // 
            // txb_contact_rc
            // 
            txb_contact_rc.BackColor = SystemColors.Window;
            txb_contact_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_contact_rc.Location = new Point(329, 480);
            txb_contact_rc.MaximumSize = new Size(360, 39);
            txb_contact_rc.MinimumSize = new Size(360, 39);
            txb_contact_rc.Name = "txb_contact_rc";
            txb_contact_rc.ReadOnly = true;
            txb_contact_rc.Size = new Size(360, 39);
            txb_contact_rc.TabIndex = 13;
            // 
            // txb_datebirth_rc
            // 
            txb_datebirth_rc.BackColor = SystemColors.Window;
            txb_datebirth_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_datebirth_rc.Location = new Point(329, 428);
            txb_datebirth_rc.MaximumSize = new Size(360, 39);
            txb_datebirth_rc.MinimumSize = new Size(360, 39);
            txb_datebirth_rc.Name = "txb_datebirth_rc";
            txb_datebirth_rc.ReadOnly = true;
            txb_datebirth_rc.Size = new Size(360, 39);
            txb_datebirth_rc.TabIndex = 11;
            // 
            // txb_phone_rc
            // 
            txb_phone_rc.BackColor = SystemColors.Window;
            txb_phone_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_phone_rc.Location = new Point(329, 322);
            txb_phone_rc.MaximumSize = new Size(617, 39);
            txb_phone_rc.MinimumSize = new Size(617, 39);
            txb_phone_rc.Name = "txb_phone_rc";
            txb_phone_rc.ReadOnly = true;
            txb_phone_rc.Size = new Size(617, 39);
            txb_phone_rc.TabIndex = 9;
            // 
            // txb_mail_rc
            // 
            txb_mail_rc.BackColor = SystemColors.Window;
            txb_mail_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_mail_rc.Location = new Point(329, 375);
            txb_mail_rc.MaximumSize = new Size(617, 39);
            txb_mail_rc.MinimumSize = new Size(617, 39);
            txb_mail_rc.Name = "txb_mail_rc";
            txb_mail_rc.ReadOnly = true;
            txb_mail_rc.Size = new Size(617, 39);
            txb_mail_rc.TabIndex = 10;
            // 
            // txb_city_rc
            // 
            txb_city_rc.BackColor = SystemColors.Window;
            txb_city_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_city_rc.Location = new Point(329, 270);
            txb_city_rc.MaximumSize = new Size(360, 39);
            txb_city_rc.MinimumSize = new Size(360, 39);
            txb_city_rc.Name = "txb_city_rc";
            txb_city_rc.ReadOnly = true;
            txb_city_rc.Size = new Size(360, 39);
            txb_city_rc.TabIndex = 7;
            // 
            // txb_address_rc
            // 
            txb_address_rc.BackColor = SystemColors.Window;
            txb_address_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_address_rc.Location = new Point(329, 218);
            txb_address_rc.Name = "txb_address_rc";
            txb_address_rc.ReadOnly = true;
            txb_address_rc.Size = new Size(617, 39);
            txb_address_rc.TabIndex = 6;
            // 
            // txb_firstname_rc
            // 
            txb_firstname_rc.BackColor = SystemColors.Window;
            txb_firstname_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_firstname_rc.Location = new Point(329, 165);
            txb_firstname_rc.MaximumSize = new Size(360, 39);
            txb_firstname_rc.MinimumSize = new Size(360, 39);
            txb_firstname_rc.Name = "txb_firstname_rc";
            txb_firstname_rc.ReadOnly = true;
            txb_firstname_rc.Size = new Size(360, 39);
            txb_firstname_rc.TabIndex = 5;
            // 
            // txb_name_rc
            // 
            txb_name_rc.BackColor = SystemColors.Window;
            txb_name_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_name_rc.Location = new Point(329, 112);
            txb_name_rc.MaximumSize = new Size(360, 39);
            txb_name_rc.MinimumSize = new Size(360, 39);
            txb_name_rc.Name = "txb_name_rc";
            txb_name_rc.ReadOnly = true;
            txb_name_rc.Size = new Size(360, 39);
            txb_name_rc.TabIndex = 4;
            // 
            // lbl_npa_rc
            // 
            lbl_npa_rc.AutoSize = true;
            lbl_npa_rc.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_npa_rc.Location = new Point(715, 270);
            lbl_npa_rc.MaximumSize = new Size(58, 32);
            lbl_npa_rc.MinimumSize = new Size(58, 32);
            lbl_npa_rc.Name = "lbl_npa_rc";
            lbl_npa_rc.Size = new Size(58, 32);
            lbl_npa_rc.TabIndex = 0;
            lbl_npa_rc.Text = "NPA";
            // 
            // lbl_contact_rc
            // 
            lbl_contact_rc.AutoSize = true;
            lbl_contact_rc.Font = new Font("Segoe UI", 18F);
            lbl_contact_rc.Location = new Point(73, 480);
            lbl_contact_rc.MaximumSize = new Size(96, 32);
            lbl_contact_rc.MinimumSize = new Size(96, 32);
            lbl_contact_rc.Name = "lbl_contact_rc";
            lbl_contact_rc.Size = new Size(96, 32);
            lbl_contact_rc.TabIndex = 0;
            lbl_contact_rc.Text = "Contact";
            // 
            // lbl_birthdate_rc
            // 
            lbl_birthdate_rc.AutoSize = true;
            lbl_birthdate_rc.Font = new Font("Segoe UI", 18F);
            lbl_birthdate_rc.Location = new Point(73, 428);
            lbl_birthdate_rc.MaximumSize = new Size(207, 32);
            lbl_birthdate_rc.MinimumSize = new Size(207, 32);
            lbl_birthdate_rc.Name = "lbl_birthdate_rc";
            lbl_birthdate_rc.Size = new Size(207, 32);
            lbl_birthdate_rc.TabIndex = 0;
            lbl_birthdate_rc.Text = "Date de naissance";
            // 
            // lbl_phone_rc
            // 
            lbl_phone_rc.AutoSize = true;
            lbl_phone_rc.Font = new Font("Segoe UI", 18F);
            lbl_phone_rc.Location = new Point(73, 322);
            lbl_phone_rc.MaximumSize = new Size(126, 32);
            lbl_phone_rc.MinimumSize = new Size(126, 32);
            lbl_phone_rc.Name = "lbl_phone_rc";
            lbl_phone_rc.Size = new Size(126, 32);
            lbl_phone_rc.TabIndex = 0;
            lbl_phone_rc.Text = "Téléphone";
            // 
            // lbl_mail_rc
            // 
            lbl_mail_rc.AutoSize = true;
            lbl_mail_rc.Font = new Font("Segoe UI", 18F);
            lbl_mail_rc.Location = new Point(73, 375);
            lbl_mail_rc.MaximumSize = new Size(71, 32);
            lbl_mail_rc.MinimumSize = new Size(71, 32);
            lbl_mail_rc.Name = "lbl_mail_rc";
            lbl_mail_rc.Size = new Size(71, 32);
            lbl_mail_rc.TabIndex = 0;
            lbl_mail_rc.Text = "Email";
            // 
            // lbl_city_rc
            // 
            lbl_city_rc.AutoSize = true;
            lbl_city_rc.Font = new Font("Segoe UI", 18F);
            lbl_city_rc.Location = new Point(73, 270);
            lbl_city_rc.MaximumSize = new Size(60, 32);
            lbl_city_rc.MinimumSize = new Size(60, 32);
            lbl_city_rc.Name = "lbl_city_rc";
            lbl_city_rc.Size = new Size(60, 32);
            lbl_city_rc.TabIndex = 0;
            lbl_city_rc.Text = "Ville";
            // 
            // lbl_address_rc
            // 
            lbl_address_rc.AutoSize = true;
            lbl_address_rc.Font = new Font("Segoe UI", 18F);
            lbl_address_rc.Location = new Point(73, 218);
            lbl_address_rc.MaximumSize = new Size(97, 32);
            lbl_address_rc.MinimumSize = new Size(97, 32);
            lbl_address_rc.Name = "lbl_address_rc";
            lbl_address_rc.Size = new Size(97, 32);
            lbl_address_rc.TabIndex = 0;
            lbl_address_rc.Text = "Adresse";
            // 
            // lbl_firstname_rc
            // 
            lbl_firstname_rc.AutoSize = true;
            lbl_firstname_rc.Font = new Font("Segoe UI", 18F);
            lbl_firstname_rc.Location = new Point(73, 165);
            lbl_firstname_rc.MaximumSize = new Size(97, 32);
            lbl_firstname_rc.MinimumSize = new Size(97, 32);
            lbl_firstname_rc.Name = "lbl_firstname_rc";
            lbl_firstname_rc.Size = new Size(97, 32);
            lbl_firstname_rc.TabIndex = 0;
            lbl_firstname_rc.Text = "Prénom";
            // 
            // lbl_name_rc
            // 
            lbl_name_rc.AutoSize = true;
            lbl_name_rc.Font = new Font("Segoe UI", 18F);
            lbl_name_rc.Location = new Point(73, 112);
            lbl_name_rc.MaximumSize = new Size(67, 32);
            lbl_name_rc.MinimumSize = new Size(67, 32);
            lbl_name_rc.Name = "lbl_name_rc";
            lbl_name_rc.Size = new Size(67, 32);
            lbl_name_rc.TabIndex = 0;
            lbl_name_rc.Text = "Nom";
            // 
            // tab_stylist_rs
            // 
            tab_stylist_rs.BackColor = SystemColors.Window;
            tab_stylist_rs.Controls.Add(btn_cancel_rs);
            tab_stylist_rs.Controls.Add(btn_photo_rs);
            tab_stylist_rs.Controls.Add(btn_confirm_rs);
            tab_stylist_rs.Controls.Add(lbl_absence_rs);
            tab_stylist_rs.Controls.Add(cmb_speciality_rs);
            tab_stylist_rs.Controls.Add(btn_next_rs);
            tab_stylist_rs.Controls.Add(btn_previous_rs);
            tab_stylist_rs.Controls.Add(btn_deleteabsence_rs);
            tab_stylist_rs.Controls.Add(btn_addabsence_rs);
            tab_stylist_rs.Controls.Add(lst_absence_rs);
            tab_stylist_rs.Controls.Add(btn_deletespeciality_rs);
            tab_stylist_rs.Controls.Add(btn_delete_rs);
            tab_stylist_rs.Controls.Add(btn_add_rs);
            tab_stylist_rs.Controls.Add(lst_speciality_rs);
            tab_stylist_rs.Controls.Add(pic_stylist_rs);
            tab_stylist_rs.Controls.Add(btn_addspeciality_rs);
            tab_stylist_rs.Controls.Add(btn_modify_rs);
            tab_stylist_rs.Controls.Add(lbl_speciality_rs);
            tab_stylist_rs.Controls.Add(lbl_search_rs);
            tab_stylist_rs.Controls.Add(txb_search_rs);
            tab_stylist_rs.Controls.Add(txb_firstname_rs);
            tab_stylist_rs.Controls.Add(txb_name_rs);
            tab_stylist_rs.Controls.Add(lbl_firstname_rs);
            tab_stylist_rs.Controls.Add(lbl_name_rs);
            tab_stylist_rs.Location = new Point(4, 30);
            tab_stylist_rs.Margin = new Padding(3, 4, 3, 4);
            tab_stylist_rs.Name = "tab_stylist_rs";
            tab_stylist_rs.Size = new Size(1023, 592);
            tab_stylist_rs.TabIndex = 2;
            tab_stylist_rs.Text = "Coiffeur";
            // 
            // btn_cancel_rs
            // 
            btn_cancel_rs.BackColor = Color.Linen;
            btn_cancel_rs.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_cancel_rs.Location = new Point(752, 532);
            btn_cancel_rs.Margin = new Padding(3, 4, 3, 4);
            btn_cancel_rs.MaximumSize = new Size(194, 35);
            btn_cancel_rs.MinimumSize = new Size(194, 35);
            btn_cancel_rs.Name = "btn_cancel_rs";
            btn_cancel_rs.Size = new Size(194, 35);
            btn_cancel_rs.TabIndex = 17;
            btn_cancel_rs.Text = "Annuler";
            btn_cancel_rs.UseVisualStyleBackColor = false;
            btn_cancel_rs.Visible = false;
            btn_cancel_rs.Click += btn_cancel_rs_Click;
            // 
            // btn_photo_rs
            // 
            btn_photo_rs.BackColor = SystemColors.Window;
            btn_photo_rs.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_photo_rs.Location = new Point(752, 22);
            btn_photo_rs.Margin = new Padding(3, 4, 3, 4);
            btn_photo_rs.MaximumSize = new Size(194, 176);
            btn_photo_rs.MinimumSize = new Size(194, 176);
            btn_photo_rs.Name = "btn_photo_rs";
            btn_photo_rs.Size = new Size(194, 176);
            btn_photo_rs.TabIndex = 13;
            btn_photo_rs.Text = "Ajouter une photo";
            btn_photo_rs.UseVisualStyleBackColor = false;
            btn_photo_rs.Visible = false;
            btn_photo_rs.Click += btn_photo_rs_Click;
            // 
            // btn_confirm_rs
            // 
            btn_confirm_rs.BackColor = Color.Honeydew;
            btn_confirm_rs.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_confirm_rs.Location = new Point(752, 480);
            btn_confirm_rs.Margin = new Padding(3, 4, 3, 4);
            btn_confirm_rs.MaximumSize = new Size(194, 35);
            btn_confirm_rs.MinimumSize = new Size(194, 35);
            btn_confirm_rs.Name = "btn_confirm_rs";
            btn_confirm_rs.Size = new Size(194, 35);
            btn_confirm_rs.TabIndex = 15;
            btn_confirm_rs.Text = "Confirmer";
            btn_confirm_rs.UseVisualStyleBackColor = false;
            btn_confirm_rs.Visible = false;
            btn_confirm_rs.Click += btn_confirm_rs_Click;
            // 
            // lbl_absence_rs
            // 
            lbl_absence_rs.AutoSize = true;
            lbl_absence_rs.Font = new Font("Segoe UI", 18F);
            lbl_absence_rs.Location = new Point(73, 428);
            lbl_absence_rs.MaximumSize = new Size(104, 32);
            lbl_absence_rs.MinimumSize = new Size(104, 32);
            lbl_absence_rs.Name = "lbl_absence_rs";
            lbl_absence_rs.Size = new Size(104, 32);
            lbl_absence_rs.TabIndex = 0;
            lbl_absence_rs.Text = "Absence";
            // 
            // cmb_speciality_rs
            // 
            cmb_speciality_rs.BackColor = SystemColors.Window;
            cmb_speciality_rs.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_speciality_rs.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmb_speciality_rs.FormattingEnabled = true;
            cmb_speciality_rs.Location = new Point(73, 323);
            cmb_speciality_rs.Margin = new Padding(3, 4, 3, 4);
            cmb_speciality_rs.MaximumSize = new Size(195, 0);
            cmb_speciality_rs.MinimumSize = new Size(195, 0);
            cmb_speciality_rs.Name = "cmb_speciality_rs";
            cmb_speciality_rs.Size = new Size(195, 29);
            cmb_speciality_rs.TabIndex = 7;
            cmb_speciality_rs.Visible = false;
            // 
            // btn_next_rs
            // 
            btn_next_rs.BackColor = SystemColors.Window;
            btn_next_rs.Image = (Image)resources.GetObject("btn_next_rs.Image");
            btn_next_rs.Location = new Point(140, 56);
            btn_next_rs.Margin = new Padding(3, 4, 3, 4);
            btn_next_rs.MaximumSize = new Size(67, 23);
            btn_next_rs.MinimumSize = new Size(67, 23);
            btn_next_rs.Name = "btn_next_rs";
            btn_next_rs.Size = new Size(67, 23);
            btn_next_rs.TabIndex = 3;
            btn_next_rs.UseVisualStyleBackColor = false;
            // 
            // btn_previous_rs
            // 
            btn_previous_rs.BackColor = SystemColors.Window;
            btn_previous_rs.Image = (Image)resources.GetObject("btn_previous_rs.Image");
            btn_previous_rs.Location = new Point(73, 56);
            btn_previous_rs.Margin = new Padding(3, 4, 3, 4);
            btn_previous_rs.MaximumSize = new Size(67, 23);
            btn_previous_rs.MinimumSize = new Size(67, 23);
            btn_previous_rs.Name = "btn_previous_rs";
            btn_previous_rs.Size = new Size(67, 23);
            btn_previous_rs.TabIndex = 2;
            btn_previous_rs.UseVisualStyleBackColor = false;
            // 
            // btn_deleteabsence_rs
            // 
            btn_deleteabsence_rs.BackColor = SystemColors.Window;
            btn_deleteabsence_rs.Font = new Font("Segoe UI", 10.2F);
            btn_deleteabsence_rs.Location = new Point(73, 527);
            btn_deleteabsence_rs.Margin = new Padding(3, 4, 3, 4);
            btn_deleteabsence_rs.MaximumSize = new Size(194, 35);
            btn_deleteabsence_rs.MinimumSize = new Size(194, 35);
            btn_deleteabsence_rs.Name = "btn_deleteabsence_rs";
            btn_deleteabsence_rs.Size = new Size(194, 35);
            btn_deleteabsence_rs.TabIndex = 12;
            btn_deleteabsence_rs.Text = "Supprimer une absence";
            btn_deleteabsence_rs.UseVisualStyleBackColor = false;
            btn_deleteabsence_rs.Visible = false;
            // 
            // btn_addabsence_rs
            // 
            btn_addabsence_rs.BackColor = SystemColors.Window;
            btn_addabsence_rs.Font = new Font("Segoe UI", 10.2F);
            btn_addabsence_rs.Location = new Point(73, 481);
            btn_addabsence_rs.Margin = new Padding(3, 4, 3, 4);
            btn_addabsence_rs.MaximumSize = new Size(194, 35);
            btn_addabsence_rs.MinimumSize = new Size(194, 35);
            btn_addabsence_rs.Name = "btn_addabsence_rs";
            btn_addabsence_rs.Size = new Size(194, 35);
            btn_addabsence_rs.TabIndex = 11;
            btn_addabsence_rs.Text = "Ajouter une absence";
            btn_addabsence_rs.UseVisualStyleBackColor = false;
            btn_addabsence_rs.Visible = false;
            btn_addabsence_rs.Click += btn_addabsence_rs_Click;
            // 
            // lst_absence_rs
            // 
            lst_absence_rs.BackColor = SystemColors.Window;
            lst_absence_rs.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lst_absence_rs.FormattingEnabled = true;
            lst_absence_rs.ItemHeight = 25;
            lst_absence_rs.Location = new Point(329, 413);
            lst_absence_rs.Margin = new Padding(3, 4, 3, 4);
            lst_absence_rs.MaximumSize = new Size(360, 154);
            lst_absence_rs.MinimumSize = new Size(360, 154);
            lst_absence_rs.Name = "lst_absence_rs";
            lst_absence_rs.Size = new Size(360, 154);
            lst_absence_rs.TabIndex = 10;
            // 
            // btn_deletespeciality_rs
            // 
            btn_deletespeciality_rs.BackColor = SystemColors.Window;
            btn_deletespeciality_rs.Font = new Font("Segoe UI", 10.2F);
            btn_deletespeciality_rs.Location = new Point(752, 357);
            btn_deletespeciality_rs.Margin = new Padding(3, 4, 3, 4);
            btn_deletespeciality_rs.MaximumSize = new Size(194, 35);
            btn_deletespeciality_rs.MinimumSize = new Size(194, 35);
            btn_deletespeciality_rs.Name = "btn_deletespeciality_rs";
            btn_deletespeciality_rs.Size = new Size(194, 35);
            btn_deletespeciality_rs.TabIndex = 9;
            btn_deletespeciality_rs.Text = "Supprimer une specialité";
            btn_deletespeciality_rs.UseVisualStyleBackColor = false;
            btn_deletespeciality_rs.Visible = false;
            // 
            // btn_delete_rs
            // 
            btn_delete_rs.BackColor = Color.MistyRose;
            btn_delete_rs.Font = new Font("Segoe UI", 14.25F);
            btn_delete_rs.Location = new Point(752, 532);
            btn_delete_rs.Margin = new Padding(3, 4, 3, 4);
            btn_delete_rs.MaximumSize = new Size(194, 35);
            btn_delete_rs.MinimumSize = new Size(194, 35);
            btn_delete_rs.Name = "btn_delete_rs";
            btn_delete_rs.Size = new Size(194, 35);
            btn_delete_rs.TabIndex = 18;
            btn_delete_rs.Text = "Supprimer";
            btn_delete_rs.UseVisualStyleBackColor = false;
            btn_delete_rs.Click += btn_delete_rs_Click;
            // 
            // btn_add_rs
            // 
            btn_add_rs.BackColor = Color.Honeydew;
            btn_add_rs.Font = new Font("Segoe UI", 14.25F);
            btn_add_rs.Location = new Point(752, 428);
            btn_add_rs.Margin = new Padding(3, 4, 3, 4);
            btn_add_rs.MaximumSize = new Size(194, 35);
            btn_add_rs.MinimumSize = new Size(194, 35);
            btn_add_rs.Name = "btn_add_rs";
            btn_add_rs.Size = new Size(194, 35);
            btn_add_rs.TabIndex = 14;
            btn_add_rs.Text = "Ajouter";
            btn_add_rs.UseVisualStyleBackColor = false;
            btn_add_rs.Click += btn_add_rs_Click;
            // 
            // lst_speciality_rs
            // 
            lst_speciality_rs.BackColor = SystemColors.Window;
            lst_speciality_rs.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lst_speciality_rs.FormattingEnabled = true;
            lst_speciality_rs.ItemHeight = 25;
            lst_speciality_rs.Location = new Point(329, 218);
            lst_speciality_rs.Margin = new Padding(3, 4, 3, 4);
            lst_speciality_rs.MaximumSize = new Size(360, 179);
            lst_speciality_rs.MinimumSize = new Size(360, 179);
            lst_speciality_rs.Name = "lst_speciality_rs";
            lst_speciality_rs.Size = new Size(360, 179);
            lst_speciality_rs.TabIndex = 6;
            // 
            // pic_stylist_rs
            // 
            pic_stylist_rs.BackColor = SystemColors.InactiveBorder;
            pic_stylist_rs.Location = new Point(752, 22);
            pic_stylist_rs.Margin = new Padding(3, 4, 3, 4);
            pic_stylist_rs.MaximumSize = new Size(194, 176);
            pic_stylist_rs.MinimumSize = new Size(194, 176);
            pic_stylist_rs.Name = "pic_stylist_rs";
            pic_stylist_rs.Size = new Size(194, 176);
            pic_stylist_rs.TabIndex = 30;
            pic_stylist_rs.TabStop = false;
            // 
            // btn_addspeciality_rs
            // 
            btn_addspeciality_rs.BackColor = SystemColors.Window;
            btn_addspeciality_rs.Font = new Font("Segoe UI", 10.2F);
            btn_addspeciality_rs.Location = new Point(73, 357);
            btn_addspeciality_rs.Margin = new Padding(3, 4, 3, 4);
            btn_addspeciality_rs.MaximumSize = new Size(194, 35);
            btn_addspeciality_rs.MinimumSize = new Size(194, 35);
            btn_addspeciality_rs.Name = "btn_addspeciality_rs";
            btn_addspeciality_rs.Size = new Size(194, 35);
            btn_addspeciality_rs.TabIndex = 8;
            btn_addspeciality_rs.Text = "Ajouter une specialité";
            btn_addspeciality_rs.UseVisualStyleBackColor = false;
            btn_addspeciality_rs.Visible = false;
            btn_addspeciality_rs.Click += btn_addspeciality_rs_Click;
            // 
            // btn_modify_rs
            // 
            btn_modify_rs.BackColor = Color.Linen;
            btn_modify_rs.Font = new Font("Segoe UI", 14.25F);
            btn_modify_rs.Location = new Point(752, 480);
            btn_modify_rs.Margin = new Padding(3, 4, 3, 4);
            btn_modify_rs.MaximumSize = new Size(194, 35);
            btn_modify_rs.MinimumSize = new Size(194, 35);
            btn_modify_rs.Name = "btn_modify_rs";
            btn_modify_rs.Size = new Size(194, 35);
            btn_modify_rs.TabIndex = 16;
            btn_modify_rs.Text = "Modifier";
            btn_modify_rs.UseVisualStyleBackColor = false;
            btn_modify_rs.Click += btn_modify_rs_Click;
            // 
            // lbl_speciality_rs
            // 
            lbl_speciality_rs.AutoSize = true;
            lbl_speciality_rs.Font = new Font("Segoe UI", 18F);
            lbl_speciality_rs.Location = new Point(73, 218);
            lbl_speciality_rs.MaximumSize = new Size(116, 32);
            lbl_speciality_rs.MinimumSize = new Size(116, 32);
            lbl_speciality_rs.Name = "lbl_speciality_rs";
            lbl_speciality_rs.Size = new Size(116, 32);
            lbl_speciality_rs.TabIndex = 0;
            lbl_speciality_rs.Text = "Spécialité";
            // 
            // lbl_search_rs
            // 
            lbl_search_rs.AutoSize = true;
            lbl_search_rs.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_search_rs.Location = new Point(73, 22);
            lbl_search_rs.MaximumSize = new Size(124, 32);
            lbl_search_rs.MinimumSize = new Size(124, 32);
            lbl_search_rs.Name = "lbl_search_rs";
            lbl_search_rs.Size = new Size(124, 32);
            lbl_search_rs.TabIndex = 0;
            lbl_search_rs.Text = "Recherche";
            // 
            // txb_search_rs
            // 
            txb_search_rs.BackColor = SystemColors.Window;
            txb_search_rs.Font = new Font("Segoe UI", 18F);
            txb_search_rs.Location = new Point(329, 22);
            txb_search_rs.Margin = new Padding(3, 4, 3, 4);
            txb_search_rs.MaximumSize = new Size(360, 39);
            txb_search_rs.MinimumSize = new Size(360, 39);
            txb_search_rs.Name = "txb_search_rs";
            txb_search_rs.Size = new Size(360, 39);
            txb_search_rs.TabIndex = 1;
            // 
            // txb_firstname_rs
            // 
            txb_firstname_rs.BackColor = SystemColors.Window;
            txb_firstname_rs.Font = new Font("Segoe UI", 18F);
            txb_firstname_rs.Location = new Point(329, 165);
            txb_firstname_rs.Margin = new Padding(3, 4, 3, 4);
            txb_firstname_rs.MaximumSize = new Size(360, 39);
            txb_firstname_rs.MinimumSize = new Size(360, 39);
            txb_firstname_rs.Name = "txb_firstname_rs";
            txb_firstname_rs.ReadOnly = true;
            txb_firstname_rs.Size = new Size(360, 39);
            txb_firstname_rs.TabIndex = 5;
            // 
            // txb_name_rs
            // 
            txb_name_rs.BackColor = SystemColors.Window;
            txb_name_rs.Font = new Font("Segoe UI", 18F);
            txb_name_rs.Location = new Point(329, 112);
            txb_name_rs.Margin = new Padding(3, 4, 3, 4);
            txb_name_rs.MaximumSize = new Size(360, 39);
            txb_name_rs.MinimumSize = new Size(360, 39);
            txb_name_rs.Name = "txb_name_rs";
            txb_name_rs.ReadOnly = true;
            txb_name_rs.Size = new Size(360, 39);
            txb_name_rs.TabIndex = 4;
            // 
            // lbl_firstname_rs
            // 
            lbl_firstname_rs.AutoSize = true;
            lbl_firstname_rs.Font = new Font("Segoe UI", 18F);
            lbl_firstname_rs.Location = new Point(73, 165);
            lbl_firstname_rs.MaximumSize = new Size(97, 32);
            lbl_firstname_rs.MinimumSize = new Size(97, 32);
            lbl_firstname_rs.Name = "lbl_firstname_rs";
            lbl_firstname_rs.Size = new Size(97, 32);
            lbl_firstname_rs.TabIndex = 0;
            lbl_firstname_rs.Text = "Prénom";
            // 
            // lbl_name_rs
            // 
            lbl_name_rs.AutoSize = true;
            lbl_name_rs.Font = new Font("Segoe UI", 18F);
            lbl_name_rs.Location = new Point(73, 112);
            lbl_name_rs.MaximumSize = new Size(67, 32);
            lbl_name_rs.MinimumSize = new Size(67, 32);
            lbl_name_rs.Name = "lbl_name_rs";
            lbl_name_rs.Size = new Size(67, 32);
            lbl_name_rs.TabIndex = 0;
            lbl_name_rs.Text = "Nom";
            // 
            // tab_haircut_rh
            // 
            tab_haircut_rh.BackColor = SystemColors.Window;
            tab_haircut_rh.Controls.Add(cmb_cuttingtime_rh);
            tab_haircut_rh.Controls.Add(btn_cancel_rh);
            tab_haircut_rh.Controls.Add(cmb_shortlong_rh);
            tab_haircut_rh.Controls.Add(btn_photo_rh);
            tab_haircut_rh.Controls.Add(btn_confirm_rh);
            tab_haircut_rh.Controls.Add(txb_price_rh);
            tab_haircut_rh.Controls.Add(lbl_price_rh);
            tab_haircut_rh.Controls.Add(btn_next_rh);
            tab_haircut_rh.Controls.Add(btn_previous_rh);
            tab_haircut_rh.Controls.Add(btn_delete_rh);
            tab_haircut_rh.Controls.Add(btn_modify_rh);
            tab_haircut_rh.Controls.Add(btn_add_rh);
            tab_haircut_rh.Controls.Add(txb_shortlong_rh);
            tab_haircut_rh.Controls.Add(lbl_shortlong_rh);
            tab_haircut_rh.Controls.Add(pic_haircut_rh);
            tab_haircut_rh.Controls.Add(txb_cuttingtime_rh);
            tab_haircut_rh.Controls.Add(txb_description_rh);
            tab_haircut_rh.Controls.Add(lbl_cuttingtime_rh);
            tab_haircut_rh.Controls.Add(txb_name_rh);
            tab_haircut_rh.Controls.Add(lbl_description_rh);
            tab_haircut_rh.Controls.Add(lbl_name_rh);
            tab_haircut_rh.Controls.Add(lbl_search_rh);
            tab_haircut_rh.Controls.Add(txb_search_rh);
            tab_haircut_rh.Location = new Point(4, 30);
            tab_haircut_rh.Name = "tab_haircut_rh";
            tab_haircut_rh.Size = new Size(1023, 592);
            tab_haircut_rh.TabIndex = 3;
            tab_haircut_rh.Text = "Coupe de cheveux";
            // 
            // cmb_cuttingtime_rh
            // 
            cmb_cuttingtime_rh.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_cuttingtime_rh.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmb_cuttingtime_rh.FormattingEnabled = true;
            cmb_cuttingtime_rh.Items.AddRange(new object[] { "  30 min" });
            cmb_cuttingtime_rh.Location = new Point(329, 428);
            cmb_cuttingtime_rh.Margin = new Padding(3, 2, 3, 2);
            cmb_cuttingtime_rh.MaximumSize = new Size(360, 0);
            cmb_cuttingtime_rh.MinimumSize = new Size(360, 0);
            cmb_cuttingtime_rh.Name = "cmb_cuttingtime_rh";
            cmb_cuttingtime_rh.Size = new Size(360, 40);
            cmb_cuttingtime_rh.TabIndex = 7;
            cmb_cuttingtime_rh.Visible = false;
            // 
            // btn_cancel_rh
            // 
            btn_cancel_rh.BackColor = Color.Linen;
            btn_cancel_rh.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_cancel_rh.Location = new Point(752, 532);
            btn_cancel_rh.MaximumSize = new Size(194, 35);
            btn_cancel_rh.MinimumSize = new Size(194, 35);
            btn_cancel_rh.Name = "btn_cancel_rh";
            btn_cancel_rh.Size = new Size(194, 35);
            btn_cancel_rh.TabIndex = 16;
            btn_cancel_rh.Text = "Annuler";
            btn_cancel_rh.UseVisualStyleBackColor = false;
            btn_cancel_rh.Visible = false;
            btn_cancel_rh.Click += btn_cancel_rh_Click;
            // 
            // cmb_shortlong_rh
            // 
            cmb_shortlong_rh.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_shortlong_rh.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmb_shortlong_rh.FormattingEnabled = true;
            cmb_shortlong_rh.Items.AddRange(new object[] { "Cheveux court", "Cheveux long" });
            cmb_shortlong_rh.Location = new Point(329, 480);
            cmb_shortlong_rh.Margin = new Padding(3, 2, 3, 2);
            cmb_shortlong_rh.MaximumSize = new Size(360, 0);
            cmb_shortlong_rh.MinimumSize = new Size(360, 0);
            cmb_shortlong_rh.Name = "cmb_shortlong_rh";
            cmb_shortlong_rh.Size = new Size(360, 40);
            cmb_shortlong_rh.TabIndex = 9;
            cmb_shortlong_rh.Visible = false;
            // 
            // btn_photo_rh
            // 
            btn_photo_rh.BackColor = SystemColors.Window;
            btn_photo_rh.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_photo_rh.Location = new Point(752, 22);
            btn_photo_rh.MaximumSize = new Size(194, 176);
            btn_photo_rh.MinimumSize = new Size(194, 176);
            btn_photo_rh.Name = "btn_photo_rh";
            btn_photo_rh.Size = new Size(194, 176);
            btn_photo_rh.TabIndex = 11;
            btn_photo_rh.Text = "Ajouter une photo";
            btn_photo_rh.UseVisualStyleBackColor = false;
            btn_photo_rh.Visible = false;
            btn_photo_rh.Click += btn_photo_rh_Click;
            // 
            // btn_confirm_rh
            // 
            btn_confirm_rh.BackColor = Color.Honeydew;
            btn_confirm_rh.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btn_confirm_rh.Location = new Point(752, 480);
            btn_confirm_rh.MaximumSize = new Size(194, 35);
            btn_confirm_rh.MinimumSize = new Size(194, 35);
            btn_confirm_rh.Name = "btn_confirm_rh";
            btn_confirm_rh.Size = new Size(194, 35);
            btn_confirm_rh.TabIndex = 14;
            btn_confirm_rh.Text = "Confirmer";
            btn_confirm_rh.UseVisualStyleBackColor = false;
            btn_confirm_rh.Visible = false;
            btn_confirm_rh.Click += btn_confirm_rh_Click;
            // 
            // txb_price_rh
            // 
            txb_price_rh.BackColor = SystemColors.Window;
            txb_price_rh.Font = new Font("Segoe UI", 18F);
            txb_price_rh.Location = new Point(329, 532);
            txb_price_rh.MaximumSize = new Size(360, 39);
            txb_price_rh.MinimumSize = new Size(360, 39);
            txb_price_rh.Name = "txb_price_rh";
            txb_price_rh.ReadOnly = true;
            txb_price_rh.Size = new Size(360, 39);
            txb_price_rh.TabIndex = 10;
            // 
            // lbl_price_rh
            // 
            lbl_price_rh.AutoSize = true;
            lbl_price_rh.Font = new Font("Segoe UI", 18F);
            lbl_price_rh.Location = new Point(73, 532);
            lbl_price_rh.MaximumSize = new Size(52, 32);
            lbl_price_rh.MinimumSize = new Size(52, 32);
            lbl_price_rh.Name = "lbl_price_rh";
            lbl_price_rh.Size = new Size(52, 32);
            lbl_price_rh.TabIndex = 0;
            lbl_price_rh.Text = "Prix";
            // 
            // btn_next_rh
            // 
            btn_next_rh.BackColor = SystemColors.Window;
            btn_next_rh.Image = (Image)resources.GetObject("btn_next_rh.Image");
            btn_next_rh.Location = new Point(140, 56);
            btn_next_rh.MaximumSize = new Size(67, 23);
            btn_next_rh.MinimumSize = new Size(67, 23);
            btn_next_rh.Name = "btn_next_rh";
            btn_next_rh.Size = new Size(67, 23);
            btn_next_rh.TabIndex = 3;
            btn_next_rh.UseVisualStyleBackColor = false;
            // 
            // btn_previous_rh
            // 
            btn_previous_rh.BackColor = SystemColors.Window;
            btn_previous_rh.Image = (Image)resources.GetObject("btn_previous_rh.Image");
            btn_previous_rh.Location = new Point(73, 56);
            btn_previous_rh.MaximumSize = new Size(67, 23);
            btn_previous_rh.MinimumSize = new Size(67, 23);
            btn_previous_rh.Name = "btn_previous_rh";
            btn_previous_rh.Size = new Size(67, 23);
            btn_previous_rh.TabIndex = 2;
            btn_previous_rh.UseVisualStyleBackColor = false;
            // 
            // btn_delete_rh
            // 
            btn_delete_rh.BackColor = Color.MistyRose;
            btn_delete_rh.Font = new Font("Segoe UI", 14.25F);
            btn_delete_rh.Location = new Point(752, 532);
            btn_delete_rh.MaximumSize = new Size(194, 35);
            btn_delete_rh.MinimumSize = new Size(194, 35);
            btn_delete_rh.Name = "btn_delete_rh";
            btn_delete_rh.Size = new Size(194, 35);
            btn_delete_rh.TabIndex = 15;
            btn_delete_rh.Text = "Supprimer";
            btn_delete_rh.UseVisualStyleBackColor = false;
            btn_delete_rh.Click += btn_delete_rh_Click;
            // 
            // btn_modify_rh
            // 
            btn_modify_rh.BackColor = Color.Linen;
            btn_modify_rh.Font = new Font("Segoe UI", 14.25F);
            btn_modify_rh.Location = new Point(752, 480);
            btn_modify_rh.MaximumSize = new Size(194, 35);
            btn_modify_rh.MinimumSize = new Size(194, 35);
            btn_modify_rh.Name = "btn_modify_rh";
            btn_modify_rh.Size = new Size(194, 35);
            btn_modify_rh.TabIndex = 13;
            btn_modify_rh.Text = "Modifier";
            btn_modify_rh.UseVisualStyleBackColor = false;
            btn_modify_rh.Click += btn_modify_rh_Click;
            // 
            // btn_add_rh
            // 
            btn_add_rh.BackColor = Color.Honeydew;
            btn_add_rh.Font = new Font("Segoe UI", 14.25F);
            btn_add_rh.Location = new Point(752, 428);
            btn_add_rh.MaximumSize = new Size(194, 35);
            btn_add_rh.MinimumSize = new Size(194, 35);
            btn_add_rh.Name = "btn_add_rh";
            btn_add_rh.Size = new Size(194, 35);
            btn_add_rh.TabIndex = 12;
            btn_add_rh.Text = "Ajouter";
            btn_add_rh.UseVisualStyleBackColor = false;
            btn_add_rh.Click += btn_add_rh_Click;
            // 
            // txb_shortlong_rh
            // 
            txb_shortlong_rh.BackColor = SystemColors.Window;
            txb_shortlong_rh.Font = new Font("Segoe UI", 18F);
            txb_shortlong_rh.Location = new Point(329, 480);
            txb_shortlong_rh.MaximumSize = new Size(360, 39);
            txb_shortlong_rh.MinimumSize = new Size(360, 39);
            txb_shortlong_rh.Name = "txb_shortlong_rh";
            txb_shortlong_rh.ReadOnly = true;
            txb_shortlong_rh.Size = new Size(360, 39);
            txb_shortlong_rh.TabIndex = 8;
            // 
            // lbl_shortlong_rh
            // 
            lbl_shortlong_rh.AutoSize = true;
            lbl_shortlong_rh.Font = new Font("Segoe UI", 18F);
            lbl_shortlong_rh.Location = new Point(73, 480);
            lbl_shortlong_rh.MaximumSize = new Size(149, 32);
            lbl_shortlong_rh.MinimumSize = new Size(149, 32);
            lbl_shortlong_rh.Name = "lbl_shortlong_rh";
            lbl_shortlong_rh.Size = new Size(149, 32);
            lbl_shortlong_rh.TabIndex = 0;
            lbl_shortlong_rh.Text = "Court / Long";
            // 
            // pic_haircut_rh
            // 
            pic_haircut_rh.BackColor = SystemColors.InactiveBorder;
            pic_haircut_rh.Location = new Point(752, 22);
            pic_haircut_rh.MaximumSize = new Size(194, 176);
            pic_haircut_rh.MinimumSize = new Size(194, 176);
            pic_haircut_rh.Name = "pic_haircut_rh";
            pic_haircut_rh.Size = new Size(194, 176);
            pic_haircut_rh.TabIndex = 31;
            pic_haircut_rh.TabStop = false;
            // 
            // txb_cuttingtime_rh
            // 
            txb_cuttingtime_rh.BackColor = SystemColors.Window;
            txb_cuttingtime_rh.Font = new Font("Segoe UI", 18F);
            txb_cuttingtime_rh.Location = new Point(329, 428);
            txb_cuttingtime_rh.MaximumSize = new Size(360, 39);
            txb_cuttingtime_rh.MinimumSize = new Size(360, 39);
            txb_cuttingtime_rh.Name = "txb_cuttingtime_rh";
            txb_cuttingtime_rh.ReadOnly = true;
            txb_cuttingtime_rh.Size = new Size(360, 39);
            txb_cuttingtime_rh.TabIndex = 6;
            // 
            // txb_description_rh
            // 
            txb_description_rh.BackColor = SystemColors.Window;
            txb_description_rh.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txb_description_rh.Location = new Point(329, 165);
            txb_description_rh.MaximumSize = new Size(360, 241);
            txb_description_rh.MinimumSize = new Size(360, 241);
            txb_description_rh.Name = "txb_description_rh";
            txb_description_rh.ReadOnly = true;
            txb_description_rh.Size = new Size(360, 241);
            txb_description_rh.TabIndex = 5;
            txb_description_rh.Text = "";
            // 
            // lbl_cuttingtime_rh
            // 
            lbl_cuttingtime_rh.AutoSize = true;
            lbl_cuttingtime_rh.Font = new Font("Segoe UI", 18F);
            lbl_cuttingtime_rh.Location = new Point(73, 428);
            lbl_cuttingtime_rh.MaximumSize = new Size(190, 32);
            lbl_cuttingtime_rh.MinimumSize = new Size(190, 32);
            lbl_cuttingtime_rh.Name = "lbl_cuttingtime_rh";
            lbl_cuttingtime_rh.Size = new Size(190, 32);
            lbl_cuttingtime_rh.TabIndex = 0;
            lbl_cuttingtime_rh.Text = "Temps de coupe";
            // 
            // txb_name_rh
            // 
            txb_name_rh.BackColor = SystemColors.Window;
            txb_name_rh.Font = new Font("Segoe UI", 18F);
            txb_name_rh.Location = new Point(329, 112);
            txb_name_rh.MaximumSize = new Size(360, 39);
            txb_name_rh.MinimumSize = new Size(360, 39);
            txb_name_rh.Name = "txb_name_rh";
            txb_name_rh.ReadOnly = true;
            txb_name_rh.Size = new Size(360, 39);
            txb_name_rh.TabIndex = 4;
            // 
            // lbl_description_rh
            // 
            lbl_description_rh.AutoSize = true;
            lbl_description_rh.Font = new Font("Segoe UI", 18F);
            lbl_description_rh.Location = new Point(73, 165);
            lbl_description_rh.MaximumSize = new Size(135, 32);
            lbl_description_rh.MinimumSize = new Size(135, 32);
            lbl_description_rh.Name = "lbl_description_rh";
            lbl_description_rh.Size = new Size(135, 32);
            lbl_description_rh.TabIndex = 0;
            lbl_description_rh.Text = "Description";
            // 
            // lbl_name_rh
            // 
            lbl_name_rh.AutoSize = true;
            lbl_name_rh.Font = new Font("Segoe UI", 18F);
            lbl_name_rh.Location = new Point(73, 112);
            lbl_name_rh.MaximumSize = new Size(67, 32);
            lbl_name_rh.MinimumSize = new Size(67, 32);
            lbl_name_rh.Name = "lbl_name_rh";
            lbl_name_rh.Size = new Size(67, 32);
            lbl_name_rh.TabIndex = 0;
            lbl_name_rh.Text = "Nom";
            // 
            // lbl_search_rh
            // 
            lbl_search_rh.AutoSize = true;
            lbl_search_rh.Font = new Font("Segoe UI", 18F);
            lbl_search_rh.Location = new Point(73, 22);
            lbl_search_rh.MaximumSize = new Size(124, 32);
            lbl_search_rh.MinimumSize = new Size(124, 32);
            lbl_search_rh.Name = "lbl_search_rh";
            lbl_search_rh.Size = new Size(124, 32);
            lbl_search_rh.TabIndex = 0;
            lbl_search_rh.Text = "Recherche";
            // 
            // txb_search_rh
            // 
            txb_search_rh.BackColor = SystemColors.Window;
            txb_search_rh.Font = new Font("Segoe UI", 18F);
            txb_search_rh.Location = new Point(329, 22);
            txb_search_rh.MaximumSize = new Size(360, 39);
            txb_search_rh.MinimumSize = new Size(360, 39);
            txb_search_rh.Name = "txb_search_rh";
            txb_search_rh.Size = new Size(360, 39);
            txb_search_rh.TabIndex = 1;
            // 
            // pic_reservecute_rf
            // 
            pic_reservecute_rf.BackColor = Color.Transparent;
            pic_reservecute_rf.Image = Properties.Resources.ReserveCut_Titre;
            pic_reservecute_rf.Location = new Point(539, -2);
            pic_reservecute_rf.Margin = new Padding(3, 2, 3, 2);
            pic_reservecute_rf.Name = "pic_reservecute_rf";
            pic_reservecute_rf.Size = new Size(401, 65);
            pic_reservecute_rf.TabIndex = 2;
            pic_reservecute_rf.TabStop = false;
            // 
            // FrmReserveCut
            // 
            AcceptButton = btn_add_rr;
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(1031, 659);
            Controls.Add(pic_reservecute_rf);
            Controls.Add(tab_reservecut_rf);
            Controls.Add(mns_reservecut_rf);
            ForeColor = SystemColors.ControlText;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MainMenuStrip = mns_reservecut_rf;
            MaximizeBox = false;
            MaximumSize = new Size(1047, 698);
            MinimumSize = new Size(1047, 698);
            Name = "FrmReserveCut";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ReserveCut";
            Load += FrmReserveCut_Load;
            mns_reservecut_rf.ResumeLayout(false);
            mns_reservecut_rf.PerformLayout();
            tab_reservecut_rf.ResumeLayout(false);
            tab_reservation_rr.ResumeLayout(false);
            tab_reservation_rr.PerformLayout();
            tab_customer_rc.ResumeLayout(false);
            tab_customer_rc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pic_customer_rc).EndInit();
            tab_stylist_rs.ResumeLayout(false);
            tab_stylist_rs.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pic_stylist_rs).EndInit();
            tab_haircut_rh.ResumeLayout(false);
            tab_haircut_rh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pic_haircut_rh).EndInit();
            ((System.ComponentModel.ISupportInitialize)pic_reservecute_rf).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private ToolStripMenuItem mns_file_rf;
        private ToolStripMenuItem mns_new_rf;
        private ToolStripMenuItem msns_newreservation_rf;
        private ToolStripMenuItem mns_newcustomer_rf;
        private ToolStripMenuItem mns_newstylist_rf;
        private ToolStripMenuItem mns_newhaircut_rf;
        private ToolStripMenuItem mns_users_rf;
        private ToolStripMenuItem mns_quite_rf;

        private MenuStrip mns_reservecut_rf;
        private TabControl tab_reservecut_rf;
        private TabPage tab_reservation_rr;
        private TabPage tab_customer_rc;
        private TabPage tab_stylist_rs;
        private TabPage tab_haircut_rh;

        private Label lbl_stylist_rr;
        private ComboBox cmb_stylist_rr;
        private DateTimePicker dtp_reservation_rr;
        private Button btn_add_rr;
        private Label lbl_monday_rr;
        private Label lbl_tuesday_rr;
        private Label lbl_wednesday_rr;
        private Label lbl_thursday_rr;
        private Label lbl_friday_rr;
        private Label lbl_saturday_rr;
        private Label lbl_0800_rr;
        private Label lbl_8030_rr;
        private Label lbl_0900_rr;
        private Label lbl_0930_rr;
        private Label lbl_1000_rr;
        private Label lbl_1030_rr;
        private Label lbl_1100_rr;
        private Label lbl_1130_rr;
        private Label lbl_1200_rr;
        private Label lbl_1230_rr;
        private Label lbl_1300_rr;
        private Label lbl_1330_rr;
        private Label lbl_1400_rr;
        private Label lbl_1430_rr;
        private Label lbl_1500_rr;
        private Label lbl_1530_rr;
        private Label lbl_1600_rr;
        private Label lbl_1630_rr;
        private Label lbl_1700_rr;
        private Label lbl_1730_rr;
        private Label lbl_1800_rr;
        private Label lbl_1830_rr;
       
        private Label lbl_search_rc;       
        private Label lbl_name_rc;       
        private Label lbl_firstname_rc;       
        private Label lbl_address_rc;       
        private Label lbl_city_rc;       
        private Label lbl_npa_rc;       
        private Label lbl_phone_rc;      
        private Label lbl_mail_rc;       
        private Label lbl_birthdate_rc;       
        private Label lbl_contact_rc; 
        private Label lbl_haircut_rc;
        private TextBox txb_search_rc;
        private TextBox txb_name_rc;
        private TextBox txb_firstname_rc;
        private TextBox txb_address_rc;
        private TextBox txb_city_rc;
        private TextBox txb_npa_rc;
        private TextBox txb_phone_rc;
        private TextBox txb_mail_rc;
        private TextBox txb_datebirth_rc;
        private TextBox txb_contact_rc;
        private TextBox txb_haircut_rc;
        private PictureBox pic_customer_rc;
        private DateTimePicker dtp_birthdate_rc;
        private ComboBox cmb_haircut_rc;
        private ComboBox cmb_contact_rc; 
        private Button btn_previous_rc;
        private Button btn_next_rc;
        private Button btn_add_rc;
        private Button btn_modify_rc;
        private Button btn_delete_rc;
        private Button btn_confirm_rc;
        private Button btn_photo_rc;

        private Label lbl_search_rs;
        private Label lbl_name_rs;
        private Label lbl_firstname_rs;
        private Label lbl_speciality_rs;
        private Label lbl_absence_rs;
        private TextBox txb_search_rs;
        private TextBox txb_name_rs;
        private TextBox txb_firstname_rs;
        private ListBox lst_speciality_rs;
        private ListBox lst_absence_rs;
        private ComboBox cmb_speciality_rs;
        private PictureBox pic_stylist_rs;
        private Button btn_previous_rs;
        private Button btn_next_rs;
        private Button btn_add_rs;
        private Button btn_modify_rs;
        private Button btn_delete_rs;
        private Button btn_confirm_rs;
        private Button btn_photo_rs;
        private Button btn_addspeciality_rs;
        private Button btn_deletespeciality_rs;
        private Button btn_addabsence_rs;
        private Button btn_deleteabsence_rs;
        
        private Label lbl_search_rh;
        private Label lbl_name_rh;
        private Label lbl_description_rh;
        private Label lbl_cuttingtime_rh;
        private Label lbl_shortlong_rh;
        private Label lbl_price_rh;
        private TextBox txb_search_rh;
        private TextBox txb_name_rh;
        private RichTextBox txb_description_rh;
        private TextBox txb_cuttingtime_rh;
        private TextBox txb_shortlong_rh;
        private TextBox txb_price_rh;
        private ComboBox cmb_shortlong_rh;
        private PictureBox pic_haircut_rh;
        private Button btn_previous_rh;
        private Button btn_next_rh;
        private Button btn_add_rh;
        private Button btn_modify_rh;
        private Button btn_delete_rh;
        private Button btn_confirm_rh;
        private Button btn_photo_rh;

        private Panel pnl_0800_mon_rr;
        private Panel pnl_0800_sat_rr;
        private Panel pnl_0800_wed_rr;
        private Panel pnl_0800_fri_rr;
        private Panel pnl_0800_thu_rr;
        private Panel pnl_0800_tue_rr;
        private Panel pnl_0830_sat_rr;
        private Panel pnl_0830_wed_rr;
        private Panel pnl_0830_fri_rr;
        private Panel pnl_0830_thu_rr;
        private Panel pnl_0830_tue_rr;
        private Panel pnl_0830_mon_rr;
        private Panel pnl_1230_mon_rr;
        private Panel pnl_1130_mon_rr;
        private Panel pnl_1100_mon_rr;
        private Panel pnl_1030_mon_rr;
        private Panel pnl_1000_mon_rr;
        private Panel pnl_0930_mon_rr;
        private Panel pnl_0900_mon_rr;
        private Panel pnl_1530_mon_rr;
        private Panel pnl_1500_mon_rr;
        private Panel pnl_1430_mon_rr;
        private Panel pnl_1400_mon_rr;
        private Panel pnl_1330_mon_rr;
        private Panel pnl_1200_mon_rr;
        private Panel pnl_1300_mon_rr;
        private Panel pnl_1830_mon_rr;
        private Panel pnl_1800_mon_rr;
        private Panel pnl_1730_mon_rr;
        private Panel pnl_1700_mon_rr;
        private Panel pnl_1630_mon_rr;
        private Panel pnl_1600_mon_rr;
        private Panel pnl_1830_tue_rr;
        private Panel pnl_1800_tue_rr;
        private Panel pnl_1730_tue_rr;
        private Panel pnl_1700_tue_rr;
        private Panel pnl_1630_tue_rr;
        private Panel pnl_1600_tue_rr;
        private Panel pnl_1530_tue_rr;
        private Panel pnl_1500_tue_rr;
        private Panel pnl_1430_tue_rr;
        private Panel pnl_1400_tue_rr;
        private Panel pnl_1330_tue_rr;
        private Panel pnl_1200_tue_rr;
        private Panel pnl_1300_tue_rr;
        private Panel pnl_1230_tue_rr;
        private Panel pnl_1130_tue_rr;
        private Panel pnl_1100_tue_rr;
        private Panel pnl_1030_tue_rr;
        private Panel pnl_1000_tue_rr;
        private Panel pnl_0930_tue_rr;
        private Panel pnl_0900_tue_rr;
        private Panel pnl_1830_wed_rr;
        private Panel pnl_1800_wed_rr;
        private Panel pnl_1730_wed_rr;
        private Panel pnl_1700_wed_rr;
        private Panel pnl_1630_wed_rr;
        private Panel pnl_1600_wed_rr;
        private Panel pnl_1530_wed_rr;
        private Panel pnl_1500_wed_rr;
        private Panel pnl_1430_wed_rr;
        private Panel pnl_1400_wed_rr;
        private Panel pnl_1330_wed_rr;
        private Panel pnl_1200_wed_rr;
        private Panel pnl_1300_wed_rr;
        private Panel pnl_1230_wed_rr;
        private Panel pnl_1130_wed_rr;
        private Panel pnl_1100_wed_rr;
        private Panel pnl_1030_wed_rr;
        private Panel pnl_1000_wed_rr;
        private Panel pnl_0930_wed_rr;
        private Panel pnl_0900_wed_rr;
        private Panel pnl_1830_thu_rr;
        private Panel pnl_1800_thu_rr;
        private Panel pnl_1730_thu_rr;
        private Panel pnl_1700_thu_rr;
        private Panel pnl_1630_thu_rr;
        private Panel pnl_1600_thu_rr;
        private Panel pnl_1530_thu_rr;
        private Panel pnl_1500_thu_rr;
        private Panel pnl_1430_thu_rr;
        private Panel pnl_1400_thu_rr;
        private Panel pnl_1330_thu_rr;
        private Panel pnl_1200_thu_rr;
        private Panel pnl_1300_thu_rr;
        private Panel pnl_1230_thu_rr;
        private Panel pnl_1130_thu_rr;
        private Panel pnl_1100_thu_rr;
        private Panel pnl_1030_thu_rr;
        private Panel pnl_1000_thu_rr;
        private Panel pnl_0930_thu_rr;
        private Panel pnl_0900_thu_rr;
        private Panel pnl_1830_sat_rr;
        private Panel pnl_1800_sat_rr;
        private Panel pnl_1730_sat_rr;
        private Panel pnl_1700_sat_rr;
        private Panel pnl_1630_sat_rr;
        private Panel pnl_1600_sat_rr;
        private Panel pnl_1530_sat_rr;
        private Panel pnl_1500_sat_rr;
        private Panel pnl_1430_sat_rr;
        private Panel pnl_1400_sat_rr;
        private Panel pnl_1330_sat_rr;
        private Panel pnl_1200_sat_rr;
        private Panel pnl_1300_sat_rr;
        private Panel pnl_1230_sat_rr;
        private Panel pnl_1130_sat_rr;
        private Panel pnl_1100_sat_rr;
        private Panel pnl_1030_sat_rr;
        private Panel pnl_1000_sat_rr;
        private Panel pnl_0930_sat_rr;
        private Panel pnl_0900_sat_rr;
        private Panel pnl_1830_fri_rr;
        private Panel pnl_1800_fri_rr;
        private Panel pnl_1730_fri_rr;
        private Panel pnl_1700_fri_rr;
        private Panel pnl_1630_fri_rr;
        private Panel pnl_1600_fri_rr;
        private Panel pnl_1530_fri_rr;
        private Panel pnl_1500_fri_rr;
        private Panel pnl_1430_fri_rr;
        private Panel pnl_1400_fri_rr;
        private Panel pnl_1330_fri_rr;
        private Panel pnl_1200_fri_rr;
        private Panel pnl_1300_fri_rr;
        private Panel pnl_1230_fri_rr;
        private Panel pnl_1130_fri_rr;
        private Panel pnl_1100_fri_rr;
        private Panel pnl_1030_fri_rr;
        private Panel pnl_1000_fri_rr;
        private Panel pnl_0930_fri_rr;
        private Panel pnl_0900_fri_rr;
        private PictureBox pic_reservecute_rf;
        private Button btn_cancel_rc;
        private Button btn_cancel_rs;
        private Button btn_cancel_rh;
        private ComboBox cmb_cuttingtime_rh;
    }

}
