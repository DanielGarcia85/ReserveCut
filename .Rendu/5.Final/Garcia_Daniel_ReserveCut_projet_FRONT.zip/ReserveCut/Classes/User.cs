﻿namespace ReserveCut.Classes
{
    // Classe représentant un utilisateur de l'application
    public class User
    {
        public int id { get; set; }
        public String name { get; set; }
        public String firstname { get; set; }
        public String username { get; set; }
        public String password { get; set; }
        public String role { get; set; }
    }

}
