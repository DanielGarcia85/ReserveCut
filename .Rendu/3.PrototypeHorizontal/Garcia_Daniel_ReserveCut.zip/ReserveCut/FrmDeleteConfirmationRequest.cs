﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmDeleteConfirmationRequest : Form
    {
        private Button callbtndel;

        public FrmDeleteConfirmationRequest(Button callingButton)
        {
            InitializeComponent();
            callbtndel = callingButton;
        }

        private void deleteConfirmationFom_Shown(object sender, EventArgs e)
        {
            btn_cancel_dcr.Focus();
        }

        private void btn_confirm_dcr_Click(object sender, EventArgs e)
        {
            switch (callbtndel.Name)
            {
                case "btn_delete_c":
                    break;
                case "btn_delete_s":
                    break;
                case "btn_delete_h":
                    break;
                case "btn_delete_u":
                    break;
                default:
                    break;
            }
            FrmDeleteConfirmation frmDeleteConfirmation = new FrmDeleteConfirmation();
            frmDeleteConfirmation.ShowDialog();
            this.Close();
        }

        private void btn_cancel_dcr_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmDeleteConfirmationRequest_Load(object sender, EventArgs e)
        {
            btn_cancel_dcr.Focus();
        }
    }
}
