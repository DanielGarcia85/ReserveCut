﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmNewStylist : Form
    {
        public FrmNewStylist()
        {
            InitializeComponent();
            cmb_speciality_ns.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        private void btn_cancel_ns_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bnt_photo_ns_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Images (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"; // Exemple de filtre
            openFileDialog.Title = "Sélectionnez un fichier";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Ici, vous pouvez faire ce que vous voulez avec le chemin du fichier sélectionné.
                // Par exemple, vous pourriez l'afficher dans un TextBox ou lire le contenu du fichier.
                // Exemple : textBox1.Text = openFileDialog.FileName;
            }
        }

        private void btn_add_ns_Click(object sender, EventArgs e)
        {
            FrmAddConfirmation frmAddConfirmation = new FrmAddConfirmation();
            frmAddConfirmation.ShowDialog();
            txb_name_ns.Text = "";
            txb_firstname_ns.Text = "";
            cmb_speciality_ns.SelectedIndex = -1;
            lst_speciality_ns.Items.Clear();
        }

        private void FrmNewStylist_Load(object sender, EventArgs e)
        {
            txb_name_ns.Focus();
        }

        private void btn_addspeciality_ns_Click(object sender, EventArgs e)
        {
            string speciality = cmb_speciality_ns.Text;

            if (!lst_speciality_ns.Items.Contains(speciality))
            {
                lst_speciality_ns.Items.Add(speciality);
            }
            else
            {
                MessageBox.Show($"{speciality} est déjà ajouté.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
