﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmLogin : Form
    {
        public static String loggedUser = "";

        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btn_login_lo_Click(object sender, EventArgs e)
        {
            if (txb_username_lo.Text == "adm1" && txb_password_lo.Text == "1")
            {
                this.DialogResult = DialogResult.OK;
                loggedUser = "admin";

            }
            else if (txb_username_lo.Text == "usr1" && txb_password_lo.Text == "1")
            {
                this.DialogResult = DialogResult.OK;
                loggedUser = "user";
            }
            else
            {
                FrmLoginError frmLoginError = new FrmLoginError();
                frmLoginError.ShowDialog();
                txb_username_lo.Text = "";
                txb_password_lo.Text = "";
                txb_username_lo.Focus();
            }
        }

        private void bnt_cancel_lo_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {
            txb_username_lo.Focus();
        }
    }
}
