﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmNewCustomer : Form
    {
        public FrmNewCustomer()
        {
            InitializeComponent();
            cmb_contact_nc.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_haricut_nc.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void btn_cancel_nc_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bnt_photo_nc_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Images (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"; // Exemple de filtre
            openFileDialog.Title = "Sélectionnez un fichier";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Ici, vous pouvez faire ce que vous voulez avec le chemin du fichier sélectionné.
                // Par exemple, vous pourriez l'afficher dans un TextBox ou lire le contenu du fichier.
                // Exemple : textBox1.Text = openFileDialog.FileName;
            }

        }

        private void btn_add_nc_Click(object sender, EventArgs e)
        {
            FrmAddConfirmation frmAddConfirmation = new FrmAddConfirmation();
            frmAddConfirmation.ShowDialog();
            txb_name_nc.Text = "";
            txb_firstname_nc.Text = "";
            txb_address_nc.Text = "";
            txb_city_nc.Text = "";
            txb_npa_nc.Text = "";
            txb_address_nc.Text = "";
            txb_phone_nc.Text = "";
            txb_mail_nc.Text = "";
            dtp_birthdate_nc.Text = "";
            cmb_contact_nc.SelectedIndex = -1;
            cmb_haricut_nc.SelectedIndex = -1;
        }

        private void FrmNewCustomer_Load(object sender, EventArgs e)
        {
            txb_name_nc.Focus();
        }
    }
}
