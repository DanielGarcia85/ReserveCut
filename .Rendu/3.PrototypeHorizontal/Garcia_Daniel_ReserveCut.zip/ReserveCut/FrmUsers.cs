﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmUsers : Form
    {
        public FrmUsers()
        {
            InitializeComponent();
            selectAdm1();
        }

        private bool isAdmSelected = true;

        private void selectAdm1()
        {
            txb_name_us.Text = "Garcia";
            txb_firstname_us.Text = "Daniel";
            cmb_username_us.SelectedIndex = 0;
            txb_username_us.Text = "adm1";
            txb_password_us.Text = "1234";
            txb_role_us.Text = "Admin";
        }

        private void selectUsr1()
        {
            txb_name_us.Text = "Dupont";
            txb_firstname_us.Text = "Marc";
            cmb_username_us.SelectedIndex = 1;
            txb_username_us.Text = "usr1";
            txb_password_us.Text = "1234";
            txb_role_us.Text = "User";
        }

        private void btn_add_us_Click(object sender, EventArgs e)
        {
            btn_add_us.Visible = false;
            btn_delete_us.Visible = false;
            btn_modify_us.Visible = false;
            btn_confirm_us.Visible = true;
            btn_cancel_us.Visible = true;
            btn_close_us.Visible = false;
            btn_previous_us.Visible = false;
            btn_next_us.Visible = false;
            cmb_username_us.Visible = false;
            cmb_role_us.Visible = true;
            txb_username_us.Visible = true;
            txb_role_us.Enabled = false;
            txb_name_us.ReadOnly = false;
            txb_firstname_us.ReadOnly = false;
            txb_username_us.ReadOnly = false;
            txb_password_us.ReadOnly = false;
            txb_name_us.Text = "";
            txb_firstname_us.Text = "";
            txb_username_us.Text = "";
            cmb_username_us.SelectedIndex = -1;
            txb_password_us.Text = "";
            txb_role_us.Text = "";
            cmb_role_us.SelectedIndex = -1;
            AcceptButton = btn_confirm_us;
        }

        private void btn_modify_Click(object sender, EventArgs e)
        {
            btn_add_us.Visible = false;
            btn_delete_us.Visible = false;
            btn_modify_us.Visible = false;
            btn_confirm_us.Visible = true;
            btn_cancel_us.Visible = true;
            btn_close_us.Visible = false;
            btn_previous_us.Visible = false;
            btn_next_us.Visible = false;
            cmb_username_us.Visible = false;
            cmb_role_us.Visible = true;
            txb_username_us.Visible = true;
            txb_role_us.Enabled = false;
            txb_name_us.ReadOnly = false;
            txb_firstname_us.ReadOnly = false;
            txb_username_us.ReadOnly = false;
            txb_password_us.ReadOnly = false;
            txb_username_us.Text = cmb_username_us.Text;
            if (txb_role_us.Text == "Admin") { cmb_role_us.SelectedIndex = 0; }
            if (txb_role_us.Text == "User") { cmb_role_us.SelectedIndex = 1; }
            AcceptButton = btn_confirm_us;

        }

        private void btn_confirm_Click(object sender, EventArgs e)
        {
            FrmPasswordConfirmation frmPasswordConfirmation = new FrmPasswordConfirmation(this);
            frmPasswordConfirmation.ShowDialog();
            selectAdm1();
            AcceptButton = btn_close_us;
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            btn_add_us.Visible = true;
            btn_delete_us.Visible = true;
            btn_modify_us.Visible = true;
            btn_confirm_us.Visible = false;
            btn_cancel_us.Visible = false;
            btn_close_us.Visible = true;
            btn_previous_us.Visible = true;
            btn_next_us.Visible = true;
            cmb_username_us.Visible = true;
            cmb_role_us.Visible = false;
            txb_username_us.Visible = false;
            txb_role_us.Enabled = true;
            txb_name_us.ReadOnly = true;
            txb_firstname_us.ReadOnly = true;
            txb_username_us.ReadOnly = true;
            txb_password_us.ReadOnly = true;
            cmb_role_us.SelectedIndex = -1;
            selectAdm1();
            AcceptButton = btn_close_us;
            
        }

        private void btn_delete_u_Click(object sender, EventArgs e)
        {
            FrmDeleteConfirmationRequest frmDeleteConfirmation = new FrmDeleteConfirmationRequest(btn_delete_us);
            frmDeleteConfirmation.ShowDialog();
            selectAdm1();
        }

        private void btn_close_us_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmUsers_Load(object sender, EventArgs e)
        {
            txb_name_us.Focus();
        }

        private void btn_next_us_Click(object sender, EventArgs e)
        {
            if (isAdmSelected)
            {
                selectUsr1();
                isAdmSelected = false;
            }
            else
            {
                selectAdm1();
                isAdmSelected = true;
            }
        }

        private void btn_previous_us_Click(object sender, EventArgs e)
        {
            if (isAdmSelected)
            {
                selectUsr1();
                isAdmSelected = false;
            }
            else
            {
                selectAdm1();
                isAdmSelected = true;
            }
        }

        private void cmb_username_us_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmb_username_us.SelectedIndex)
            {
                case 0:
                    selectAdm1();
                    break;
                case 1:
                    selectUsr1();
                    break;
                default:
                    break;
            }
        }
    }
}
