﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmReservation : Form
    {
        public FrmReservation()
        {
            InitializeComponent();

        }

        private void btn_modify_re_Click(object sender, EventArgs e)
        {
            dtp_date_re.Visible = true;
            cmb_time_re.Visible = true;
            cmb_customer_re.Visible = true;
            cmb_styliste_re.Visible = true;
            txb_date_re.Visible = false;
            txb_time_re.Visible = false;
            txb_customer_re.Visible = false;
            txb_stylist_re.Visible = false;
            txb_comments_re.ReadOnly = false;
            rdo_no_beard_re.Enabled = true;
            rdo_yes_beard_re.Enabled = true;
            rdo_no_shampoo_re.Enabled = true;
            rdo_yes_shampoo_re.Enabled = true;
            btn_modify_re.Visible = false;
            btn_close_re.Visible = false;
            btn_confirm_re.Visible = true;
            btn_cancel_re.Visible = true;
            AcceptButton = btn_confirm_re;
        }

        private void btn_confirm_re_Click(object sender, EventArgs e)
        {
            dtp_date_re.Visible = false;
            cmb_time_re.Visible = false;
            cmb_customer_re.Visible = false;
            cmb_styliste_re.Visible = false;
            txb_date_re.Visible = true;
            txb_time_re.Visible = true;
            txb_customer_re.Visible = true;
            txb_stylist_re.Visible = true;
            txb_comments_re.ReadOnly = true;
            rdo_no_beard_re.Enabled = false;
            rdo_yes_beard_re.Enabled = false;
            rdo_no_shampoo_re.Enabled = false;
            rdo_yes_shampoo_re.Enabled = false;
            btn_modify_re.Visible = true;
            btn_close_re.Visible = true;
            btn_confirm_re.Visible = false;
            btn_cancel_re.Visible = false;
            txb_date_re.Text = dtp_date_re.Text;
            txb_time_re.Text = cmb_time_re.Text;
            txb_customer_re.Text = cmb_customer_re.Text;
            txb_stylist_re.Text = cmb_styliste_re.Text;
            FrmModificationConfirmation frmModificationConfirmation = new FrmModificationConfirmation();
            frmModificationConfirmation.ShowDialog();
            AcceptButton = btn_close_re;
        }

        private void btn_cancel_re_Click(object sender, EventArgs e)
        {
            dtp_date_re.Visible = false;
            cmb_time_re.Visible = false;
            cmb_customer_re.Visible = false;
            cmb_styliste_re.Visible = false;
            txb_date_re.Visible = true;
            txb_time_re.Visible = true;
            txb_customer_re.Visible = true;
            txb_stylist_re.Visible = true;
            txb_comments_re.ReadOnly = true;
            rdo_no_beard_re.Enabled = false;
            rdo_yes_beard_re.Enabled = false;
            rdo_no_shampoo_re.Enabled = false;
            rdo_yes_shampoo_re.Enabled = false;
            btn_modify_re.Visible = true;
            btn_close_re.Visible = true;
            btn_confirm_re.Visible = false;
            btn_cancel_re.Visible = false;
            txb_date_re.Text = "";
            txb_time_re.Text = "";
            txb_customer_re.Text = "";
            txb_stylist_re.Text = "";
            txb_comments_re.Text = "";
            cmb_time_re.SelectedIndex = -1;
            cmb_customer_re.SelectedIndex = -1;
            cmb_styliste_re.SelectedIndex = -1;
            rdo_yes_shampoo_re.Checked = false;
            rdo_no_shampoo_re.Checked = false;
            rdo_yes_beard_re.Checked = false;
            rdo_no_beard_re.Checked = false;
            rdo_yes_shampoo_re.TabStop = true;
            rdo_no_shampoo_re.TabStop = true;
            rdo_yes_beard_re.TabStop = true;
            rdo_no_beard_re.TabStop = true;
        }

        private void btn_close_re_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmReservation_Load(object sender, EventArgs e)
        {
            dtp_date_re.Focus();
        }

    }
}
