﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmNewHaircut : Form
    {
        public FrmNewHaircut()
        {
            InitializeComponent();
            cmb_shortlong_nh.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_cutingtime_nh.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void btn_cancel_nh_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bnt_photo_nh_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Images (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"; // Exemple de filtre
            openFileDialog.Title = "Sélectionnez un fichier";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Ici, vous pouvez faire ce que vous voulez avec le chemin du fichier sélectionné.
                // Par exemple, vous pourriez l'afficher dans un TextBox ou lire le contenu du fichier.
                // Exemple : textBox1.Text = openFileDialog.FileName;
            }
        }

        private void btn_add_nh_Click(object sender, EventArgs e)
        {
            FrmAddConfirmation frmAddConfirmation = new FrmAddConfirmation();
            frmAddConfirmation.ShowDialog();
            txb_name_nh.Text = "";
            txb_description_nh.Text = "";
            cmb_cutingtime_nh.SelectedIndex = -1;
            cmb_shortlong_nh.SelectedIndex = -1;
            txb_price_nh.Text = "";
        }

        private void FrmNewHaircut_Load(object sender, EventArgs e)
        {
            txb_name_nh.Focus();
        }
    }
}
