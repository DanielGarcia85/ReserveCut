﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmNewAbsence : Form
    {
        public FrmNewAbsence()
        {
            InitializeComponent();
        }

        private void FrmNewAbsence_Load(object sender, EventArgs e)
        {
            dtp_begindate_na.Focus();
        }

        private void btn_add_na_Click(object sender, EventArgs e)
        {
            FrmAddConfirmation frmAddConfirmation = new FrmAddConfirmation();
            frmAddConfirmation.ShowDialog();
            this.Close();
        }
    }
}
