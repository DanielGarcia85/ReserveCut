﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmNewReservation : Form
    {
        public FrmNewReservation()
        {
            InitializeComponent();
            cmb_time_nr.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_customer_nr.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_styliste_nr.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        private void btn_cancel_nr_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_addcustomer_nr_Click(object sender, EventArgs e)
        {
            FrmNewCustomer frmNewCustomer = new FrmNewCustomer();
            frmNewCustomer.ShowDialog();
        }

        private void btn_add_nr_Click(object sender, EventArgs e)
        {
            FrmAddConfirmation frmAddConfirmation = new FrmAddConfirmation();
            frmAddConfirmation.ShowDialog();
            cmb_time_nr.SelectedIndex = -1;
            cmb_customer_nr.SelectedIndex = -1;
            cmb_styliste_nr.SelectedIndex = -1;
            rdo_yes_shampoo_nr.Checked = false;
            rdo_no_shampoo_nr.Checked = false;
            rdo_yes_beard_nr.Checked = false;
            rdo_no_beard_nr.Checked = false;
            rdo_yes_shampoo_nr.TabStop = true;
            rdo_no_shampoo_nr.TabStop = true;
            rdo_yes_beard_nr.TabStop = true;
            rdo_no_beard_nr.TabStop = true;
            txb_comments_nr.Text = "";
        }

        private void FrmNewReservation_Load(object sender, EventArgs e)
        {
            dtp_reservationdate_nr.Focus();
        }
    }
}
