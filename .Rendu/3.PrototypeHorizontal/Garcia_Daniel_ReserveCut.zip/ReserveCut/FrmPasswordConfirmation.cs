﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmPasswordConfirmation : Form
    {
        private FrmUsers usersFormInstance;

        public FrmPasswordConfirmation(FrmUsers usersForm)
        {
            InitializeComponent();
            this.usersFormInstance = usersForm;
        }

        private void btn_confirm_pc_Click(object sender, EventArgs e)
        {
            usersFormInstance.Set_btn_add_us_Visible(true);
            usersFormInstance.Set_btn_delete_us_Visible(true);
            usersFormInstance.Set_btn_modify_us_Visible(true);
            usersFormInstance.Set_btn_validate_us_Visible(false);
            usersFormInstance.Set_btn_cancel_us_Visible(false);
            usersFormInstance.Set_btn_close_us_Visible(true);
            usersFormInstance.Set_btn_previous_us_Visible(true);
            usersFormInstance.Set_btn_next_us_Visible(true);
            usersFormInstance.Set_cmb_username_us_Visible(true);
            usersFormInstance.Set_cmb_role_us_Visible(false);
            usersFormInstance.Set_txb_username_us_Visible(false);
            usersFormInstance.Set_txb_role_us_Enable(true);
            usersFormInstance.Set_txb_name_us_ReadOnly(true);
            usersFormInstance.Set_txb_firstname_us_ReadOnly(true);
            usersFormInstance.Set_txb_username_us_ReadOnly(true);
            usersFormInstance.Set_txb_password_us_ReadOnly(true);
            this.Close();
            FrmAddConfirmation frmAddConfirmation = new FrmAddConfirmation();
            frmAddConfirmation.ShowDialog();
        }

        private void btn_cancel_pc_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmPasswordConfirmation_Load(object sender, EventArgs e)
        {
            txb_password_pc.Focus();
        }
    }
}
