﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReserveCut
{
    public partial class FrmDeleteConfirmation : Form
    {
        public FrmDeleteConfirmation()
        {
            InitializeComponent();
        }

        private void btn_ok_dc_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmDeleteConfirmation_Load(object sender, EventArgs e)
        {
            btn_ok_dc.Focus();
        }
    }
}
