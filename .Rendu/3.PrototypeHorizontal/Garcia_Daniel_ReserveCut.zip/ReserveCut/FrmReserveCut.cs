using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ReserveCut
{
    public partial class FrmReserveCut : Form
    {
        public FrmReserveCut()
        {
            InitializeComponent();

            if (FrmLogin.loggedUser == "user")
            {
                mns_file_rc.DropDownItems.Clear();
                mns_file_rc.DropDownItems.AddRange(new ToolStripItem[] { mns_new_rc, mns_quite_rc });
                mns_new_rc.DropDownItems.Clear();
                mns_new_rc.DropDownItems.AddRange(new ToolStripItem[] { msns_newreservation_rc, mns_newcustomer_rc });
                tab_reservecut_rc.Controls.Clear();
                tab_reservecut_rc.Controls.Add(tab_reservation_rr);
                tab_reservecut_rc.Controls.Add(tab_customer_rc);
            }
        }

        private void mns_users_rc_Click(object sender, EventArgs e)
        {
            FrmUsers frmUsers = new FrmUsers();
            frmUsers.ShowDialog();
        }

        private void mns_quite_rc_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mns_newreservation_rc_Click(object sender, EventArgs e)
        {
            FrmNewReservation frmNewReservation = new FrmNewReservation();
            frmNewReservation.ShowDialog();
        }

        private void mns_newcustomer_rc_Click(object sender, EventArgs e)
        {
            FrmNewCustomer frmNewCustomer = new FrmNewCustomer();
            frmNewCustomer.ShowDialog();
        }

        private void mns_newstylist_rc_Click(object sender, EventArgs e)
        {
            FrmNewStylist frmNewStylist = new FrmNewStylist();
            frmNewStylist.ShowDialog();
        }

        private void mns_newhaircut_rc_Click(object sender, EventArgs e)
        {
            FrmNewHaircut frmNewHaircut = new FrmNewHaircut();
            frmNewHaircut.ShowDialog();
        }

        private void btn_add_rr_Click(object sender, EventArgs e)
        {
            FrmNewReservation frmNewReservation = new FrmNewReservation();
            frmNewReservation.ShowDialog();
        }

        private void btn_add_rc_Click(object sender, EventArgs e)
        {
            FrmNewCustomer frmNewCustomer = new FrmNewCustomer();
            frmNewCustomer.ShowDialog();
        }

        private void bnt_add_rs_Click(object sender, EventArgs e)
        {
            FrmNewStylist frmNewStylist = new FrmNewStylist();
            frmNewStylist.ShowDialog();
        }

        private void btn_add_rh_Click(object sender, EventArgs e)
        {
            FrmNewHaircut frmNewHaircut = new FrmNewHaircut();
            frmNewHaircut.ShowDialog();
        }

        private void btn_modify_rc_Click(object sender, EventArgs e)
        {
            mns_reservecut_rc.Enabled = false;
            tab_reservation_rr.Enabled = false;
            tab_stylist_rs.Enabled = false;
            tab_haircut_rh.Enabled = false;
            btn_add_rc.Visible = false;
            btn_delete_rc.Visible = false;
            btn_modify_rc.Visible = false;
            txb_search_rc.Enabled = false;
            txb_name_rc.ReadOnly = false;
            txb_firstname_rc.ReadOnly = false;
            txb_address_rc.ReadOnly = false;
            txb_city_rc.ReadOnly = false;
            txb_npa_rc.ReadOnly = false;
            txb_phone_rc.ReadOnly = false;
            txb_mail_rc.ReadOnly = false;
            txb_datebirth_rc.ReadOnly = false;
            txb_contact_rc.ReadOnly = false;
            txb_haircut_rc.ReadOnly = false;
            btn_confirm_rc.Visible = true;
            btn_cancel_rc.Visible = true;
            btn_previous_rc.Visible = false;
            btn_next_rc.Visible = false;
            pic_customer_rc.Visible = false;
            btn_photo_rc.Visible = true;
            pic_customer_rc.Visible = false;
            cmb_haircut_rc.Visible = true;
            txb_haircut_rc.Visible = false;
            cmb_contact_rc.Visible = true;
            txb_contact_rc.Visible = false;
            dtp_birthdate_rc.Visible = true;
            txb_datebirth_rc.Visible = false;
            txb_search_rc.Text = "";
            txb_name_rc.Focus();
            AcceptButton = btn_cancel_rc;
            CancelButton = btn_cancel_rc;
        }

        private void bnt_confirm_rc_Click(object sender, EventArgs e)
        {
            mns_reservecut_rc.Enabled = true;
            tab_reservation_rr.Enabled = true;
            tab_stylist_rs.Enabled = true;
            tab_haircut_rh.Enabled = true;
            btn_add_rc.Visible = true;
            btn_delete_rc.Visible = true;
            btn_modify_rc.Visible = true;
            txb_search_rc.Enabled = true;
            txb_name_rc.ReadOnly = true;
            txb_firstname_rc.ReadOnly = true;
            txb_address_rc.ReadOnly = true;
            txb_city_rc.ReadOnly = true;
            txb_npa_rc.ReadOnly = true;
            txb_phone_rc.ReadOnly = true;
            txb_mail_rc.ReadOnly = true;
            txb_datebirth_rc.ReadOnly = true;
            txb_contact_rc.ReadOnly = true;
            txb_haircut_rc.ReadOnly = true;
            btn_confirm_rc.Visible = false;
            btn_cancel_rc.Visible = false;
            btn_previous_rc.Visible = true;
            btn_next_rc.Visible = true;
            pic_customer_rc.Visible = true;
            btn_photo_rc.Visible = false;
            pic_customer_rc.Visible = true;
            cmb_haircut_rc.Visible = false;
            txb_haircut_rc.Visible = true;
            cmb_contact_rc.Visible = false;
            txb_contact_rc.Visible = true;
            dtp_birthdate_rc.Visible = false;
            txb_datebirth_rc.Visible = true;
            txb_name_rc.Text = "";
            txb_firstname_rc.Text = "";
            txb_address_rc.Text = "";
            txb_city_rc.Text = "";
            txb_npa_rc.Text = "";
            txb_phone_rc.Text = "";
            txb_mail_rc.Text = "";
            cmb_contact_rc.SelectedItem = null;
            cmb_haircut_rc.SelectedItem = null;
            AcceptButton = btn_add_rc;
            txb_search_rc.Focus();
            FrmModificationConfirmation frmModificationConfirmation = new FrmModificationConfirmation();
            frmModificationConfirmation.ShowDialog();
        }

        private void btn_cancel_rc_Click(object sender, EventArgs e)
        {
            mns_reservecut_rc.Enabled = true;
            tab_reservation_rr.Enabled = true;
            tab_stylist_rs.Enabled = true;
            tab_haircut_rh.Enabled = true;
            btn_add_rc.Visible = true;
            btn_delete_rc.Visible = true;
            btn_modify_rc.Visible = true;
            txb_search_rc.Enabled = true;
            txb_name_rc.ReadOnly = true;
            txb_firstname_rc.ReadOnly = true;
            txb_address_rc.ReadOnly = true;
            txb_city_rc.ReadOnly = true;
            txb_npa_rc.ReadOnly = true;
            txb_phone_rc.ReadOnly = true;
            txb_mail_rc.ReadOnly = true;
            txb_datebirth_rc.ReadOnly = true;
            txb_contact_rc.ReadOnly = true;
            txb_haircut_rc.ReadOnly = true;
            btn_confirm_rc.Visible = false;
            btn_cancel_rc.Visible = false;
            btn_previous_rc.Visible = true;
            btn_next_rc.Visible = true;
            pic_customer_rc.Visible = true;
            btn_photo_rc.Visible = false;
            pic_customer_rc.Visible = true;
            cmb_haircut_rc.Visible = false;
            txb_haircut_rc.Visible = true;
            cmb_contact_rc.Visible = false;
            txb_contact_rc.Visible = true;
            dtp_birthdate_rc.Visible = false;
            txb_datebirth_rc.Visible = true;
            txb_name_rc.Text = "";
            txb_firstname_rc.Text = "";
            txb_address_rc.Text = "";
            txb_city_rc.Text = "";
            txb_npa_rc.Text = "";
            txb_phone_rc.Text = "";
            txb_mail_rc.Text = "";
            cmb_contact_rc.SelectedItem = null;
            cmb_haircut_rc.SelectedItem = null;
            AcceptButton = btn_add_rc;
            txb_search_rc.Focus();
        }

        private void bnt_modify_rs_Click(object sender, EventArgs e)
        {
            mns_reservecut_rc.Enabled = false;
            tab_reservation_rr.Enabled = false;
            tab_customer_rc.Enabled = false;
            tab_haircut_rh.Enabled = false;
            cmb_speciality_rs.Visible = true;
            btn_addspeciality_rs.Visible = true;
            btn_deletespeciality_rs.Visible = true;
            btn_addabsence_rs.Visible = true;
            btn_deleteabsence_rs.Visible = true;
            btn_previous_rs.Visible = false;
            btn_next_rs.Visible = false;
            pic_stylist_rs.Visible = false;
            btn_confirm_rs.Visible = true;
            btn_add_rs.Visible = false;
            btn_delete_rs.Visible = false;
            btn_modify_rs.Visible = false;
            btn_cancel_rs.Visible = true;
            btn_photo_rs.Visible = true;
            txb_search_rs.Enabled = false;
            txb_name_rs.ReadOnly = false;
            txb_firstname_rs.ReadOnly = false;
            txb_search_rs.Text = "";
            txb_name_rs.Focus();
            AcceptButton = btn_cancel_rs;
            CancelButton = btn_cancel_rs;
        }

        private void btn_confirm_rs_Click(object sender, EventArgs e)
        {
            mns_reservecut_rc.Enabled = true;
            tab_reservation_rr.Enabled = true;
            tab_customer_rc.Enabled = true;
            tab_haircut_rh.Enabled = true;
            cmb_speciality_rs.Visible = false;
            btn_addspeciality_rs.Visible = false;
            btn_deletespeciality_rs.Visible = false;
            btn_addabsence_rs.Visible = false;
            btn_deleteabsence_rs.Visible = false;
            btn_previous_rs.Visible = true;
            btn_next_rs.Visible = true;
            pic_stylist_rs.Visible = true;
            btn_confirm_rs.Visible = false;
            btn_cancel_rs.Visible = false;
            btn_add_rs.Visible = true;
            btn_delete_rs.Visible = true;
            btn_modify_rs.Visible = true;
            btn_photo_rs.Visible = false;
            pic_stylist_rs.Visible = true;
            txb_search_rs.Enabled = true;
            txb_name_rs.ReadOnly = true;
            txb_firstname_rs.ReadOnly = true;
            txb_name_rs.Text = "";
            txb_firstname_rs.Text = "";
            cmb_speciality_rs.SelectedIndex = -1;
            lst_speciality_rs.Items.Clear();
            lst_absence_rs.Items.Clear();
            AcceptButton = btn_add_rs;
            txb_search_rs.Focus();
            FrmModificationConfirmation frmModificationConfirmation = new FrmModificationConfirmation();
            frmModificationConfirmation.ShowDialog();
        }

        private void btn_cancel_rs_Click(object sender, EventArgs e)
        {
            mns_reservecut_rc.Enabled = true;
            tab_reservation_rr.Enabled = true;
            tab_customer_rc.Enabled = true;
            tab_haircut_rh.Enabled = true;
            cmb_speciality_rs.Visible = false;
            btn_addspeciality_rs.Visible = false;
            btn_deletespeciality_rs.Visible = false;
            btn_addabsence_rs.Visible = false;
            btn_deleteabsence_rs.Visible = false;
            btn_previous_rs.Visible = true;
            btn_next_rs.Visible = true;
            pic_stylist_rs.Visible = true;
            btn_confirm_rs.Visible = false;
            btn_cancel_rs.Visible = false;
            btn_add_rs.Visible = true;
            btn_delete_rs.Visible = true;
            btn_modify_rs.Visible = true;
            btn_photo_rs.Visible = false;
            pic_stylist_rs.Visible = true;
            txb_search_rs.Enabled = true;
            txb_name_rs.ReadOnly = true;
            txb_firstname_rs.ReadOnly = true;
            txb_name_rs.Text = "";
            txb_firstname_rs.Text = "";
            cmb_speciality_rs.SelectedIndex = -1;
            lst_speciality_rs.Items.Clear();
            lst_absence_rs.Items.Clear();
            AcceptButton = btn_add_rs;
            txb_search_rs.Focus();
        }

        private void btn_modify_rh_Click(object sender, EventArgs e)
        {
            mns_reservecut_rc.Enabled = false;
            tab_reservation_rr.Enabled = false;
            tab_customer_rc.Enabled = false;
            tab_stylist_rs.Enabled = false;
            txb_search_rh.Enabled = false;
            txb_name_rh.ReadOnly = false;
            txb_description_rh.ReadOnly = false;
            txb_cuttingtime_rh.ReadOnly = false;
            txb_shortlong_rh.Visible = false;
            txb_cuttingtime_rh.Visible = false;
            btn_previous_rh.Visible = false;
            btn_next_rh.Visible = false;
            cmb_shortlong_rh.Visible = true;
            cmb_cuttingtime_rh.Visible = true;
            txb_price_rh.ReadOnly = false;
            pic_haircut_rh.Visible = false;
            btn_photo_rh.Visible = true;
            btn_confirm_rh.Visible = true;
            btn_modify_rh.Visible = false;
            btn_add_rh.Visible = false;
            btn_delete_rh.Visible = false;
            btn_cancel_rh.Visible = true;
            txb_search_rh.Text = "";
            txb_name_rh.Focus();
            AcceptButton = btn_cancel_rh;
            CancelButton = btn_cancel_rh;
        }

        private void btn_confirm_rh_Click(object sender, EventArgs e)
        {
            mns_reservecut_rc.Enabled = true;
            tab_reservation_rr.Enabled = true;
            tab_customer_rc.Enabled = true;
            tab_stylist_rs.Enabled = true;
            txb_search_rh.Enabled = true;
            txb_name_rh.ReadOnly = true;
            txb_description_rh.ReadOnly = true;
            txb_cuttingtime_rh.ReadOnly = true;
            txb_shortlong_rh.Visible = true;
            txb_cuttingtime_rh.Visible = true;
            btn_previous_rh.Visible = true;
            btn_next_rh.Visible = true;
            cmb_shortlong_rh.Visible = false;
            cmb_cuttingtime_rh.Visible = false;
            txb_price_rh.ReadOnly = true;
            pic_haircut_rh.Visible = true;
            btn_photo_rh.Visible = false;
            btn_add_rh.Visible = true;
            btn_modify_rh.Visible = true;
            btn_cancel_rh.Visible = false;
            btn_delete_rh.Visible = true;
            btn_confirm_rh.Visible = false;
            txb_name_rh.Text = "";
            txb_description_rh.Text = "";
            txb_cuttingtime_rh.Text = "";
            txb_price_rh.Text = "";
            cmb_cuttingtime_rh.SelectedItem = null;
            cmb_shortlong_rh.SelectedItem = null;
            AcceptButton = btn_add_rh;
            txb_search_rh.Focus();
            FrmModificationConfirmation frmModificationConfirmation = new FrmModificationConfirmation();
            frmModificationConfirmation.ShowDialog();
        }

        private void btn_cancel_rh_Click(object sender, EventArgs e)
        {
            mns_reservecut_rc.Enabled = true;
            tab_reservation_rr.Enabled = true;
            tab_customer_rc.Enabled = true;
            tab_stylist_rs.Enabled = true;
            txb_search_rh.Enabled = true;
            txb_name_rh.ReadOnly = true;
            txb_description_rh.ReadOnly = true;
            txb_cuttingtime_rh.ReadOnly = true;
            txb_shortlong_rh.Visible = true;
            txb_cuttingtime_rh.Visible = true;
            btn_previous_rh.Visible = true;
            btn_next_rh.Visible = true;
            cmb_shortlong_rh.Visible = false;
            cmb_cuttingtime_rh.Visible = false;
            txb_price_rh.ReadOnly = true;
            pic_haircut_rh.Visible = true;
            btn_photo_rh.Visible = false;
            btn_add_rh.Visible = true;
            btn_modify_rh.Visible = true;
            btn_cancel_rh.Visible = false;
            btn_delete_rh.Visible = true;
            btn_confirm_rh.Visible = false;
            txb_name_rh.Text = "";
            txb_description_rh.Text = "";
            txb_cuttingtime_rh.Text = "";
            txb_price_rh.Text = "";
            cmb_cuttingtime_rh.SelectedItem = null;
            cmb_shortlong_rh.SelectedItem = null;
            AcceptButton = btn_add_rh;
            txb_search_rh.Focus();

        }

        private void btn_delete_rc_Click(object sender, EventArgs e)
        {
            FrmDeleteConfirmationRequest frmDeleteConfirmation = new FrmDeleteConfirmationRequest(btn_delete_rc);
            frmDeleteConfirmation.ShowDialog();
        }

        private void btn_delete_rs_Click(object sender, EventArgs e)
        {
            FrmDeleteConfirmationRequest frmDeleteConfirmation = new FrmDeleteConfirmationRequest(btn_delete_rs);
            frmDeleteConfirmation.ShowDialog();
        }

        private void btn_delete_rh_Click(object sender, EventArgs e)
        {
            FrmDeleteConfirmationRequest frmDeleteConfirmation = new FrmDeleteConfirmationRequest(btn_delete_rh);
            frmDeleteConfirmation.ShowDialog();
        }

        private void bnt_photo_rc_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Images (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"; // Exemple de filtre
            openFileDialog.Title = "S�lectionnez un fichier";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Ici, vous pouvez faire ce que vous voulez avec le chemin du fichier s�lectionn�.
                // Par exemple, vous pourriez l'afficher dans un TextBox ou lire le contenu du fichier.
                // Exemple : textBox1.Text = openFileDialog.FileName;
            }
        }

        private void btn_photo_rs_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Images (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"; // Exemple de filtre
            openFileDialog.Title = "S�lectionnez un fichier";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Ici, vous pouvez faire ce que vous voulez avec le chemin du fichier s�lectionn�.
                // Par exemple, vous pourriez l'afficher dans un TextBox ou lire le contenu du fichier.
                // Exemple : textBox1.Text = openFileDialog.FileName;
            }
        }

        private void bnt_photo_rh_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Images (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"; // Exemple de filtre
            openFileDialog.Title = "S�lectionnez un fichier";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Ici, vous pouvez faire ce que vous voulez avec le chemin du fichier s�lectionn�.
                // Par exemple, vous pourriez l'afficher dans un TextBox ou lire le contenu du fichier.
                // Exemple : textBox1.Text = openFileDialog.FileName;
            }
        }

        private void FrmReserveCut_Load(object sender, EventArgs e)
        {
            btn_add_rr.Focus();
        }

        private void tab_reservecut_rc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tab_reservecut_rc.SelectedIndex == 0)
            {
                btn_add_rr.Focus();
                AcceptButton = btn_add_rr;
            }
            else if (tab_reservecut_rc.SelectedIndex == 1)
            {
                txb_search_rc.Focus();
                AcceptButton = btn_add_rc;
            }
            else if (tab_reservecut_rc.SelectedIndex == 2)
            {
                txb_search_rs.Focus();
                AcceptButton = btn_add_rs;
            }
            else if (tab_reservecut_rc.SelectedIndex == 3)
            {
                txb_search_rh.Focus();
                AcceptButton = btn_add_rh;
            }
        }

        private void btn_addabsence_rs_Click(object sender, EventArgs e)
        {
            FrmNewAbsence frmNewAbsence = new FrmNewAbsence();
            frmNewAbsence.ShowDialog();
        }

        private void pnl_0800_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_0830_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0900_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0930_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1000_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1030_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1100_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1130_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1200_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1230_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1300_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1330_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1400_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1430_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1500_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1530_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1600_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1630_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1700_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1730_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1800_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1830_mon_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_0800_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0830_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_0900_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_0930_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {

            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1000_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1030_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1100_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1130_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1200_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1300_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1330_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1400_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1430_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1500_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1530_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1600_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1230_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1630_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1700_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1730_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1800_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1830_tue_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0800_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0830_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0900_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0930_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1000_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1030_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1100_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1130_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1200_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1230_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1300_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1330_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1400_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1430_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1500_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1530_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1600_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1630_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1700_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1730_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1800_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1830_wen_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0800_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0830_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_0900_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_0930_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1000_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1030_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1100_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1130_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1200_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1230_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1300_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1330_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1400_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1430_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1500_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1530_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1600_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1630_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1700_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1730_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1800_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1830_thu_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0800_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_0830_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0900_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0930_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1000_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1030_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1100_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1130_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1200_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1230_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1300_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1330_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1400_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1430_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1500_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1530_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1600_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1630_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1700_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1730_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1800_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1830_fri_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0800_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0830_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_0900_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_0930_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1000_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1030_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1100_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1130_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1200_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1230_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1300_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1330_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1400_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1430_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1500_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1530_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1600_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1630_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1700_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();

        }

        private void pnl_1730_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1800_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void pnl_1830_sat_rr_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            FrmReservation frmReservation = new FrmReservation();
            frmReservation.ShowDialog();
        }

        private void btn_addspeciality_rs_Click(object sender, EventArgs e)
        {
            string speciality = cmb_speciality_rs.Text;

            if (!lst_speciality_rs.Items.Contains(speciality))
            {
                lst_speciality_rs.Items.Add(speciality);
            }
            else
            {
                MessageBox.Show($"{speciality} est d�j� ajout�.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
