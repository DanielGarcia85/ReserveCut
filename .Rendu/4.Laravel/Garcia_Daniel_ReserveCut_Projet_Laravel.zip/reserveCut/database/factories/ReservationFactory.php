<?php

// Declares the namespace for database factories to organize factory classes
namespace Database\Factories;

// Imports the base Factory class from Laravel's Eloquent factory system
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * Extends the Laravel Factory class specifically for the Reservation model to generate fake data.
 */
class ReservationFactory extends Factory
{
    /**
     * Define the model's default state.
     * Returns the default set of attributes for the Reservation model.
     *
     * @return array<string, mixed> // Returns an array with string keys and mixed values.
     */
    public function definition(): array
    {
        // Returns an array of attributes for creating a Reservation record
        return [
            'date_begin' => $this->faker->dateTimeBetween('now', '+1 year'), // Generate a fake random date/time between now and the next year as the start date
            'date_end' => $this->faker->dateTimeBetween('now', '+2 years'), // Generate a fake random date/time between now and two years from now as the end date
            'comments' => $this->faker->sentence, // Generate a fake random sentence as comments for the reservation
            'beard_y_n' => $this->faker->boolean, // Generate a fake boolean value to indicate if a beard service is required
            'shampoo_y_n' => $this->faker->boolean, // Generate a fake boolean value to indicate if a shampoo service is required
        ];
    }
}
